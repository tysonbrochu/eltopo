// ---------------------------------------------------------
//
//  options.h
//  Tyson Brochu 2008
//
//  Constants and macro defines
//
// ---------------------------------------------------------

#ifndef OPTIONS_H
#define OPTIONS_H

// ---------------------------------------------------------
// Preproccessor defines
// ---------------------------------------------------------

// Fast as possible, no sanity checking
//
#define ELTOPO_PROFILE

// Whether to use an OpenGL GUI, or run command-line style
// (Define NO_GUI in your build to suppress the GUI.)

#ifndef NO_GUI
#define USE_GUI
#endif

#ifndef NO_RAY_TRACER
#define RAY_TRACER
#endif

// ---------------------------------------------------------
// Global constants
// ---------------------------------------------------------

const double UNINITIALIZED_DOUBLE = 0x0F;

const double G_EIGENVALUE_RANK_RATIO = 0.03;

#endif

