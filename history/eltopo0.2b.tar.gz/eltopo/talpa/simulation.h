// ---------------------------------------------------------
//
//  simulation.h
//  Tyson Brochu 2008
//
//  Simulation class.  Mainly just timekeeping.
//
// ---------------------------------------------------------

#ifndef SIMULATION_H
#define SIMULATION_H

// ---------------------------------------------------------
// Nested includes
// ---------------------------------------------------------

// ---------------------------------------------------------
//  Forwards and typedefs
// ---------------------------------------------------------

// ---------------------------------------------------------
//  Interface declarations
// ---------------------------------------------------------

// ---------------------------------------------------------
///
///  Simulation parameters
///
// ---------------------------------------------------------

class Simulation
{
public:
   
   /// Specify a target time step and optional end time
   ///
   Simulation( double in_dt, double in_max_t = 1e30 );
   
   /// simulation time step size
   ///
   double m_dt;

   /// end time
   ///
   double m_max_t;
   
   /// frame time step size (1/fps)
   ///
   double m_frame_dt;
   
   /// current simulation time
   ///
   double m_curr_t;

   /// current frame
   ///
   unsigned int m_curr_frame;

   /// whether we're currently running an entire simulation
   ///
   bool m_running;

   /// whether we're currently running a single timestep of the simulation
   ///
   bool m_currently_advancing_simulation;
   
};

// ---------------------------------------------------------
//  Inline functions
// ---------------------------------------------------------

inline Simulation::Simulation( double in_dt, double in_max_t ) :
   m_dt(in_dt),
   m_max_t(in_max_t),
   m_frame_dt(in_dt),
   m_curr_t(0),
   m_curr_frame(0),
   m_running(false),
   m_currently_advancing_simulation(false)
{
}

#endif



