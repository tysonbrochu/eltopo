// ---------------------------------------------------------
//
//  main.cpp
//  Tyson Brochu 2008
//
//  Functions for setting up and running an explicit surface simulation, 
//  as well as visualizing it with gluvi.
//
// ---------------------------------------------------------

// ---------------------------------------------------------
// Includes
// ---------------------------------------------------------

#include <cstdio>
#include <fstream>
#include <vector>
#include <queue>

#include <options.h>

// common
#include <array2.h>
#ifdef USE_GUI
#include <gluvi.h>
#endif
#include <marching_tiles_hires.h>
#include <meshloader.h>
#include <util.h>
#include <vec.h>
#include <wallclocktime.h>

// el topo
#include <eltopo.h>
#include <iomesh.h>
#include <meancurvature.h>
#include <meshdriver.h>
#include <parser.h>
#include <simulation.h>
#include <surftrack.h>

// raytracer
#ifdef RAY_TRACER
#include <box.h>
#include <camera.h>
#include <fresnel_shader.h>
#include <image_io.h>
#include <raytracer.h>
#include <transformation.h>
#include <triangle_mesh.h>
#include <thing.h>
#include <diffuse_shader.h>
#include <soot_shader.h>
#include <scatter_shader.h>
#include <plane.h>
#include <sphere.h>
#endif

// ---------------------------------------------------------
// Globals
// ---------------------------------------------------------

SurfTrack *g_surf;        // The dynamic surface
MeshDriver *g_driver;     // The thing that makes the dynamic surface go
Simulation *g_sim;        // Timekeeping

char g_output_path[256];  // Where to write output data

#ifdef USE_GUI

float g_camera_target[] = {0.0f, 0.0f, 0.0f};    // OpenGL camera points here
Gluvi::Target3D g_cam(g_camera_target, 10.0f);   // OpenGL camera

bool g_render_edges;
bool g_render_fill_triangles;
bool g_render_colliding_triangles;
bool g_render_vertex_rank;
bool g_display_driver = false;
bool g_smooth_shading = true;

#else

struct hack_camera
{
   float target[3];
   float dist;
   float pitch;
   float heading;
} g_cam;

#endif

std::vector<double> g_vertex_values;
std::vector<unsigned int> g_intersecting_triangles;

// Mouse click / ray casting data
int g_selected_vertex = -1;
int g_selected_edge = -1;
int g_selected_triangle = -1;
float g_ray_origin[3], g_ray_direction[3];

// Stats and timings

unsigned int g_min_num_triangles;
unsigned int g_max_num_triangles;
unsigned int g_total_num_triangles;

unsigned int g_min_num_vertices;
unsigned int g_max_num_vertices;

unsigned int g_total_steps = 0;

double g_total_sim_time = 0;
double g_total_improvement_time = 0;
double g_total_topology_time = 0;
double g_total_driver_time = 0;
double g_total_collision_time = 0;

bool g_skip_improve = false;
bool g_skip_to_impact_zones = false;

bool g_making_animation = false;

#ifdef RAY_TRACER
bool g_rendering_series = false;
bool g_rendering_snapshot = false;
void render_scene( const char* sgi_filename );
bool g_volume_render = true;
#endif

enum { FOG, THICK, THIN };
int g_example_setup = FOG;

// TEMP: display options for fluid sim driver
unsigned int g_fluid_render_type = 0;
const unsigned int g_fluid_render_type_max = 5;


// ---------------------------------------------------------
// Interface declarations
// ---------------------------------------------------------

void display_stats( );

void advance_sim();
void run_simulation(void);

#ifdef USE_GUI
void keyboard(unsigned char key, int x, int y);
void advance_frame();
void mouse(int button, int state, int x, int y);
void mouseMotion(int x, int y);
void bin2ppm();
void display(void);
void init_gui( int argc, char **argv );
#endif

void init_simulation( int argc, char **argv );

int main(int argc, char **argv);


// ---------------------------------------------------------
// Function definitions
// ---------------------------------------------------------

// ---------------------------------------------------------
///
/// Output collected stats to stdout
///
// ---------------------------------------------------------

void display_stats( )
{
   std::cout << "g_total_sim_time: " << g_total_sim_time << std::endl;
   std::cout << "g_total_improvement_time: " << g_total_improvement_time << std::endl;
   std::cout << "g_total_topology_time: " << g_total_topology_time << std::endl;
   std::cout << "g_total_driver_time: " << g_total_driver_time << std::endl;
   std::cout << "g_total_collision_time: " << g_total_collision_time << std::endl;   

   std::cout << "g_total_steps: " << g_total_steps << std::endl;
   
   std::cout << "avg improvement time per step: " << g_total_improvement_time / (double) g_total_steps << std::endl;
   std::cout << "avg topology time per step: " << g_total_topology_time / (double) g_total_steps << std::endl;
   std::cout << "avg driver time per step: " << g_total_driver_time / (double) g_total_steps << std::endl;
   std::cout << "avg collision handling time per step: " << g_total_collision_time / (double) g_total_steps << std::endl;   
      
   std::cout << "min number of triangles: " << g_min_num_triangles << std::endl;
   std::cout << "max number of triangles: " << g_max_num_triangles << std::endl;
   std::cout << "min number of vertices: " << g_min_num_vertices << std::endl;
   std::cout << "max number of vertices: " << g_max_num_vertices << std::endl;   

   std::cout << "avg num triangles per step: " << (double) g_total_num_triangles / (double) g_total_steps << std::endl;
   
   std::cout << "total_num_collisions: " << g_surf->m_total_num_collisions << std::endl;
   
}


void static_operations( )
{
   
   //
   // Put SurfTrack data into C-array format.
   //
   
   unsigned int nv = g_surf->m_positions.size();
   double *masses = new double[nv];
   double *positions = new double[3*nv];
   for ( unsigned int i = 0; i < nv; ++i )
   {
      masses[i] = g_surf->m_masses[i];
      positions[3*i] = g_surf->m_positions[i][0];
      positions[3*i+1] = g_surf->m_positions[i][1];
      positions[3*i+2] = g_surf->m_positions[i][2];         
   }
   
   unsigned int nt = g_surf->m_mesh.m_tris.size();
   int *triangles = new int[3*nt];
   for ( unsigned int i = 0; i < nt; ++i )
   {
      triangles[3*i] = g_surf->m_mesh.m_tris[i][0];
      triangles[3*i+1] = g_surf->m_mesh.m_tris[i][1];
      triangles[3*i+2] = g_surf->m_mesh.m_tris[i][2];         
   }      
                               
   ElTopoGeneralOptions general_options;
   general_options.m_verbose = g_surf->m_verbose;
   general_options.m_collision_safety = g_surf->m_collision_safety;
   
   ElTopoStaticOperationsOptions static_options;
   static_options.m_allow_topology_changes = g_surf->m_allow_topology_changes;
   static_options.m_max_volume_change = g_surf->m_max_volume_change;
   static_options.m_min_edge_length = g_surf->m_min_edge_length;
   static_options.m_max_edge_length = g_surf->m_max_edge_length;
   static_options.m_merge_proximity_epsilon = g_surf->m_merge_proximity_epsilon;
   static_options.m_perform_improvement = g_surf->m_perform_improvement;
   static_options.m_subdivision_scheme = g_surf->m_subdivision_scheme;
   
   // ====================================================================================================
   
   //
   // Run static operations
   //
   
   int out_num_vertices;                
   double* out_vertex_locations;
   int out_num_triangles;
   int* out_triangles;
   double* out_masses;
   
   el_topo_static_operations( nv,
                              positions,
                              nt,
                              triangles,
                              masses,
                              &general_options,       
                              &static_options, 
                              &out_num_vertices,
                              &out_vertex_locations,
                              &out_num_triangles,
                              &out_triangles,
                              &out_masses );
         
   
   // ====================================================================================================
   
   //
   // Now update SurfTrack with new data
   //
   
   std::vector<Vec3d> new_positions;
   std::vector<double> new_masses;
   for ( int i = 0; i < out_num_vertices; ++i )
   {
      new_positions.push_back( Vec3d( out_vertex_locations[3*i], out_vertex_locations[3*i+1], out_vertex_locations[3*i+2] ) ); 
      new_masses.push_back( out_masses[i] );
   }
   
   std::vector<Vec3ui> new_triangles;
   for ( int i = 0; i < out_num_triangles; ++i )
   {
      new_triangles.push_back( Vec3ui( out_triangles[3*i], out_triangles[3*i+1], out_triangles[3*i+2] ) ); 
   }
   

   g_surf->m_positions = new_positions;
   g_surf->m_masses = new_masses;
   g_surf->m_newpositions.resize( out_num_vertices );
   g_surf->m_velocities.resize( out_num_vertices );
   g_surf->m_mesh.m_tris = new_triangles;
   g_surf->m_mesh.update_connectivity( out_num_vertices );
   
   el_topo_free_static_operations_results( out_vertex_locations, out_triangles, out_masses );
   
   delete[] masses;
   delete[] positions;
   delete[] triangles;

}


void integration_operations( double dt, const std::vector<Vec3d>& predicted_positions )
{
   
   //
   // Put SurfTrack data into C-array format.
   //
   
   unsigned int nv = g_surf->m_positions.size();
   double *c_masses = new double[nv];
   double *c_positions = new double[3*nv];
   double *c_predicted_positions = new double[3*nv];
   for ( unsigned int i = 0; i < nv; ++i )
   {
      c_masses[i] = g_surf->m_masses[i];
      c_positions[3*i] = g_surf->m_positions[i][0];
      c_positions[3*i+1] = g_surf->m_positions[i][1];
      c_positions[3*i+2] = g_surf->m_positions[i][2];         
      c_predicted_positions[3*i] = predicted_positions[i][0];
      c_predicted_positions[3*i+1] = predicted_positions[i][1];
      c_predicted_positions[3*i+2] = predicted_positions[i][2];      
   }
   
   unsigned int nt = g_surf->m_mesh.m_tris.size();
   int *c_triangles = new int[3*nt];
   for ( unsigned int i = 0; i < nt; ++i )
   {
      c_triangles[3*i] = g_surf->m_mesh.m_tris[i][0];
      c_triangles[3*i+1] = g_surf->m_mesh.m_tris[i][1];
      c_triangles[3*i+2] = g_surf->m_mesh.m_tris[i][2];         
   }      
   
   ElTopoGeneralOptions general_options;
   general_options.m_verbose = g_surf->m_verbose;
   general_options.m_collision_safety = g_surf->m_collision_safety;
   
   ElTopoIntegrationOptions integration_options;
   integration_options.m_proximity_epsilon = g_surf->m_proximity_epsilon;
   integration_options.m_dt = dt;
   
   // ====================================================================================================
   
   //
   // Run integration operations
   //
   
   double* out_vertex_locations;
   
   el_topo_integrate( nv,
                      c_positions,
                      c_predicted_positions,
                      nt,
                      c_triangles,
                      c_masses,
                      &general_options,
                      &integration_options,
                      &out_vertex_locations );
   
   // ====================================================================================================
   
   //
   // Now update SurfTrack with new positions
   //

   for ( unsigned int i = 0; i < nv; ++i )
   {
      g_surf->m_positions[i] = Vec3d( out_vertex_locations[3*i], out_vertex_locations[3*i+1], out_vertex_locations[3*i+2] );
   }
   
   el_topo_free_integrate_results( out_vertex_locations );
   
   delete[] c_masses;
   delete[] c_positions;
   delete[] c_predicted_positions;  
   delete[] c_triangles;
   
}


// ---------------------------------------------------------
///
/// Advance simulation, GUI-ignorant
///
// ---------------------------------------------------------

void advance_sim()
{
   
   double start_time = get_time_in_seconds();
   
   double accum_dt = 0;
   
   while ( (accum_dt < g_sim->m_dt) && (g_sim->m_curr_t + accum_dt < g_sim->m_max_t) && (g_sim->m_running == true) )        
   {       
      
      std::cout << "update connectivity" << std::endl;
      
      ++g_total_steps;
      
      std::cout << "rebuilding broad phase" << std::endl;
      g_surf->rebuild_static_broad_phase();

      // ----------
      // collect stats
      // ----------
      
      g_min_num_triangles = min( g_min_num_triangles, (unsigned int) g_surf->m_mesh.m_tris.size() );
      g_max_num_triangles = max( g_max_num_triangles, (unsigned int) g_surf->m_mesh.m_tris.size() );
      g_min_num_vertices = min( g_min_num_vertices, (unsigned int) g_surf->m_positions.size() );
      g_max_num_vertices = max( g_max_num_vertices, (unsigned int) g_surf->m_positions.size() );      
      g_total_num_triangles += g_surf->m_mesh.m_tris.size();
            
      // ---------- 
      // mesh maintenance & topology changes
      // ---------- 
     
      if ( false == g_skip_improve && false == g_skip_to_impact_zones )
      {
         // El Topo API:
         //static_operations();
         
         // SurfTrack API:
         g_surf->improve_mesh();
         g_surf->topology_changes();
      }
            
      // ---------- 
      // advance underlying simulation
      // ----------
                  
      double curr_dt = g_sim->m_dt - accum_dt;
      curr_dt = min( curr_dt, g_sim->m_max_t - g_sim->m_curr_t - accum_dt );
      
      printf( "desired dt: %g\n", curr_dt );
      
      printf( "setting surface velocity\n" );

      double time_before_driver = get_time_in_seconds();

      if ( false == g_skip_to_impact_zones )
      {
         g_surf->m_velocities.resize( g_surf->m_positions.size() );
         g_driver->set_surface_velocity( *g_surf, g_surf->m_velocities, g_sim->m_curr_t + accum_dt, curr_dt );
      }
      
      double time_after_driver = get_time_in_seconds();
      
      g_total_driver_time += time_after_driver - time_before_driver;
               
      printf( "adapted dt: %g\n", curr_dt );
      
      // ----------
      // move & handle collision detection
      // ----------
      
      double time_before_integration = get_time_in_seconds();
      
      std::vector<Vec3d> predicted_positions( g_surf->m_positions.size() );
      for ( unsigned int i = 0; i < g_surf->m_positions.size(); ++i )
      {
         if( g_surf->m_velocities[i][0] != g_surf->m_velocities[i][0] )
         {
            std::cout << i << ": " << g_surf->m_velocities[i][0] << std::endl;
            assert( false );
         }
         
         assert( g_surf->m_velocities[i][1] == g_surf->m_velocities[i][1] );
         assert( g_surf->m_velocities[i][2] == g_surf->m_velocities[i][2] );                  
         
         predicted_positions[i] = g_surf->m_positions[i] + curr_dt * g_surf->m_velocities[i];
         //g_surf->m_newpositions[i] = g_surf->m_positions[i] + curr_dt * g_surf->m_velocities[i];
      }
      
      // El Topo API:
      //integration_operations( curr_dt, predicted_positions );
      
      // DynamicSurface:
      g_surf->integrate( curr_dt );
      
      g_total_collision_time += get_time_in_seconds() - time_before_integration;
      
      if ( g_surf->m_collision_safety )
      {
         g_surf->assert_mesh_is_intersection_free();      
      }
      
      accum_dt += curr_dt;
      
      g_driver->compute_error( *g_surf, g_sim->m_curr_t + accum_dt );
      
   }
      
   double sim_step_time = get_time_in_seconds() - start_time;
   g_total_sim_time += sim_step_time;
   
   ++g_sim->m_curr_frame;
   g_sim->m_curr_t += accum_dt;
   
   
   printf( "frame: %d  ---  t: %f   \n", g_sim->m_curr_frame, g_sim->m_curr_t );
   printf( "run time: %f --- tris: %d \n", sim_step_time, (int)g_surf->m_mesh.m_tris.size() );
      
   // ----------
   // file output
   // ----------
   
   char binary_filename[256];
   sprintf( binary_filename, "%s/frame%04d.bin", g_output_path, g_sim->m_curr_frame );      
   write_binary_file( g_surf->m_mesh, g_surf->m_positions, g_surf->m_masses, g_sim->m_curr_t, binary_filename );   

   //char v_binary_filename[256];
   //sprintf( v_binary_filename, "%s/frame%04d-with-velocities.bin", g_output_path, g_sim->m_curr_frame );      
   //write_binary_file_with_velocities( g_surf->m_mesh, g_surf->m_positions, g_surf->m_masses, g_surf->m_velocities, g_sim->m_curr_t, v_binary_filename );   
   
   //if ( g_sim->m_curr_frame % 25 == 0 )
//   {
//      char sgi_filename[256];
//      sprintf( sgi_filename, "%s/frame%04d.sgi", g_output_path, g_sim->m_curr_frame );      
//      render_scene( sgi_filename );
//   }      
   
   // ----------
   // check if max time is reached
   // ----------

   if ( g_sim->m_curr_t + 1e-10 >= g_sim->m_max_t )
   {         
      g_sim->m_running = false;
      std::cout << "total time steps: " << g_total_steps << std::endl;
      display_stats();
   }
      
}


// ---------------------------------------------------------
///
/// Run an entire simulation without GUI
///
// ---------------------------------------------------------
void run_simulation(void)
{
   g_sim->m_running = true;
   while ( g_sim->m_running )
   {
      if(!g_sim->m_currently_advancing_simulation)
      {
         g_sim->m_currently_advancing_simulation = true;
         
         advance_sim();
         
         g_sim->m_currently_advancing_simulation = false;
      }
   }
   g_sim->m_running = false;
}


// ---------------------------------------------------------
///
/// Run all examples from the SISC submission
///
// ---------------------------------------------------------

void run_all_sisc_examples( const char* sisc_script_directory )
{
   std::cout << "\n\n\n -------------- running all SISC examples -------------- \n\n\n" << std::endl;
   
   std::vector<std::string> sisc_script_filenames;
   sisc_script_filenames.push_back( "faceoff-params-1.txt" );
   sisc_script_filenames.push_back( "faceoff-params-2.txt" );
   sisc_script_filenames.push_back( "faceoff-params-3.txt" );         
   sisc_script_filenames.push_back( "normal-params-1.txt" );
   sisc_script_filenames.push_back( "normal-params-2.txt" );
   sisc_script_filenames.push_back( "normal-params-3.txt" );      
   sisc_script_filenames.push_back( "mc-params-1.txt" );   
   sisc_script_filenames.push_back( "mc-params-2.txt" );   
   sisc_script_filenames.push_back( "mc-params-3.txt" );         
   sisc_script_filenames.push_back( "enright-parameters.txt" );
   sisc_script_filenames.push_back( "curlnoise-parameters.txt" );
   sisc_script_filenames.push_back( "tangled.txt" );
   sisc_script_filenames.push_back( "open-curlnoise-parameters.txt" );

   
   std::vector<std::string> output_directories;
   output_directories.push_back( "/faceoff1/" );
   output_directories.push_back( "/faceoff2/" );
   output_directories.push_back( "/faceoff3/" );   
   output_directories.push_back( "/normal1/" );
   output_directories.push_back( "/normal2/" );
   output_directories.push_back( "/normal3/" );
   output_directories.push_back( "/mc1/" );      
   output_directories.push_back( "/mc2/" );
   output_directories.push_back( "/mc3/" );   
   output_directories.push_back( "/enright/" );
   output_directories.push_back( "/curlnoise/" );
   output_directories.push_back( "/tangled/" );
   output_directories.push_back( "/opencurlnoise/" );
   
   char results_filename[256];
   strcpy( results_filename, g_output_path );
   strcat( results_filename, "results.txt" );
   std::ofstream results_file( results_filename, std::ios_base::trunc );      // clears existing contents!
   assert( results_file.good() );
   
   std::cout << "results: " << results_filename << std::endl;
   
   for ( unsigned int i = 0; i < sisc_script_filenames.size(); ++i )
   {
      delete g_sim;
      delete g_surf;
      delete g_driver;

      char base_output_path[256];
      strcpy( base_output_path, g_output_path );
      
      std::cout << "base_output_path: " << base_output_path << std::endl;
         
      // set the output path
      strcat( g_output_path, output_directories[i].c_str() );
      std::cout << "output path: " << g_output_path << std::endl;
      
      // re-initialize the simulation
      char filename[256];
      strcpy( filename, sisc_script_directory );
      strcat( filename, sisc_script_filenames[i].c_str() );
      
      char* fake_argv[2] = { NULL, filename };
      init_simulation( 2, fake_argv );
      
      results_file << "filename: " << sisc_script_filenames[i] << std::endl;
      results_file << "------------------------------------------" << std::endl;
      results_file << "avg edge length: " << g_surf->get_average_edge_length() << std::endl;
      results_file << "min edge length: " << g_surf->m_min_edge_length << std::endl;
      results_file << "max edge length: " << g_surf->m_max_edge_length << std::endl;
      results_file << "max volume change: " << g_surf->m_max_volume_change << std::endl;
      
      {
         char binary_filename[256];
         sprintf( binary_filename, "%s/frame%04d.bin", g_output_path, g_sim->m_curr_frame );      
         write_binary_file( g_surf->m_mesh, g_surf->m_positions, g_surf->m_masses, g_sim->m_curr_t, binary_filename );   
      }   
      
      run_simulation();
      
      std::cout << "\n -------------- sim done -------------- \n\n\n" << std::endl;
      
      // re-route cout to outfile
      std::streambuf* sbuf = std::cout.rdbuf();
      std::cout.rdbuf(results_file.rdbuf());
      
      // put final error into outfile
      g_driver->compute_error( *g_surf, g_sim->m_curr_t );

      // put timings and mesh resolution stats into outfile
      display_stats();
      
      std::cout << std::endl;
      
      // now restore cout to usual
      std::cout.rdbuf(sbuf);
            
      // restore output path
      strcpy( g_output_path, base_output_path );
      
   }
   
   results_file.close();
   
}
                           

#ifdef RAY_TRACER


void extend_open_surface( std::vector<Vec3d>& new_vertices, std::vector<Vec3i>& new_triangles )
{
   // find a boundary edge
   unsigned int i = 0;
   for ( ; i < g_surf->m_mesh.m_edges.size(); ++i )
   {
      if ( g_surf->m_mesh.m_edgetri[i].size() == 1 )
      {
         break;
      }
   }
   
   unsigned int root_vertex = g_surf->m_mesh.m_edges[i][0];
   unsigned int curr_edge = i;
   unsigned int curr_vertex = g_surf->m_mesh.m_edges[i][1];
   std::vector<unsigned int> boundary_vertices;
   while ( curr_vertex != root_vertex )
   {
      boundary_vertices.push_back( curr_vertex );
      const std::vector<unsigned int>& vtxedge = g_surf->m_mesh.m_vtxedge[curr_vertex];
      // get next edge
      
      for ( unsigned int i = 0; i < vtxedge.size(); ++i )
      {
         unsigned int e = vtxedge[i];
         if ( ( g_surf->m_mesh.m_edgetri[e].size() == 1 ) && ( e != curr_edge ) )
         {
            curr_edge = e;
            if ( g_surf->m_mesh.m_edges[e][0] == curr_vertex )
            {
               curr_vertex = g_surf->m_mesh.m_edges[e][1];
            }
            else
            {
               assert( g_surf->m_mesh.m_edges[e][1] == curr_vertex );
               curr_vertex = g_surf->m_mesh.m_edges[e][0];
            }
            break;
         }
      }
         
   }
   
   std::cout << "boundary_vertices: " << boundary_vertices.size() << std::endl;
   std::cout << "m_positions: " << g_surf->m_positions.size() << std::endl;
   
   // now we have the boundary
   
   new_vertices.clear();
   new_triangles.clear();
   
   // duplicate and offset each boundary vertex
   for ( unsigned int i = 0; i < boundary_vertices.size(); ++i )
   {
      new_vertices.push_back( g_surf->m_positions[ boundary_vertices[i] ] + Vec3d( 0.0, -10.0, 0.0 ) );
   }
   
   // triangulate offset vertices with boundary vertices
   
   for ( unsigned int i = 0; i < boundary_vertices.size(); ++i )
   {
      unsigned int next_i = (i+1) % boundary_vertices.size();
      unsigned int new_i = i + g_surf->m_positions.size();
      unsigned int new_next_i = (i+1) % boundary_vertices.size() + g_surf->m_positions.size();
      
      new_triangles.push_back( Vec3i( boundary_vertices[i], new_i, boundary_vertices[next_i] ) );
      new_triangles.push_back( Vec3i( new_i, new_next_i, boundary_vertices[next_i] ) );
   }
   
}



//void load_raytrace_settings()
//{
//   char filename[256];
//   sprintf( filename, "%s/rtfile.txt", g_output_path );      
//   std::ifstream rt_file( filename );
//   assert( rt_file.good() );
//      
//}

// ---------------------------------------------------------
///
/// Run raytracer on the scene using the current Gluvi camera parameters (this code is currently in a state of flux).
///
// ---------------------------------------------------------

void render_scene( const char* sgi_filename )
{
   
   if ( !g_rendering_snapshot )
   {
      
      g_rendering_snapshot = true;
      
      std::cout << "Render setup: " << g_example_setup;
      std::cout << ", g_volume_render: " << g_volume_render << std::endl;

      std::cout << "ray tracing..." << std::endl;
      double render_start_time = get_time_in_seconds();
      
      // set up lights
      Lighting lighting;
      
      Vec3f overhead_light_pos;
      Vec3f fill_light_pos;
      switch ( g_example_setup )
      {
         case FOG:
            
            // 
            // FOG
            //

            lighting.ambient = 0.4f * Vec3f(1.0f, 1.0f, 1.0f);
            
            // overhead
            overhead_light_pos =  Vec3f( 1.0, 10.0, 1.0 );       
            lighting.directed_light.push_back(new PointLight( overhead_light_pos, 40.0f * Vec3f(1.0f, 1.0f, 1.0f) ));
            
            // fill
            fill_light_pos = Vec3f( 0, 0, 1.2 * g_cam.dist );
            fill_light_pos = rotate( fill_light_pos, g_cam.pitch, Vec3f(1,0,0) );
            fill_light_pos = rotate( fill_light_pos, g_cam.heading, Vec3f(0,1,0) );
            fill_light_pos += Vec3f( g_cam.target[0], g_cam.target[1], g_cam.target[2] );
            lighting.directed_light.push_back(new PointLight( fill_light_pos, 40.0f * Vec3f(1.0f,1.0f,1.0f)));
            break;
            
         case THICK:
            
            //
            // THICK SMOKE
            //
            
            lighting.ambient = 0.3f * Vec3f(1.0f, 1.0f, 1.0f);
            
            overhead_light_pos =  Vec3f( 4.0, 12.0, 4.0 );       
            lighting.directed_light.push_back(new PointLight( overhead_light_pos, 80.0f * Vec3f(1.0f, 1.0f, 1.0f) ));
            
            fill_light_pos = Vec3f( 0, 0, 1.2 * g_cam.dist );
            fill_light_pos = rotate( fill_light_pos, g_cam.pitch, Vec3f(1,0,0) );
            fill_light_pos = rotate( fill_light_pos, g_cam.heading, Vec3f(0,1,0) );
            fill_light_pos += Vec3f( g_cam.target[0], g_cam.target[1], g_cam.target[2] );
            lighting.directed_light.push_back(new PointLight( fill_light_pos, 200.0f * Vec3f(1.0f,1.0f,1.0f)));
            break;
            
         case THIN:
            
            //
            // THIN SMOKE
            //
            
            lighting.ambient = 0.3f * Vec3f(1.0f, 1.0f, 1.0f);
            
            overhead_light_pos =  Vec3f( 2.0, 16.0, 2.0 );       
            lighting.directed_light.push_back(new PointLight( overhead_light_pos, 60.0f * Vec3f(1.0f, 1.0f, 1.0f) ));
            
            fill_light_pos = Vec3f( 0, 0, 1.2 * g_cam.dist );
            fill_light_pos = rotate( fill_light_pos, g_cam.pitch, Vec3f(1,0,0) );
            fill_light_pos = rotate( fill_light_pos, g_cam.heading, Vec3f(0,1,0) );
            fill_light_pos += Vec3f( g_cam.target[0], g_cam.target[1], g_cam.target[2] );
            lighting.directed_light.push_back(new PointLight( fill_light_pos, 300.0f * Vec3f(1.0f,1.0f,1.0f)));
            break;
                     
         default:
            assert(0);
      }
            
      //Vec3f cam_dir = Vec3f( g_cam.target[0], g_cam.target[1], g_cam.target[2] ) - light_pos;
      //normalize(cam_dir);
      //lighting.directed_light.push_back(new DistantLight( cam_dir, 0.5f * Vec3f(1.0f,1.0f,1.0f)));
      
      // set up shapes
      MultiThing world;
      
      std::vector<unsigned int> surface_ids;
      std::vector< std::vector< unsigned int> > surfaces;
      g_surf->partition_surfaces( surface_ids, surfaces );
      
      std::vector<Vec3f> colors;
      colors.push_back( Vec3f(0.5f, 0.5f, 0.5f) );
      colors.push_back( Vec3f(0.1f, 0.8f, 0.1f) );
      colors.push_back( Vec3f(0.1f, 0.1f, 0.8f) );
      
      std::vector<TriangleMesh*> meshes;
      meshes.resize(surfaces.size());
      
      for ( unsigned int s = 0; s < surfaces.size(); ++s )
      { 
         meshes[s] = new TriangleMesh;
         
         for ( unsigned int t = 0; t < g_surf->m_mesh.m_tris.size(); ++t )
         {
            if ( surface_ids[ g_surf->m_mesh.m_tris[t][0] ] == s )
            {
               Vec3i new_tri( (int) g_surf->m_mesh.m_tris[t][0], (int) g_surf->m_mesh.m_tris[t][1], (int) g_surf->m_mesh.m_tris[t][2] );
               meshes[s]->tri.push_back( new_tri );   
            }
         }
         
         meshes[s]->x.resize( g_surf->m_positions.size() );
         
         for ( unsigned int v = 0; v < g_surf->m_positions.size(); ++v )
         {
            meshes[s]->x[v][0] = (float) g_surf->m_positions[v][0];
            meshes[s]->x[v][1] = (float) g_surf->m_positions[v][1];
            meshes[s]->x[v][2] = (float) g_surf->m_positions[v][2];            
         }
         
         if ( g_example_setup == FOG && g_volume_render )
         {
            // FOG:
            std::vector<Vec3d> new_vertices;
            std::vector<Vec3i> new_triangles;
            extend_open_surface( new_vertices, new_triangles );
               
            for ( unsigned int t = 0; t < new_triangles.size(); ++t )
            {
               meshes[s]->tri.push_back( new_triangles[t] );   
            }
            
            for ( unsigned int v = 0; v < new_vertices.size(); ++v )
            {
               meshes[s]->x.push_back( Vec3f( (float) new_vertices[v][0], (float) new_vertices[v][1], (float) new_vertices[v][2] ) );
            }
         }
         
         
         meshes[s]->build_tree();
         
         Shader* mesh_shader = 0;
         
         switch ( g_example_setup )
         {
            case FOG:
               if ( g_volume_render )
               {
                  mesh_shader = new ScatterShader( 6.0, 2.5, 1e-2 ); 
               }
               else
               {
                  mesh_shader = new DiffuseShader( Vec3f(0.4f, 0.4f, 0.4f) ); 
               }
               break;
               
            case THICK:
               if ( g_volume_render )
               {
                  mesh_shader = new ScatterShader( 7.0, 4.5, 1e-2, 0.02, 0.005 );
               }
               else
               {
                  mesh_shader = new DiffuseShader( Vec3f(0.6f) );
               }
               break;
               
            case THIN:
               if ( g_volume_render )
               {
                  mesh_shader = new ScatterShader( 1.5, 1.5, 1e-2 );
               }
               else
               {
                  mesh_shader = new DiffuseShader( Vec3f(0.75f) );
               }
               break;

               
         }
         
         StandardThing* mesh_thing = new StandardThing( *meshes[s], *mesh_shader );
         
         world.subthing.push_back( mesh_thing );
      }

      //
      // Ground
      //
      
      {
         Plane *plane=new Plane;
         plane->point = Vec3f( 0.0f, 0.0f, 0.0f );
         plane->plane_normal = Vec3f( 0.0f, 1.0f, 0.0f );
         DiffuseShader* plane_shader = new DiffuseShader( Vec3f( 0.85f, 0.8f, 0.5f) );
         //DiffuseShader* plane_shader = new DiffuseShader( Vec3f( 1.0f ) );
         StandardThing *plane_thing = new StandardThing( *plane, *plane_shader );
         world.subthing.push_back( plane_thing );
      }

      {
         Plane *plane=new Plane;
         plane->point = Vec3f( 0.0f, 0.0f, -20.0f );
         plane->plane_normal = Vec3f( 0.0f, 0.0f, 1.0f );
         DiffuseShader* plane_shader = new DiffuseShader( Vec3f( 0.85f, 0.8f, 0.5f) );
         //DiffuseShader* plane_shader = new DiffuseShader( Vec3f( 1.0f ) );
         StandardThing *plane_thing = new StandardThing( *plane, *plane_shader );
         world.subthing.push_back( plane_thing );
      }

//      {
//         Sphere* sphere = new Sphere( Vec3f(0,1,0), 0.5f );
//         DiffuseShader* sphere_shader = new DiffuseShader( Vec3f( 0.3f, 0.3f, 0.8f) );
//         StandardThing* sphere_thing = new StandardThing( *sphere, *sphere_shader );
//         world.subthing.push_back( sphere_thing );
//      }

      //
      // Glass box
      //
      /*
      {
         Plane *plane=new Plane;
         plane->point = Vec3f( -3.0f, 0.0f, 0.0f );
         plane->plane_normal = Vec3f( 1.0f, 0.0f, 0.0f );
         FresnelShader* glass_shader = new FresnelShader( 1.1f );         
         StandardThing *plane_thing = new StandardThing( *plane, *glass_shader );
         world.subthing.push_back( plane_thing );
      }
      {
         Plane *plane=new Plane;
         plane->point = Vec3f( -3.1f, 0.0f, 0.0f );
         plane->plane_normal = Vec3f( -1.0f, 0.0f, 0.0f );
         FresnelShader* glass_shader = new FresnelShader( 1.1f );         
         StandardThing *plane_thing = new StandardThing( *plane, *glass_shader );
         world.subthing.push_back( plane_thing );
      }
      {
         Plane *plane=new Plane;
         plane->point = Vec3f( 3.0f, 0.0f, 0.0f );
         plane->plane_normal = Vec3f( -1.0f, 0.0f, 0.0f );
         FresnelShader* glass_shader = new FresnelShader( 1.1f );         
         StandardThing *plane_thing = new StandardThing( *plane, *glass_shader );
         world.subthing.push_back( plane_thing );
      }
      {
         Plane *plane=new Plane;
         plane->point = Vec3f( 3.1f, 0.0f, 0.0f );
         plane->plane_normal = Vec3f( 1.0f, 0.0f, 0.0f );
         FresnelShader* glass_shader = new FresnelShader( 1.1f );         
         StandardThing *plane_thing = new StandardThing( *plane, *glass_shader );
         world.subthing.push_back( plane_thing );
      }
           
      {
         Aquarium *aq=new Aquarium( Vec3f(-3.15f, -0.15f, -3.15f), 
                                    Vec3f( 3.15,   3.15f,  3.15f), 
                                    Vec3f(-3.1f,  -0.1f,  -3.1f), 
                                    Vec3f( 3.1,    3.1f,   3.1f) );
         FresnelShader* aq_shader = new FresnelShader( 1.1f );
         StandardThing *aq_thing = new StandardThing( *aq, *aq_shader );
         world.subthing.push_back( aq_thing );  
       }
   
      {
         Box *box=new Box( Vec3f(-3.2f, -0.2f, -3.2f), Vec3f( 3.2, 4.2f, 3.2f) );
         FresnelShader* box_shader = new FresnelShader( 1.1f );
         StandardThing *box_thing = new StandardThing( *box, *box_shader );
         world.subthing.push_back( box_thing );  
      }
      {
         Box *box=new InvertedBox( Vec3f(-3.1f, -0.1f, -3.1f), Vec3f( 3.1, 4.1f, 3.1f) );
         FresnelShader* box_shader = new FresnelShader( 1.1f );
         StandardThing *box_thing = new StandardThing( *box, *box_shader );
         world.subthing.push_back( box_thing );  
      }
       
      */
      
      world.build_tree();
      
      // set up raytracer
      // (this has to come after lighting and world, since raytracer needs a reference to these objects)
      RayTracer raytracer( lighting, world, 1e-4, Vec3f(1,1,1) );
      
      // and finally set up the camera
      // (this has to come after raytracer, since the camera needs areference to it)
      Camera camera(raytracer);
      
      Transformation T0 = translate( Vec3f( 0, 0, -g_cam.dist ) );
      Transformation T1 = rotate_x( -180.0f/(float)M_PI*g_cam.pitch );
      Transformation T2 = rotate_y( -180.0f/(float)M_PI*g_cam.heading );
      Transformation T3 = translate( Vec3f( -g_cam.target[0],
                                           -g_cam.target[1], -g_cam.target[2] ) );
      camera.modelview = T0 * T1 * T2 * T3;
      
      camera.left = -0.5f;
      camera.right = 0.5f;
      camera.bottom = -0.33333333333333333333f;
      camera.top = 0.33333333333333333333f;
      
      // do the render
      Array2<Vec3f> image;
      camera.render_image(image, 2);
      
      // and save the output image
      write_sgi(image, sgi_filename);
      
      StandardThing* del = (StandardThing*) world.subthing[0];
      delete del;
      
      for ( unsigned int s = 0; s < meshes.size(); ++s )
      {
         delete meshes[s];
      }
      
      std::cout << "donezo!  Time spent rendering: " << get_time_in_seconds() - render_start_time << std::endl;
      
      g_rendering_snapshot = false;
   }
}

// ---------------------------------------------------------
///
/// Load a mesh in binary format, ray-trace using the current Gluvi camera settings, and output an sgi file.
///
// ---------------------------------------------------------

void bin2sgi()
{
   
   if ( !g_rendering_snapshot )
   {
      g_surf->m_positions.clear();
      g_surf->m_mesh.clear();
      
      char bin_filename[256];
      sprintf( bin_filename, "%s/frame%04d.bin", g_output_path, g_sim->m_curr_frame );      
      
      printf( "input filename: %s\n", bin_filename ); 
      
      bool good = read_binary_file( g_surf->m_mesh, g_surf->m_positions, g_surf->m_masses, g_sim->m_curr_t, bin_filename );
      
      if (!good)
      {
         g_rendering_series = false;
         return;
      }
      
      g_surf->m_mesh.clear_deleted_triangles();
      g_surf->m_mesh.update_connectivity( g_surf->m_positions.size() );   
      
      char sgi_filename[256];
      sprintf( sgi_filename, "%s/frame%04d.sgi", g_output_path, g_sim->m_curr_frame );      
      render_scene( sgi_filename );   
      
      g_sim->m_curr_frame += 1;
      
#ifdef USE_GUI
      glutPostRedisplay();
#endif
      
   }
   
}

#endif

// =========================================================
// GUI FUNCTIONS
// =========================================================

#ifdef USE_GUI

// ---------------------------------------------------------
///
/// Handle keyboard input
///
// ---------------------------------------------------------

void keyboard(unsigned char key, int, int )
{

   // TEMP: display options for fluid sim driver
   if ( key == 'f' )
   {
      g_fluid_render_type = ( g_fluid_render_type + 1 ) % g_fluid_render_type_max;
      std::cout << "g_fluid_render_type: " << g_fluid_render_type << std::endl;
   }
      
   if(key == 'q')
   {
      delete g_surf;
      delete g_driver;
      exit(0);
   }
   
   if ( key == 's' )
   {
      g_display_driver = !g_display_driver;
   }
   
   // run one frame
   // 
   if(key == 'n')
   {
      g_sim->m_running = true;
      advance_frame();
      g_sim->m_running = false;      
   }
   
   if ( key == 'e' )
   {
      g_render_edges = !g_render_edges;
   }
   
   if ( key == 't' )
   {
      g_render_fill_triangles = !g_render_fill_triangles;
   }
   
   if ( key == 'c' )
   {
      g_render_colliding_triangles = !g_render_colliding_triangles;
      if ( g_render_colliding_triangles )
      {
         g_intersecting_triangles.clear();
         g_surf->assert_mesh_is_intersection_free();
         std::cout << "num intersecting triangles: " << g_intersecting_triangles.size() << std::endl;
      }
   }
   
   if ( key == 'v' )
   {
      g_render_vertex_rank = !g_render_vertex_rank;
   }
   
   // run improvement sweep
   //
   if ( key == 'i' )
   {
      g_sim->m_currently_advancing_simulation = true;
      
      g_surf->improve_mesh();
      g_surf->rebuild_static_broad_phase();
      g_surf->trim_non_manifold();
      
      g_surf->rebuild_static_broad_phase();
      g_surf->assert_mesh_is_intersection_free();
      
      g_sim->m_currently_advancing_simulation = false;
   }
   
   // return to default camera
   //
   if ( key == 'r' )
   {
      g_cam.return_to_default();
   }
   
#ifdef RAY_TRACER
   
   // dump a render
   if ( key == 'a' )
   {
      char sgi_filename[256];
      sprintf( sgi_filename, "%s/frame%04d.sgi", g_output_path, g_sim->m_curr_frame );
      render_scene(sgi_filename);
   }
   
   // render a series
   if ( key == 'A' )
   {
      g_rendering_series = !g_rendering_series;
   }
   
   if ( key == 'z' )
   {
      g_example_setup = ( g_example_setup + 1 ) % 3;
      std::cout << "Render setup: " << g_example_setup;
      std::cout << ", g_volume_render: " << g_volume_render << std::endl;
   }

   if ( key == 'Z' )
   {
      g_volume_render = !g_volume_render;
      std::cout << "Render setup: " << g_example_setup;
      std::cout << ", g_volume_render: " << g_volume_render << std::endl;
   }
   
#endif

   // define default camera
   //
   if ( key == 'd' )
   {
      g_cam.default_target[0] = g_cam.target[0];
      g_cam.default_target[1] = g_cam.target[1];
      g_cam.default_target[2] = g_cam.target[2];      
      g_cam.default_dist = g_cam.dist;
      g_cam.default_heading = g_cam.heading;
      g_cam.default_pitch = g_cam.pitch;   
      
      std::cout << "cam_target " << g_cam.default_target[0] << " " <<  g_cam.default_target[1] << " " << g_cam.default_target[2] << std::endl;
      std::cout << "cam_distance " << g_cam.default_dist << std::endl;
      std::cout << "cam_heading " << g_cam.default_heading << std::endl;
      std::cout << "cam_pitch " << g_cam.default_pitch << std::endl;
   }

   if ( key == 'l' )
   {
      g_smooth_shading = !g_smooth_shading;
   }
   
   /*
   // add a point light with shadows using current camera properties
   //
   if ( key == 'l' )
   {
      Gluvi::Target3D newCam;
      newCam.target[0] = g_cam.target[0]; newCam.target[1] =  g_cam.target[1]; newCam.target[2] = g_cam.target[2];
      newCam.dist = g_cam.dist;
      newCam.heading = g_cam.heading;
      newCam.pitch = g_cam.pitch;
      newCam.fovy = g_cam.fovy;
      newCam.near_clip_factor = g_cam.near_clip_factor;
      newCam.far_clip_factor = g_cam.far_clip_factor;

      //lights.push_back( newCam );
      
      // compute location of light
      Vec3f light_pos( 0, 0, newCam.dist );
      light_pos = rotate( light_pos, newCam.pitch, Vec3f(1,0,0) );
      light_pos = rotate( light_pos, newCam.heading, Vec3f(0,1,0) );
      light_pos += Vec3f( newCam.target[0], newCam.target[1], newCam.target[2] );
      
      std::cout << "light position: " << light_pos << std::endl;
      
   }
    */
   
   // output binary file
   //
   if(key == 'b')
   {
      char binary_filename[256];
      sprintf( binary_filename, "%s/frame%04d.bin", g_output_path, g_sim->m_curr_frame );      
      write_binary_file( g_surf->m_mesh, g_surf->m_positions, g_surf->m_masses, g_sim->m_curr_t, binary_filename );   
      std::cout << "binary file written" << std::endl;      
   }
   
   // output OBJ file
   //
   if(key == 'o')
   {
      char obj_filename[256];
      sprintf( obj_filename, "%s/frame%04d.obj", g_output_path, g_sim->m_curr_frame );
      write_objfile( g_surf->m_mesh, g_surf->m_positions, obj_filename );
      std::cout << "obj file written" << std::endl;
   }
   
   // PPM screenshot
   //
   if(key == 'p')
   {
      char ppm_filename[256];
      sprintf( ppm_filename, "%s/frame%04d.ppm", g_output_path, g_sim->m_curr_frame );      
      Gluvi::ppm_screenshot( ppm_filename );
      std::cout << "ppm screen shot taken" << std::endl;
   }


   // PPM screenshots for a sequence of bin files
   //
   if(key == 'P')
   {
      g_making_animation = true;
      
      g_sim->m_curr_frame = 0;
      g_surf->m_positions.clear();
      g_surf->m_mesh.clear();
      
      char bin_filename[256];
      sprintf( bin_filename, "%s/frame%04d.bin", g_output_path, g_sim->m_curr_frame );            
      std::cout << "loading " << bin_filename << std::endl;
      bool good = read_binary_file( g_surf->m_mesh, g_surf->m_positions, g_surf->m_masses, g_sim->m_curr_t, bin_filename );
      
      if (!good)
      {
         g_making_animation = false;
      }
      
      g_surf->m_mesh.clear_deleted_triangles();
      g_surf->m_mesh.update_connectivity( g_surf->m_positions.size() );   
      
      glutPostRedisplay();
      
   }
   
   // toggle simulation
   //
   if(key == ' ')
   {
      g_sim->m_running = !g_sim->m_running;
      std::cout << "running: " << (g_sim->m_running ? "yes" : "no") << std::endl;
      
      if ( !g_sim->m_running )
      {
         display_stats();
      }
   }
   
   glutPostRedisplay();
   
}


// ---------------------------------------------------------
///
/// Handle mouse click
///
// ---------------------------------------------------------

void mouse(int button, int state, int x, int y)
{
   if ( glutGetModifiers() == GLUT_ACTIVE_ALT )
   {
      g_selected_vertex = g_selected_edge = g_selected_triangle = -1;
      
      g_cam.transform_mouse( x, y, g_ray_origin, g_ray_direction );
      
      unsigned int hit_index;
      
      unsigned int ray_cast_type;
      if ( button==GLUT_LEFT_BUTTON ) { ray_cast_type = 0; }
      else if ( button==GLUT_MIDDLE_BUTTON ) { ray_cast_type = 1; }
      else { ray_cast_type = 2; }
      
      unsigned int ray_hit_type = g_surf->ray_cast( Vec3f( g_ray_origin ), Vec3f( g_ray_direction ), ray_cast_type, hit_index );
      
      switch (ray_hit_type)
      {
         case SurfTrack::RAY_HIT_VERTEX:
            g_selected_vertex = hit_index;
            break;
         case SurfTrack::RAY_HIT_EDGE:
            g_selected_edge = hit_index;
            break;
         case SurfTrack::RAY_HIT_TRIANGLE:
            g_selected_triangle = hit_index;      
            break;
         default:
            assert( ray_hit_type == SurfTrack::RAY_HIT_NOTHING );
            break;
      }
      
      glutPostRedisplay();
      return;
   }
   
   g_cam.click(button, state, x, y);
}

// ---------------------------------------------------------
///
/// Handle mouse motion
///
// ---------------------------------------------------------

void mouseMotion(int x, int y)
{
   g_cam.drag(x, y);
}


// ---------------------------------------------------------
///
/// Advance simulation with GUI
///
// ---------------------------------------------------------

void advance_frame()
{
   
   if(!g_sim->m_currently_advancing_simulation)
   {
      g_sim->m_currently_advancing_simulation = true;
      
      if ( g_sim->m_curr_frame == 0 )
      {
         // output initial conditions
         char ppm_filename[256];
         sprintf( ppm_filename, "%s/frame%04d.ppm", g_output_path, g_sim->m_curr_frame );      
         Gluvi::ppm_screenshot( ppm_filename );         
      }
      
      advance_sim();
      
      glutPostRedisplay();
      
      char ppm_filename[256];
      sprintf( ppm_filename, "%s/frame%04d.ppm", g_output_path, g_sim->m_curr_frame );      
      Gluvi::ppm_screenshot( ppm_filename );
      
      if ( g_render_colliding_triangles )
      {
         if ( g_surf->m_collision_safety )
         {
            g_surf->assert_mesh_is_intersection_free();
         }
            
         glutPostRedisplay();
      }
            
      g_sim->m_currently_advancing_simulation = false;

   }

}

// ---------------------------------------------------------
///
/// Load a mesh in binary format, and take a PPM screenshot
///
// ---------------------------------------------------------

void bin2ppm()
{

   g_surf->m_positions.clear();
   g_surf->m_mesh.clear();

   char bin_filename[256];
   sprintf( bin_filename, "%s/frame%04d.bin", g_output_path, g_sim->m_curr_frame );      
   
   printf( "input filename: %s\n", bin_filename ); 
   
   bool good = read_binary_file( g_surf->m_mesh, g_surf->m_positions, g_surf->m_masses, g_sim->m_curr_t, bin_filename );

   if (!good)
   {
      g_making_animation = false;
      return;
   }
   
   g_surf->m_mesh.clear_deleted_triangles();
   g_surf->m_mesh.update_connectivity( g_surf->m_positions.size() );   
   
   glutPostRedisplay();
   
   char ppm_filename[256];
   sprintf( ppm_filename, "%s/frame%04d.ppm", g_output_path, g_sim->m_curr_frame );      
   Gluvi::ppm_screenshot( ppm_filename );     
   
   ++g_sim->m_curr_frame;
   
}

// ---------------------------------------------------------
///
/// Render to the OpenGL GUI.  Rendering the triangle surface is handled by SurfTrack::render
///
// ---------------------------------------------------------

void display(void)
{
   Gluvi::set_generic_lights();

   unsigned int options = 0;
   if ( g_render_edges ) { options |= SurfTrack::RENDER_EDGES; }
   if ( g_render_fill_triangles ) { options |= SurfTrack::RENDER_TRIANGLES; }
   if ( g_render_vertex_rank ) { options |= SurfTrack::RENDER_VERTEX_DATA; }
   if ( g_render_colliding_triangles ) { options |= SurfTrack::RENDER_COLLIDING_TRIANGLES; }
   if ( !g_smooth_shading ) { options |= SurfTrack::NO_SHADING; }
   
   
   options |= SurfTrack::TWO_SIDED;
   
   g_surf->render( options );

   if ( g_display_driver )
   {
      g_driver->display(*g_surf);
   }
   
   glDisable(GL_LIGHTING);
   
   if ( g_selected_vertex >= 0 )
   {
      glPointSize( 3.0f );
      glBegin(GL_POINTS);
      Vec3d& vtx0 = g_surf->m_positions[g_selected_vertex];
      glVertex3dv(vtx0.v);
      glEnd();      
   }
   
   if ( g_selected_edge >= 0 )
   {
      glBegin(GL_LINES);
      Vec2ui& edge = g_surf->m_mesh.m_edges[g_selected_edge];
      Vec3d& vtx0 = g_surf->m_positions[edge[0]];
      Vec3d& vtx1 = g_surf->m_positions[edge[1]];
      glVertex3dv(vtx0.v);
      glVertex3dv(vtx1.v);
      glEnd();
   }
   
   if ( g_selected_triangle >= 0 )
   {
      glBegin(GL_TRIANGLES);
      Vec3ui& triangle = g_surf->m_mesh.m_tris[g_selected_triangle];
      Vec3d& vtx0 = g_surf->m_positions[triangle[0]];
      Vec3d& vtx1 = g_surf->m_positions[triangle[1]];
      Vec3d& vtx2 = g_surf->m_positions[triangle[2]];
      glVertex3dv(vtx0.v);
      glVertex3dv(vtx1.v);
      glVertex3dv(vtx2.v);
      glEnd();      
   }
   
   glEnable(GL_LIGHTING);


   // check if we're running something
   
   if( g_sim->m_running )
   {
      advance_frame();
   }
   
   if ( g_making_animation )
   {
      bin2ppm();
   }
       
#ifdef RAY_TRACER
   if ( g_rendering_series )
   {
      bin2sgi();
   }
#endif
   
}


// ---------------------------------------------------------
///
/// Initialize the OpenGL GUI
///
// ---------------------------------------------------------

void init_gui( int argc, char **argv )
{
   Gluvi::init("Talpa", &argc, argv);
      
   g_render_fill_triangles = true;
   g_render_colliding_triangles = false;
 
   glClearColor(1,1,1,0);
   Gluvi::camera=&g_cam;
   
   // default
   g_cam.target[0] = 0.0f;
   g_cam.target[1] = 0.0f;
   g_cam.target[2] = 0.0f;
   g_cam.dist = 10.0f;
   g_cam.heading = 0.0f;
   
   std::ifstream file( argv[1] );
   parse_gui_script( file, g_cam.target, g_cam.dist, g_cam.heading, g_cam.pitch );

   keyboard( 'd', 0, 0 );  // set to default

   Gluvi::userDisplayFunc=display;
   
   glutKeyboardFunc(keyboard);
   glutMouseFunc(mouse);
   glutMotionFunc(mouseMotion);
}

#endif  // #ifdef USE_GUI


// ---------------------------------------------------------
///
/// Initialize the simulation.  Set the simulation parameters, initial geometry, etc.
///
// ---------------------------------------------------------

void init_simulation( int argc, char **argv )
{
   assert( argc > 1 );
      
   SurfTrackInitializationParameters init_params;

   std::vector<Vec3ui> tris;
   std::vector<Vec3d> verts;
   std::vector<Vec3d> velocities;
   std::vector<double> masses;
   
   std::cout << "parsing script: " << argv[1] << std::endl;
   std::ifstream file( argv[1] );
   assert( file.good() );
   parse_script( file, g_driver, g_sim, tris, verts, velocities, masses, init_params );
        
   if ( masses.size() != verts.size() )
   {
      masses.resize( verts.size(), 1.0 );
   }
   
   g_surf = new SurfTrack( verts, tris, masses, init_params );   

   std::cout << "initial t: " << g_sim->m_curr_t << std::endl;
   
   g_surf->m_mesh.clear_deleted_triangles();
   g_surf->m_mesh.update_connectivity( g_surf->m_positions.size() );   
   g_surf->clear_deleted_vertices();
   g_surf->m_mesh.update_connectivity( g_surf->m_positions.size() );   
   
   g_surf->trim_non_manifold();
   g_surf->m_mesh.update_connectivity( g_surf->m_positions.size() );

   
   g_driver->initialize( *g_surf );
   
   if ( velocities.size() == verts.size() )
   {
      g_surf->m_velocities = velocities;      
   }
   
   g_surf->rebuild_static_broad_phase();      
   
   if ( g_surf->m_collision_safety )
   {
      g_surf->assert_mesh_is_intersection_free();      
   }
   
   std::cout << "max_edge_length " << g_surf->m_max_edge_length << std::endl;
   std::cout << "min_edge_length " << g_surf->m_min_edge_length << std::endl;
   std::cout << "max_volume_change " << g_surf->m_max_volume_change << std::endl;
   
   //
   // Initialize profiling and statistics variables
   //
   
   g_min_num_triangles = g_surf->m_mesh.m_tris.size();
   g_max_num_triangles = g_surf->m_mesh.m_tris.size();
   g_total_num_triangles = 0;
   g_min_num_vertices = g_surf->m_positions.size();
   g_max_num_vertices = g_surf->m_positions.size();
               
   g_total_sim_time = 0;
   g_total_collision_time = 0;
   g_total_topology_time = 0;
   g_total_improvement_time = 0;
   g_total_driver_time = 0;
   
   g_total_steps = 0;
   
   set_time_base();
      
}

// ---------------------------------------------------------
///
/// MAIN
///
// ---------------------------------------------------------

int main(int argc, char **argv)
{   
   std::cout << "Talpa: Demo applications of El Topo" << std::endl;
   std::cout << "-----------------------------------" << std::endl << std::endl;

   if( argc < 2 )
   {
      std::cout << "Usage: <executable> <scriptfile> <outputdirectory>" << std::endl;
      std::cout << "e.g.: " << std::endl;
      std::cout << "$ ./talpa_release curlnoise-parameters.txt /var/tmp/" << std::endl;
      return 0;
   }
        
   // set path for outputting obj, bin files, etc.
   
   if ( argc > 2 )
   {
      strcpy( g_output_path, argv[2] );
   }
   else
   {
      // argc == 2
      strcpy( g_output_path, "." );
   }
     
   printf("Output path: %s\n", g_output_path );

   
   
   //
   // Initialize the simulation using the script file
   //
   
   init_simulation( argc, argv );

#ifdef USE_GUI
   
   //
   // Initialize the GUI using the script file
   //
   
   init_gui( argc, argv );
   
#endif
   
   srand( time(NULL) );
   
   // write frame 0
   char binary_filename[256];
   sprintf( binary_filename, "%s/frame%04d.bin", g_output_path, g_sim->m_curr_frame );      
   write_binary_file( g_surf->m_mesh, g_surf->m_positions, g_surf->m_masses, g_sim->m_curr_t, binary_filename );   
   
   //
   // Now start
   //
   
#ifdef USE_GUI
   // start the GUI
   Gluvi::run();
#else

   // default
   std::ifstream file( argv[1] );
   parse_gui_script( file, g_cam.target, g_cam.dist, g_cam.heading, g_cam.pitch );

   if ( argc == 4 )
   {
      g_example_setup = atoi( argv[3] );
      std::cout << "g_example_setup: " << g_example_setup << std::endl;
   }
   
   //while(1) { bin2sgi(); }
      
   // start the simulation (hands off)
   run_simulation();
   
   // uncomment to run all examples in our SISC paper:
   //run_all_sisc_examples( "./sisc-scripts/" );
   
#endif
   
   return 0;
}



