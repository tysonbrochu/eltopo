// ---------------------------------------------------------
//
//  Tyson Brochu 2009
//  
//
//  
//
// ---------------------------------------------------------

// ---------------------------------------------------------
// Includes
// ---------------------------------------------------------

#include <gridsmoke.h>
#include <makelevelset3.h>
#include <dynamicsurface.h>
#include <sparse_matrix.h>
#include <krylov_solvers.h>

#include <curlnoise.h>

// ---------------------------------------------------------
// Global externs
// ---------------------------------------------------------

// ---------------------------------------------------------
// Local constants, typedefs, macros
// ---------------------------------------------------------

// ---------------------------------------------------------
// Static function definitions
// ---------------------------------------------------------

// ---------------------------------------------------------
// Member function definitions
// ---------------------------------------------------------

GridSmokeSim::GridSmokeSim( const Vec3d& grid_origin, const Vec3d& grid_high_bound, double grid_dx, double in_gravity ) :
   GridFluidSim( grid_origin, grid_high_bound, grid_dx, in_gravity )
{
   m_temperature.resize( m_fluid_phi.ni, m_fluid_phi.nj, m_fluid_phi.nk );
}


void GridSmokeSim::initialize( const DynamicSurface& surf )
{
}

void GridSmokeSim::compute_signed_distance( const DynamicSurface& surf )
{
   for ( unsigned int i = 0; i < m_fluid_phi.a.n; ++i )
   {
      m_fluid_phi.a[i] = -1.0;
   }

}


void GridSmokeSim::apply_forces( const DynamicSurface& surf, double dt )
{
   
   std::cout << "making level set... ";
   
   // use inside-outside as discontinuous temperature field
   make_level_set3( surf.m_mesh.m_tris, 
                    surf.m_positions, 
                    m_phi_grid.origin, 
                    m_phi_grid.dx, 
                    m_temperature.ni, 
                    m_temperature.nj, 
                    m_temperature.nk, 
                    m_temperature, 
                    m_closest_tris );
   
   std::cout << "done" << std::endl;
   
   // apply bouyancy
   for ( int i = 0; i < m_sim_v.ni; ++i )
   {
      for ( int j = 1; j < m_sim_v.nj-1; ++j )
      {
         for ( int k = 0; k < m_sim_v.nk; ++ k )
         {
            double temperature = lerp( m_temperature(i,j-1,k), m_temperature(i,j,k), 0.5f );
            
            if ( temperature < m_phi_grid.dx )
            {
               m_sim_v(i,j,k) += dt * (-m_gravity);
            }
         }
      }
   }
   
}


Vec3d SmokeCurlNoise::potential(double x, double y, double z) const
{
   std::vector<double> noise_lengthscale(1);
   noise_lengthscale[0] = 0.12;
   
   std::vector<double> noise_gain(1);
   noise_gain[0] = 0.03;
   
   Vec3d psi(0,0,0);
   
   for ( unsigned int i = 0; i < noise_lengthscale.size(); ++i )
   {
      double sx=x/noise_lengthscale[i];
      double sy=y/noise_lengthscale[i];
      double sz=z/noise_lengthscale[i];
      
      Vec3d psi_i(noise0(sx,sy,sz), noise1(sx,sy,sz), noise2(sx,sy,sz));
      psi += noise_gain[i] * psi_i;
   }
   
   return psi;
}
   
void GridSmokeSim::addCurlNoise( const DynamicSurface& surf, std::vector<Vec3d>& out_velocity )
{
   for ( unsigned int i = 0; i < surf.m_positions.size(); ++i )
   {
      Vec3d v;
      m_curl_noise.get_velocity( surf.m_positions[i], v );
      out_velocity[i] += 0.1 * v;
   }
}


void GridSmokeSim::set_surface_velocity( const DynamicSurface& surf, 
                                        std::vector<Vec3d>& out_velocity, 
                                        double current_t, 
                                        double& adaptive_dt )
{
   
   std::cout << " -------------- smoke sim update -------------------- " << std::endl;

   if ( current_t > 0.5 )
   {
      //GridFluidSim::set_surface_velocity( surf, out_velocity, current_t, adaptive_dt );
   }
   
   m_curl_noise.noise.set_time( current_t );
   m_curl_noise.advance_time( adaptive_dt );
   
   addCurlNoise( surf, out_velocity );
   
//   const Vec3d c( 0.5, 0.5, 0.5 );
//   const double r = 0.5;
//   for ( unsigned int i = 0; i < surf.m_positions.size(); ++i )
//   {    
//      const Vec3d& p = surf.m_positions[i];
//      double d = dist( p, c );
//      if ( d < r )
//      {
//         double scale = 0.15;
//         double gain = 0.3;
//         
//         double sx=p[0]/scale;
//         double sy=p[1]/scale;
//         double sz=p[2]/scale;
//         
//         double noise_factor = gain * (m_curl_noise.noise0( sx, sy, sz ) + 0.5);
//         
//         out_velocity[i] += noise_factor * ((r - d) * (surf.m_positions[i] - c) / d); // / adaptive_dt;
//      }
//   }
//         
}

