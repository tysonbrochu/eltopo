
// ---------------------------------------------------------
//
//  cloth.h
//  Tyson Brochu 2009
//
//  Cloth simulated using springs along edges
//
// ---------------------------------------------------------

#ifndef CLOTH_H
#define CLOTH_H

// ---------------------------------------------------------
//  Nested includes
// ---------------------------------------------------------

#include <meshdriver.h>

// ---------------------------------------------------------
//  Forwards and typedefs
// ---------------------------------------------------------

class DynamicSurface;
struct SparseMatrixDynamicCSR;
class NonDestructiveTriMesh;

// ---------------------------------------------------------
//  Interface declarations
// ---------------------------------------------------------

struct Spring
{
   unsigned int vertex_a;
   unsigned int vertex_b;
   double rest_length;
   double spring_constant;   
   double damping_constant;      
};

class ClothDriver : public MeshDriver
{
   
public:

   unsigned int nx;          // num vertices in one dimension
   unsigned int ny;          // num vertices in one dimension
   unsigned int num_sheets;  // num cloth sheets
   
   std::vector<Spring> springs;
   std::vector<unsigned int> constrained_vertices;
      
   ClothDriver( unsigned int _nx, unsigned int _ny, unsigned int _ns ) : nx(_nx), ny(_ny), num_sheets(_ns), springs(0), constrained_vertices(0) {}
        
   void initialize( const DynamicSurface& surf );

   void display( const DynamicSurface& surf );
         
   void compute_edge_spring_forces( const DynamicSurface& surf, std::vector<Vec3d>& forces );
   
   void strain_limiting_impulses( const DynamicSurface& surf, std::vector<Vec3d>& velocities, double dt );
   
   void set_surface_velocity( const DynamicSurface& surf, std::vector<Vec3d>& out_velocity, double current_t, double& adaptive_dt );      
   
   void compute_error( const DynamicSurface& surf, double current_t ) {}
   
   void write_springs_to_file( const char* filename );
   
   void read_springs_from_file( const char* filename );
   
};

// ---------------------------------------------------------
//  Inline functions
// ---------------------------------------------------------


#endif
