// ---------------------------------------------------------
//
//  flowprimitives.cpp
//  Tyson Brochu 2009
//
//  A set of procedural flow primitives
//
// ---------------------------------------------------------

#include <flowprimitives.h>
#include <gluvi.h>

// ---------------------------------------------------------

void VortexRing::render( )
{
   static const unsigned int num_verts = 20;
   
   glColor3f( 0.0f, 0.0f, 0.0f );
   glBegin(GL_LINE_LOOP);
   for ( unsigned int i = 0; i <= num_verts; ++i )
   {
      double theta = 2.0 * M_PI * double (i) / double (num_verts);
      double x = m_centre[0] + m_radius * cos(theta);
      double y = m_centre[1];
      double z = m_centre[2] + m_radius * sin(theta);
      glVertex3d( x, y, z );
   }
   glEnd();
   
}


// ---------------------------------------------------------

Vec3d VortexParticle::potential( double x, double y, double z )
{

   double rmag = max( 0.0, 1.0 - dist( Vec3d(x,y,z), m_centre ) );      
   
   Vec3d rpsi = rmag * m_magnitude * m_orientation;
   
   return rpsi;  
}

// ---------------------------------------------------------

void VortexParticle::apply( const Vec3d& x, Vec3d& v )
{
   v[0] += ( (potential(x[0], x[1]+m_dx, x[2])[2] - potential(x[0], x[1]-m_dx, x[2])[2])
            -(potential(x[0], x[1], x[2]+m_dx)[1] - potential(x[0], x[1], x[2]-m_dx)[1]) ) / (2*m_dx);
   v[1] += ( (potential(x[0], x[1], x[2]+m_dx)[0] - potential(x[0], x[1], x[2]-m_dx)[0])
            -(potential(x[0]+m_dx, x[1], x[2])[2] - potential(x[0]-m_dx, x[1], x[2])[2]) ) / (2*m_dx);
   v[2] += ( (potential(x[0]+m_dx, x[1], x[2])[1] - potential(x[0]-m_dx, x[1], x[2])[1])
            -(potential(x[0], x[1]+m_dx, x[2])[0] - potential(x[0], x[1]-m_dx, x[2])[0]) ) / (2*m_dx);
}

// ---------------------------------------------------------
// ---------------------------------------------------------
// ---------------------------------------------------------


// ---------------------------------------------------------

Vec3d VortexRing::potential( double x, double y, double z )
{
//   double ry = y - m_centre[1];
//   double rr = std::sqrt( (x - m_centre[0])*(x - m_centre[0]) + (z - m_centre[2])*(z - m_centre[2]) );
   
   double r = dist( Vec3d(x,y,z), m_centre );  
   double denom = ((m_radius - r) * (m_radius - r) + 2 * m_radius * r);
   
   double rmag = 0.5 / denom;
   
   Vec3d rpsi = rmag * m_magnitude * Vec3d(z, 0, -x);
   
   return rpsi;  
}

// ---------------------------------------------------------

void VortexRing::apply( const Vec3d& x, Vec3d& v )
{
   v[0] += ( (potential(x[0], x[1]+m_dx, x[2])[2] - potential(x[0], x[1]-m_dx, x[2])[2])
            -(potential(x[0], x[1], x[2]+m_dx)[1] - potential(x[0], x[1], x[2]-m_dx)[1]) ) / (2*m_dx);
   v[1] += ( (potential(x[0], x[1], x[2]+m_dx)[0] - potential(x[0], x[1], x[2]-m_dx)[0])
            -(potential(x[0]+m_dx, x[1], x[2])[2] - potential(x[0]-m_dx, x[1], x[2])[2]) ) / (2*m_dx);
   v[2] += ( (potential(x[0]+m_dx, x[1], x[2])[1] - potential(x[0]-m_dx, x[1], x[2])[1])
            -(potential(x[0], x[1]+m_dx, x[2])[0] - potential(x[0], x[1]-m_dx, x[2])[0]) ) / (2*m_dx);
}

// ---------------------------------------------------------
// ---------------------------------------------------------
// ---------------------------------------------------------


// ---------------------------------------------------------

static double modulate( double t, double period )
{
   double quarter_period = 0.25 * period;
   double rem = t / period - floor(t/period);
   if ( rem < quarter_period )
   {
      double theta = 2.0 * M_PI * t / period;
      return 0.5 + 0.5 * max( 0.0, cos(theta) );
   }
   return 0.5;
}

// ---------------------------------------------------------

void DivergenceSource::update( double dt )
{
   m_velocity[0] = apply_clamped_dot( m_velocity[0], dt, m_clamped_acceleration[0] );
   m_velocity[1] = apply_clamped_dot( m_velocity[1], dt, m_clamped_acceleration[1] );
   m_velocity[2] = apply_clamped_dot( m_velocity[2], dt, m_clamped_acceleration[2] );
   
   std::cout << "source y-velocity: " << m_velocity[1] << std::endl;
   
   m_centre += dt * m_velocity;
   m_radius = max( 0.0, m_radius + dt * m_radius_dot );
   m_magnitude = apply_clamped_dot( m_magnitude, dt, m_magnitude_clamped_dot );
   m_lengthscale = max( 0.0, m_lengthscale + dt * m_lengthscale_dot );
   //m_noise.set_time( m_time );
   m_time += dt;
}

// ---------------------------------------------------------

void DivergenceSource::apply( const Vec3d& x, Vec3d& v )
{
   double dist_to_source = mag( x - m_centre );

   double mod = 1.0; //modulate( m_time, 10.0 );
   double rad = mod * m_radius;

   if ( dist_to_source < rad )
   {  
      double sx=x[0]/m_lengthscale;
      double sy=x[1]/m_lengthscale;
      double sz=x[2]/m_lengthscale;
      
      double min_noise = 0.0;
      double max_noise = 1.5;
      double noise01 = (m_noise( sx, sy, sz ) + 1.0) / 2.0;
      
      assert( noise01 >= 0.0 );
      assert( noise01 <= 1.0 );
      
      double noise_factor = m_magnitude * ( noise01 * (max_noise - min_noise) + min_noise );
      double falloff_factor = ( rad - dist_to_source ) / rad;
      noise_factor *= falloff_factor * falloff_factor * falloff_factor;
      
      v += noise_factor * ( x - m_centre ) / dist_to_source;
      
   }   
   
}

// ---------------------------------------------------------

void DivergenceSource::render()
{
   glColor3f( 1.0f, 0.0f, 0.0f );
   glBegin(GL_POINTS);
   glVertex3dv( m_centre.v );
   glEnd();
}

// ---------------------------------------------------------
// ---------------------------------------------------------
// ---------------------------------------------------------


void NoiseOctave::update( double dt )
{
   m_noise.set_time( m_time );
   m_time += dt;
}

Vec3d NoiseOctave::potential( double x, double y, double z )
{

   double sx=x/m_lengthscale;
   double sy=y/m_lengthscale;
   double sz=z/m_lengthscale;
   
   Vec3d psi_i(noise0(sx,sy,sz), noise1(sx,sy,sz), noise2(sx,sy,sz));
      
   return m_magnitude * psi_i;
   
}

// ---------------------------------------------------------

void NoiseOctave::apply( const Vec3d& x, Vec3d& v )
{
   v[0] += ( (potential(x[0], x[1]+m_dx, x[2])[2] - potential(x[0], x[1]-m_dx, x[2])[2])
            -(potential(x[0], x[1], x[2]+m_dx)[1] - potential(x[0], x[1], x[2]-m_dx)[1]) ) / (2*m_dx);
   v[1] += ( (potential(x[0], x[1], x[2]+m_dx)[0] - potential(x[0], x[1], x[2]-m_dx)[0])
            -(potential(x[0]+m_dx, x[1], x[2])[2] - potential(x[0]-m_dx, x[1], x[2])[2]) ) / (2*m_dx);
   v[2] += ( (potential(x[0]+m_dx, x[1], x[2])[1] - potential(x[0]-m_dx, x[1], x[2])[1])
            -(potential(x[0], x[1]+m_dx, x[2])[0] - potential(x[0], x[1]-m_dx, x[2])[0]) ) / (2*m_dx);   
}



// ---------------------------------------------------------


// ---------------------------------------------------------
// ---------------------------------------------------------
// ---------------------------------------------------------


void CentredNoise::update( double dt )
{
   NoiseOctave::update(dt);
   
   m_velocity += dt * m_acceleration;
   m_centre += dt * m_velocity;
   
   m_radius += dt * m_radius_dot;
   m_magnitude = max( 0.0, m_magnitude + dt * m_magnitude_dot );
   m_lengthscale = max( 0.0, m_magnitude + dt * m_lengthscale_dot );
}

// ---------------------------------------------------------

Vec3d CentredNoise::potential( double x, double y, double z )
{
   double r = dist( Vec3d(x,y,z), m_centre );
   double falloff = max( 0.0, ( m_radius - r ) / m_radius );
   
   double sx=x/m_lengthscale;
   double sy=y/m_lengthscale;
   double sz=z/m_lengthscale;
   
   Vec3d psi_i(noise0(sx,sy,sz), noise1(sx,sy,sz), noise2(sx,sy,sz));
   
   return falloff * m_magnitude * psi_i;
}

// ---------------------------------------------------------

void CentredNoise::apply( const Vec3d& x, Vec3d& v )
{
   v[0] += ( (potential(x[0], x[1]+m_dx, x[2])[2] - potential(x[0], x[1]-m_dx, x[2])[2])
            -(potential(x[0], x[1], x[2]+m_dx)[1] - potential(x[0], x[1], x[2]-m_dx)[1]) ) / (2*m_dx);
   v[1] += ( (potential(x[0], x[1], x[2]+m_dx)[0] - potential(x[0], x[1], x[2]-m_dx)[0])
            -(potential(x[0]+m_dx, x[1], x[2])[2] - potential(x[0]-m_dx, x[1], x[2])[2]) ) / (2*m_dx);
   v[2] += ( (potential(x[0]+m_dx, x[1], x[2])[1] - potential(x[0]-m_dx, x[1], x[2])[1])
            -(potential(x[0], x[1]+m_dx, x[2])[0] - potential(x[0], x[1]-m_dx, x[2])[0]) ) / (2*m_dx);   
}


// ---------------------------------------------------------


