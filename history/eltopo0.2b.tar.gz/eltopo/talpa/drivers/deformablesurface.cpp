// ---------------------------------------------------------
//
//  Tyson Brochu 2009
//
// ---------------------------------------------------------

// ---------------------------------------------------------
// Includes
// ---------------------------------------------------------

#include <deformablesurface.h>
#include <broadphase.h>
#include <cmath>
#include <dynamicsurface.h>

// ---------------------------------------------------------
// Global externs
// ---------------------------------------------------------

// ---------------------------------------------------------
// Local constants, typedefs, macros
// ---------------------------------------------------------

// ---------------------------------------------------------
// Static function definitions
// ---------------------------------------------------------


// ---------------------------------------------------------
// Member function definitions
// ---------------------------------------------------------

void DeformableSurface::get_volume_triangles( const DynamicSurface& surf, unsigned int volume_id, std::vector<unsigned int>& volume_triangles )
{

   volume_triangles.clear();
   
   const std::vector<unsigned int>& volume_verts = m_current_volumes[volume_id];

   for ( unsigned int i = 0; i < volume_verts.size(); ++i )
   {
      const std::vector<unsigned int>& inc_tris = surf.m_mesh.m_vtxtri[ volume_verts[i] ];
      for ( unsigned int j = 0; j < inc_tris.size(); ++j )
      {
         add_unique( volume_triangles, inc_tris[j] );
      }
   }
   
}

double DeformableSurface::get_surface_area( const DynamicSurface& surf, const std::vector<unsigned int>& volume_triangles, const std::vector<Vec3d>& positions  )
{
   double area = 0;
   
   for(unsigned int t=0; t < volume_triangles.size(); ++t )
   {
      const Vec3ui tri = surf.m_mesh.m_tris[ volume_triangles[t] ];
      
      if ( tri[0] == tri[1] ) { continue; }

      area += 0.5 * mag( cross( positions[tri[1]] - positions[tri[0]], positions[tri[2]] - positions[tri[0]] ) );
   }
   
   return area;
}

double DeformableSurface::get_volume( const DynamicSurface& surf, const std::vector<unsigned int>& volume_triangles, const std::vector<Vec3d> positions )
{
   
   static const double inv_six = 1.0/6.0;
   double volume=0;
   for(unsigned int i=0; i < volume_triangles.size(); ++i )
   {
      unsigned int t = volume_triangles[i];
      const Vec3ui& tri = surf.m_mesh.m_tris[t];

      if ( tri[0] == tri[1] ) { continue; }
      
      volume += inv_six * triple( positions[tri[0]], positions[tri[1]], positions[tri[2]] );
   }
   return volume;
}


void DeformableSurface::initialize( const DynamicSurface& surf )
{
   surface_tension_coefficient = 1e+4;
   spring_coefficient = 0.0;
   volume_preserving_coefficient = 10.0;
   gravity_constant = -9.8;
   
   edge_rest_length = surf.get_average_edge_length();
   
   
   initial_volumes.clear();
   for ( unsigned int i = 0; i < m_current_volumes.size(); ++i )
   {
      std::vector<unsigned int> volume_triangles;
      get_volume_triangles( surf, i, volume_triangles );
      initial_volumes.push_back( get_volume( surf, volume_triangles, surf.m_positions ) );
   }
                           
}


void DeformableSurface::compute_volume_conservation_impulses( const DynamicSurface& surf, const std::vector<Vec3d>& velocities, std::vector<Vec3d>& impulses, double dt )
{

   std::cout << " ---- volume conservation ---- " << std::endl;

   if ( volume_preserving_coefficient == 0.0 ) { return; }
   

   std::vector<Vec3d> predicted_positions( impulses.size() );   
   
   for ( unsigned int i = 0; i < velocities.size(); ++i )
   {
      predicted_positions[i] = surf.m_positions[i] + dt * velocities[i];
   }
   
   //std::vector<Vec3d> positions = surf.m_positions;
   
   std::vector<Vec3d> triangle_forces( surf.m_mesh.m_tris.size(), Vec3d(0,0,0) );
   
   if ( m_current_volumes.size() != initial_volumes.size() )
   {
      std::cout << "HACK: number of volumes has changed, resetting initial volumes" << std::endl;
      
      initial_volumes.clear();
      for ( unsigned int i = 0; i < m_current_volumes.size(); ++i )
      {
         std::vector<unsigned int> volume_triangles;
         get_volume_triangles( surf, i, volume_triangles );
         initial_volumes.push_back( get_volume( surf, volume_triangles, surf.m_positions ) );
      }
   }

   double max_volume_difference = 1e30;
   
   while ( max_volume_difference > 0.005 )
   {
      max_volume_difference = -1e30;
      
      for ( unsigned int v = 0; v < m_current_volumes.size(); ++v )
      {
         if ( surf.m_masses[ m_current_volumes[v][0] ] > 100.0 )
         {
            // solid
            continue;
         }

         std::vector<unsigned int> volume_triangles;
         get_volume_triangles( surf, v, volume_triangles );

         
         /*
         // remove triangles which are in contact with a solid surface
         
         std::cout << "surface triangles: " << volume_triangles.size() << std::endl;
         
         std::vector<unsigned int> free_volume_triangles = volume_triangles;
         for ( unsigned int i = 0; i < free_volume_triangles.size(); ++i )
         {
            const Vec3ui& tri = surf.m_mesh.m_tris[ free_volume_triangles[i] ];
            Vec3d query_min, query_max;
            minmax( surf.m_positions[tri[0]], surf.m_positions[tri[1]], surf.m_positions[tri[2]], query_min, query_max );
            
            std::vector<unsigned int> overlapping_vertices;
            surf.m_broad_phase->get_potential_vertex_collisions( query_min, query_max, overlapping_vertices );
            
            for ( unsigned int j = 0; j < overlapping_vertices.size(); ++j )
            {            
               if ( surf.m_masses[overlapping_vertices[j]] < 100.0 ) { continue; }
               
               double proximity;
               check_point_triangle_proximity( surf.m_positions[overlapping_vertices[j]], 
                                               surf.m_positions[tri[0]], 
                                               surf.m_positions[tri[1]], 
                                               surf.m_positions[tri[2]], 
                                               proximity );
                 
               if ( proximity < 1e-3 )
               {
                  free_volume_triangles.erase( free_volume_triangles.begin() + i );
                  --i;
                  break;
               }
            }

            for ( unsigned int vt = 0; vt < 3; ++vt )
            {
               unsigned int vertex = tri[vt];
               
               std::vector<unsigned int> overlapping_triangles;
               surf.m_broad_phase->get_potential_triangle_collisions( surf.m_positions[vt], surf.m_positions[vt], overlapping_triangles );
            
               bool solid_triangle_found = false;
               
               for ( unsigned int j = 0; j < overlapping_triangles.size(); ++j )
               {            
                  const Vec3ui& overlapping_tri = surf.m_mesh.m_tris[ overlapping_triangles[j] ];
                  if ( surf.m_masses[overlapping_tri[0]] < 100.0 ) { continue; }
                  
                  double proximity;
                  check_point_triangle_proximity( surf.m_positions[vertex], 
                                                 surf.m_positions[overlapping_tri[0]], 
                                                 surf.m_positions[overlapping_tri[1]], 
                                                 surf.m_positions[overlapping_tri[2]], 
                                                 proximity );
                  
                  if ( proximity < 1e-3 )
                  {
                     solid_triangle_found = true;
                     free_volume_triangles.erase( free_volume_triangles.begin() + i );
                     --i;
                     break;
                  }
               }
               
               if ( solid_triangle_found ) { break; }
            }
            
         }
         
         std::cout << "free surface triangles: " << free_volume_triangles.size() << std::endl;
         */


         //
         // Compute delta_volume
         // 
         
         double volume = get_volume( surf, volume_triangles, predicted_positions );   
         double surface_area = get_surface_area( surf, volume_triangles, predicted_positions );
                  
         double dv = 0.5 * (initial_volumes[v] - volume) / surface_area;
       
         max_volume_difference = max( max_volume_difference, dv );

//         std::cout << "initial_volume: " << initial_volumes[v] << std::endl;   
//         std::cout << "volume: " << volume << std::endl;
//         std::cout << "surface_area: " << surface_area << std::endl;      
   
         //
         // Compute per-triangle volume conservation forces
         //
         
         for ( unsigned int i = 0; i < volume_triangles.size(); ++i )
         {
            unsigned int tri_index = volume_triangles[i];
            
            const Vec3ui& tri = surf.m_mesh.m_tris[ tri_index ];
            
            if ( tri[0] == tri[1] ) { continue; }
            
            Vec3d v01 = predicted_positions[tri[1]] - predicted_positions[tri[0]];
            Vec3d v02 = predicted_positions[tri[2]] - predicted_positions[tri[0]];
            Vec3d normal = normalized(cross(v01, v02));
            
            triangle_forces[ tri_index ] = volume_preserving_coefficient * dv * normal;
         }

      }
   
      //
      // Average forces from triangles to vertices
      //
   
      for( unsigned int i = 0; i < surf.m_positions.size(); ++i )
      {
         if ( surf.m_masses[i] > 100.0 )
         {
            continue;
         }
         
         const std::vector<unsigned int>& incident_triangles = surf.m_mesh.m_vtxtri[i];
      
         for ( unsigned int j = 0; j < incident_triangles.size(); ++j )
         {
             impulses[i] += triangle_forces[ incident_triangles[j] ] / (double) incident_triangles.size();
         }
         
         // recompute predicred positions
         predicted_positions[i] = surf.m_positions[i] + dt * (velocities[i] + impulses[i]);  
      }
   
      std::cout << "max_volume_difference: " << max_volume_difference << std::endl;
      
   }

//   for( unsigned int i = 0; i < surf.m_positions.size(); ++i )
//   {
//      impulses[i] = (positions[i] - surf.m_positions[i]) / dt;
//   }
   
}


void DeformableSurface::compute_spring_forces( const DynamicSurface& surf, std::vector<Vec3d>& forces )
{
   
   std::cout << " ---- springs ---- " << std::endl;
   
   for ( unsigned int i = 0; i < surf.m_positions.size(); ++i )
   {
      const std::vector<unsigned int> incident_edges = surf.m_mesh.m_vtxedge[i];
      for ( unsigned int j = 0; j < incident_edges.size(); ++j )
      {
         unsigned int other_vertex = surf.m_mesh.m_edges[incident_edges[j]][0];
         if ( other_vertex == i ) { other_vertex = surf.m_mesh.m_edges[incident_edges[j]][1]; }
 
         Vec3d edge_vector = surf.m_positions[other_vertex] - surf.m_positions[i];
         double edge_length = mag( edge_vector );
         
         forces[i] += spring_coefficient * (edge_length - edge_rest_length) * edge_vector;
         forces[other_vertex] -= spring_coefficient * (edge_length - edge_rest_length) * edge_vector;
      }      
   }
   
}


void DeformableSurface::compute_surface_tension_forces( const DynamicSurface& surf, std::vector<Vec3d>& forces )
{
 
   std::cout << " ---- surface tension ---- " << std::endl;
   
   
   //
   // Compute per-triangle surface tension forces
   //
   
   std::vector<Vec3d> triangle_surface_tensions( surf.m_mesh.m_tris.size(), Vec3d(0,0,0) );
   
   for ( unsigned int i = 0; i < triangle_surface_tensions.size(); ++i )
   {
      if ( surf.m_mesh.m_tris[i][0] == surf.m_mesh.m_tris[i][1] ) { continue; }
      
      const Vec3ui& incident_edges = surf.m_mesh.m_triedge[i];
      
      for ( unsigned int e = 0; e < 3; ++e )
      {
         unsigned int edge_index = incident_edges[e]; 
         Vec2ui edge = surf.m_mesh.m_edges[edge_index];
         Vec3d edge_vector = surf.m_positions[edge[1]] - surf.m_positions[edge[0]];

         if ( false == surf.m_mesh.oriented( edge[0], edge[1], surf.m_mesh.m_tris[i] ) )
         {
            edge_vector = -edge_vector;
         }
         
         const std::vector<unsigned int>& adjacent_triangles = surf.m_mesh.m_edgetri[edge_index];
         
         for ( unsigned int j = 0; j < adjacent_triangles.size(); ++j )
         {
            if ( adjacent_triangles[j] == i ) { continue; }
         
            Vec3d normal = surf.get_triangle_normal( adjacent_triangles[j] );
            
            triangle_surface_tensions[i] += surface_tension_coefficient * mag(edge_vector) * normalized(cross( edge_vector, normal ));
         }         
      }
   }
   
   //
   // Average forces from triangles to vertices
   //
   
   for( unsigned int i = 0; i < surf.m_positions.size(); ++i )
   {
      if ( surf.m_masses[i] > 100.0 )  { continue; }
      
      const std::vector<unsigned int>& incident_triangles = surf.m_mesh.m_vtxtri[i];
      
      for ( unsigned int j = 0; j < incident_triangles.size(); ++j )
      {
         forces[i] += triangle_surface_tensions[ incident_triangles[j] ] / (double) incident_triangles.size() ;
      }
   }
   
   
}


void DeformableSurface::compute_accelerations( const DynamicSurface& surf, std::vector<Vec3d>& accelerations )
{
   std::vector<Vec3d> forces( accelerations.size(), Vec3d(0) );
   
   compute_surface_tension_forces( surf, forces );
   
   //compute_spring_forces( surf, forces );
   
   for ( unsigned int i = 0; i < accelerations.size(); ++i )
   {
      if ( surf.m_masses[i] < 100.0 )
      {
         accelerations[i] += forces[i] / surf.m_masses[i];
         accelerations[i][1] += gravity_constant;
      }
   }
      
}

void DeformableSurface::set_surface_velocity( const DynamicSurface& surf, std::vector<Vec3d>& velocities, double current_t, double& dt )
{
   // HACK: set initial velocities
//   static bool first_time = true;   
//   if ( first_time )
//   {
//      std::cout << "HACK: setting initial velocities" << std::endl;
//      for ( unsigned int i = 0; i < velocities.size(); ++i )
//      {
//         if ( velocities[i][1] > -10.0 )
//         {
//            velocities[i][1] = -10.0;
//         }
//      }
//      first_time = false;
//   }
   

   surf.partition_surfaces( m_current_volume_ids, m_current_volumes );

   
   std::vector<Vec3d> accelerations( velocities.size(), Vec3d(0) );
   
   compute_accelerations( surf, accelerations );
   
   for ( unsigned int i = 0; i < velocities.size(); ++i )
   {
      if ( surf.m_masses[i] < 100.0 )
      {
         velocities[i] += dt * accelerations[i];
      }
      else
      {
         velocities[i] = Vec3d(0,0,0);
      }
   }
   
   
   std::vector<Vec3d> impulses( velocities.size(), Vec3d(0) );
   compute_volume_conservation_impulses( surf, velocities, impulses, dt );
   
   std::vector<Vec3d> predicted_positions( velocities.size() );
   
   for ( unsigned int i = 0; i < velocities.size(); ++i )
   {
      if ( surf.m_masses[i] >= 100.0 ) 
      { 
         velocities[i] = Vec3d(0,0,0);
         continue;
      }

      //std::cout << "dt * acceleration: " << dt * accelerations[i] << "\t";
      //std::cout << "volume impulse: " << impulses[i] << std::endl;

      velocities[i] += impulses[i];
      predicted_positions[i] = surf.m_positions[i] + dt * velocities[i];
          
      
   }

   
}




