// ---------------------------------------------------------
//
//  potential.cpp
//  Tyson Brochu 2008
//
//  Motion defined by the gradient of a potential flow.
//
// ---------------------------------------------------------

// ---------------------------------------------------------
// Includes
// ---------------------------------------------------------

#include <potential.h>
#include <surftrack.h>
#include <meancurvature.h>

// ---------------------------------------------------------
// Global externs
// ---------------------------------------------------------

// ---------------------------------------------------------
// Local constants, typedefs, macros
// ---------------------------------------------------------

// ---------------------------------------------------------
// Static function definitions
// ---------------------------------------------------------

static double torus_a_signed_distance( const Vec3d& pt )
{
   static const Vec3d centre( 0.4, 0, 0 );
   static const Vec3d plane_normal(0,0,1);
   static const double outer_radius = 0.8;
   static const double innder_radius = 0.2;
   
   Vec3d pt_on_plane = pt - plane_normal * ( dot( plane_normal, pt - centre ) );
   Vec3d pt_on_circle = centre + outer_radius * ( pt_on_plane - centre ) / mag( pt_on_plane - centre );
   
   return mag( pt - pt_on_circle ) - innder_radius;
}

static double torus_b_signed_distance( const Vec3d& pt )
{
   static const Vec3d centre( -0.4, 0, 0 );
   static const Vec3d plane_normal(0,1,0);
   static const double outer_radius = 0.8;
   static const double innder_radius = 0.2;
   
   Vec3d pt_on_plane = pt - plane_normal * ( dot( plane_normal, pt - centre ) );
   Vec3d pt_on_circle = centre + outer_radius * ( pt_on_plane - centre ) / mag( pt_on_plane - centre );
   
   return mag( pt - pt_on_circle ) - innder_radius;
}

// ---------------------------------------------------------
// Member function definitions
// ---------------------------------------------------------

void PotentialDriver::grad_phi( const Vec3d& pt, Vec3d& n )
{
   double dphi_dx = ( signed_distance( pt + Vec3d( dx, 0, 0 ) ) - signed_distance( pt - Vec3d( dx, 0, 0 ) ) ) / (2*dx);
   double dphi_dy = ( signed_distance( pt + Vec3d( 0, dx, 0 ) ) - signed_distance( pt - Vec3d( 0, dx, 0 ) ) ) / (2*dx);
   double dphi_dz = ( signed_distance( pt + Vec3d( 0, 0, dx ) ) - signed_distance( pt - Vec3d( 0, 0, dx ) ) ) / (2*dx);
   
   n = Vec3d( dphi_dx, dphi_dy, dphi_dz );

}

double PotentialDriver::signed_distance( const Vec3d& pt )
{
   return min( torus_a_signed_distance(pt), torus_b_signed_distance(pt) );
}

void PotentialDriver::curvature_regularization( const DynamicSurface& surf, unsigned int vertex_index, double coefficient, Vec3d& f_out )
{
   Vec3d sum_y(0,0,0);
   const std::vector<unsigned int>& inc_edges = surf.m_mesh.m_vtxedge[vertex_index];
   for ( unsigned int i = 0; i < inc_edges.size(); ++i )
   {
      unsigned int other_vertex = surf.m_mesh.m_edges[inc_edges[i]][0];
      if ( other_vertex == vertex_index ) { other_vertex = surf.m_mesh.m_edges[inc_edges[i]][1]; }
      
      sum_y += neighbour_average_points[other_vertex] - surf.m_positions[other_vertex];
   }
   
   f_out = coefficient * (neighbour_average_points[vertex_index] - surf.m_positions[vertex_index] - sum_y / (double)inc_edges.size());
}

void PotentialDriver::spring_force( const DynamicSurface& surf, unsigned int vertex_index, double coefficient, double spring_constant, Vec3d& f_out )
{
   const std::vector<unsigned int>& inc_edges = surf.m_mesh.m_vtxedge[vertex_index];
   f_out = Vec3d(0,0,0);
   for ( unsigned int i = 0; i < inc_edges.size(); ++i )
   {
      unsigned int other_vertex = surf.m_mesh.m_edges[inc_edges[i]][0];
      if ( other_vertex == vertex_index ) { other_vertex = surf.m_mesh.m_edges[inc_edges[i]][1]; }
      
      Vec3d s = surf.m_positions[other_vertex] - surf.m_positions[vertex_index];
      f_out += ( mag(s) - spring_constant ) * s / mag(s) ;
   }
   
   f_out *= coefficient; 
}


void PotentialDriver::set_surface_velocity( const DynamicSurface& surf, std::vector<Vec3d>& out_velocity, double /*unused current_t*/, double& adaptive_dt )
{
   static const double curvature_multiplier = 0.1;
   
   out_velocity.resize( surf.m_positions.size() );

   double t_limit = 1e30;
   double avg_len = surf.get_average_edge_length();
   
   neighbour_average_points.resize( surf.m_positions.size() );
   for ( unsigned int i = 0; i < surf.m_positions.size(); ++i )
   {
      const std::vector<unsigned int>& inc_edges = surf.m_mesh.m_vtxedge[i];
      neighbour_average_points[i] = Vec3d(0,0,0);
      for ( unsigned int j = 0; j < inc_edges.size(); ++j )
      {
         unsigned int other_vertex = surf.m_mesh.m_edges[inc_edges[j]][0];
         if ( other_vertex == i ) { other_vertex = surf.m_mesh.m_edges[inc_edges[j]][1]; }
         
         neighbour_average_points[i] += surf.m_positions[other_vertex];
      }
      
      neighbour_average_points[i] /= (double) inc_edges.size();
   }
   
   for ( unsigned int i = 0; i < out_velocity.size(); ++i )
   {
      if ( surf.m_mesh.m_vtxtri[i].size() > 0 )
      {
         double weight_sum;
         Vec3d curvature_normal;
         MeanCurvatureDriver::vertex_mean_curvature_normal( i, surf, curvature_normal, weight_sum );
         
         curvature_normal *= curvature_multiplier * fabs( signed_distance( surf.m_positions[i] ) );
         weight_sum *= curvature_multiplier * fabs( signed_distance( surf.m_positions[i] ) );
         
         if ( weight_sum == 0 )
         {
            out_velocity[i] = Vec3d(0,0,0);
            continue;
         }
         
         Vec3d reg;
         curvature_regularization( surf, i, 0.1, reg );
         
         Vec3d spring;
         spring_force( surf, i, 0.1, avg_len, spring );
         
         Vec3d surface_normal;
         grad_phi( surf.m_positions[i], surface_normal );
         normalize( surface_normal );
         surface_normal *= -signed_distance( surf.m_positions[i] );
         
         out_velocity[i] = reg + spring + surface_normal;
         
         //weight_sum += mag( surface_normal );
         //t_limit = min( t_limit, 1.0 / weight_sum );
      }
      else
      {
         out_velocity[i] = Vec3d(0,0,0);
      }   
   }

   adaptive_dt = min( adaptive_dt, t_limit );   

}
