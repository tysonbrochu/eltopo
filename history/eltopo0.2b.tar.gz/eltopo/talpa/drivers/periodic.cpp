
#include <periodic.h>
#include <dynamicsurface.h>
#include <gluvi.h>

void PeriodicDriver::initialize( const DynamicSurface& surf )
{
   // assume vertices are on an regular nx-by-nx grid
   
   unsigned int nx = (unsigned int) sqrt( surf.m_positions.size() );
   
   assert( nx*nx == surf.m_positions.size() );
   
   for ( unsigned int i = 0; i < nx; ++i )
   {
      constrained_vertex_pairs.push_back( Vec2ui( i, nx*(nx-1) + i ) );
      constrained_vertex_pairs.push_back( Vec2ui( i*nx, i*nx + nx-1 ) );
   }   
}

void PeriodicDriver::display( const DynamicSurface& surf )
{
   glDisable(GL_LIGHTING);
   
   glLineWidth(3);
   glColor3d(1.0,0,0);
   
   glBegin(GL_LINES);
   
   for(unsigned int i = 0; i < constrained_vertex_pairs.size(); i++)
   {
      const Vec3d& vtx0 = surf.m_positions[constrained_vertex_pairs[i][0]];
      const Vec3d& vtx1 = surf.m_positions[constrained_vertex_pairs[i][1]];
      glVertex3d(vtx0[0], vtx0[1], vtx0[2]);
      glVertex3d(vtx1[0], vtx1[1], vtx1[2]);
   }
   
   glEnd();   
}

void PeriodicDriver::set_surface_velocity( const DynamicSurface& surf, std::vector<Vec3d>& out_velocities, double current_t, double& adaptive_dt )
{
}

