// ---------------------------------------------------------
//
//  Tyson Brochu 2009
//
//  ==================
//  UNDER CONSTRUCTION
//  ==================
//
// ---------------------------------------------------------

#ifndef DEFORMABLESURFACE_H
#define DEFORMABLESURFACE_H

// ---------------------------------------------------------
// Nested includes
// ---------------------------------------------------------

#include <meshdriver.h>

// ---------------------------------------------------------
//  Forwards and typedefs
// ---------------------------------------------------------

// ---------------------------------------------------------
//  Interface declarations
// ---------------------------------------------------------

///
///
class DeformableSurface : public MeshDriver
{
   
public:
      
   DeformableSurface() : 
      initial_volumes(0), edge_rest_length(1e30), 
      gravity_constant(1e30), spring_coefficient(1e30), 
      surface_tension_coefficient(1e30), volume_preserving_coefficient(1e30)
   {}
   
   // Initialise the driver with the surface at t = 0.
   void initialize( const DynamicSurface& surf );
   
   // Draw something with OpenGL
   void display( const DynamicSurface& /*surf*/ ) {}

   void get_volume_triangles( const DynamicSurface& surf, unsigned int volume_id, std::vector<unsigned int>& volume_triangles );
   
   double get_surface_area( const DynamicSurface& surf, const std::vector<unsigned int>& volume_triangles, const std::vector<Vec3d>& positions  );
   
   double get_volume( const DynamicSurface& surf, const std::vector<unsigned int>& volume_triangles, const std::vector<Vec3d> positions );
   
   void compute_volume_conservation_impulses( const DynamicSurface& surf, const std::vector<Vec3d>& velocities, std::vector<Vec3d>& impulses, double dt );
   
   void compute_spring_forces( const DynamicSurface& surf, std::vector<Vec3d>& forces );
   
   void compute_surface_tension_forces( const DynamicSurface& surf, std::vector<Vec3d>& forces );
   
   void compute_accelerations( const DynamicSurface& surf, std::vector<Vec3d>& accelerations );
   
   // Set velocities on each mesh vertex
   void set_surface_velocity( const DynamicSurface& surf, std::vector<Vec3d>& out_velocity, double current_t, double& adaptive_dt );

   void compute_error( const DynamicSurface& /*surf*/, double /*current_t*/ ) {}
   
   std::vector<double> initial_volumes;
   double edge_rest_length;

   double gravity_constant;
   double spring_coefficient;
   double surface_tension_coefficient;
   double volume_preserving_coefficient;

   std::vector<unsigned int> m_current_volume_ids;
   std::vector<std::vector<unsigned int> > m_current_volumes;
};

#endif

