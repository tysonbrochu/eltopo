
// ---------------------------------------------------------
//
//  Tyson Brochu 2008
//  
//
//  
//
// ---------------------------------------------------------

#ifndef GRIDFLUIDSIM_H
#define GRIDFLUIDSIM_H

// ---------------------------------------------------------
// Nested includes
// ---------------------------------------------------------

#include <array3.h>
#include <grid3.h>
#include <meshdriver.h>

// ---------------------------------------------------------
//  Forwards and typedefs
// ---------------------------------------------------------

class SurfTrack;

// ---------------------------------------------------------
//  Interface declarations
// ---------------------------------------------------------

class GridFluidSim : public MeshDriver
{
   
public:
   
   GridFluidSim( const Vec3d& grid_origin, const Vec3d& grid_high_bound, double grid_dx, double in_gravity = -9.8 );
   
   virtual void initialize( const DynamicSurface& surf ) {}
   
   void display( const DynamicSurface& surf );
   
   void apply_boundary_conditions();
   
   void project_velocity( double dt );
   
   virtual void extend_velocity( const DynamicSurface& surf, Array3d& vel, unsigned int offset_i, unsigned int offset_j, unsigned int offset_k );
   
   void apply_grid_velocity_to_mesh( const DynamicSurface& surf, std::vector<Vec3d>& out_velocity );
   
   virtual void compute_signed_distance( const DynamicSurface& surf );
   
   void extrapolate_phi_into_solid();
   
   virtual void apply_forces( const DynamicSurface& surf, double dt );
   
   void advect_velocity( double dt );
   
   void fluid_sim_update();
   

   /// Set velocities on each mesh vertex
   ///
   void set_surface_velocity( const DynamicSurface& surf, std::vector<Vec3d>& out_velocity, double current_t, double& adaptive_dt );
   
   double m_gravity;
   
   // At cell centres
   Array3d m_fluid_phi;
   Array3d m_pressure;

   // At cell faces
   Array3d m_sim_u, m_sim_v, m_sim_w;
   Array3d m_vol_fraction_u, m_vol_fraction_v, m_vol_fraction_w;

   Grid3d m_phi_grid;
   
   Array3i m_closest_tris;
   
};

void render_pressure( const Vec3d& origin, double dx, const Array3d& pressure );
void render_signed_distance( const Vec3d& origin, double dx, const Array3d& phi );
void render_velocity( const Vec3d& phi_origin, double dx, const Array3d& u, const Array3d& v, const Array3d& w );
void render_solid( const Vec3d& phi_origin, double dx, const Array3d& u, const Array3d& v, const Array3d& w );

// ---------------------------------------------------------
//  Inline functions
// ---------------------------------------------------------


#endif
