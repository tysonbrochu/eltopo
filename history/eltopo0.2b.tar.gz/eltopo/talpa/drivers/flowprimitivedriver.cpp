// ---------------------------------------------------------
//
//  flowprimitivedriver.cpp
//  Tyson Brochu 2009
//
//  
//
// ---------------------------------------------------------

// ---------------------------------------------------------
// Includes
// ---------------------------------------------------------

#include <flowprimitivedriver.h>
#include <surftrack.h>
#include <gluvi.h>
#include <simulation.h>

// ---------------------------------------------------------
// Global externs
// ---------------------------------------------------------

// ---------------------------------------------------------
// Local constants, typedefs, macros 
// ---------------------------------------------------------

// ---------------------------------------------------------
// Static function definitions
// ---------------------------------------------------------

double falloff( double r, double h )
{
   if ( r > h )
   {
      return 0.0;
   }
   else
   {
      double denom = (64.0 * M_PI * h * h * h * h * h * h * h * h * h);
      if ( denom < 1e-10 )
      {
         return 1.0;
      }
      else
      {
         return 315.0 / denom * ( h*h - r*r) * ( h*h - r*r) * ( h*h - r*r);
      }
   }
   
}

// ---------------------------------------------------------
// Member function definitions
// ---------------------------------------------------------

// ---------------------------------------------------------
// ---------------------------------------------------------
   


// ---------------------------------------------------------
// ---------------------------------------------------------

FlowPrimitiveDriver::FlowPrimitiveDriver() : 
   m_flow_primitive_manager( 0.0 ),
   m_initial_volume(-1.0)
{
}


void FlowPrimitiveDriver::initialize( const DynamicSurface& surf )
{
   extern Simulation *g_sim;
   std::cout << "current t: " << g_sim->m_curr_t << std::endl;
      
   m_flow_primitive_manager.m_current_t = g_sim->m_curr_t;
 
   // Initial flow primitives
   
   extern int g_example_setup;
   switch (g_example_setup)
   {
      case 0:
      {
         // FOG:
         
         m_flow_primitive_manager.add_flow_primitive( new NoiseOctave( 0.4, 0.001 ) );
         m_flow_primitive_manager.add_flow_primitive( new NoiseOctave( 1.2, 0.01 ) );      
         break;
      }
         
      case 1:
      {
         // THIN SMOKE:
         
         m_flow_primitive_manager.add_flow_primitive( new AxisNoiseOctave( Vec3d(0,0,0), 2.0, 0.03 ) );
         m_flow_primitive_manager.add_flow_primitive( new AxisNoiseOctave( Vec3d(0,0,0), 1.2, 0.06 ) );      

         VortexRing *initial_ring = new VortexRing( Vec3d(0), Vec3d(0, 0.25, 0), 0.6, 0.25 );
         initial_ring->m_radius_dot = 0.01;
         initial_ring->m_clamped_acceleration[1] = Vec3d( -0.003, 0.0, MAXFLOAT );
         initial_ring->m_magnitude_clamped_dot[0] = -0.001;   
         m_flow_primitive_manager.add_flow_primitive( initial_ring );      

         VortexRing subsquent_rings( *initial_ring );
         subsquent_rings.m_magnitude = 0.20;   
         m_flow_primitive_manager.add_flow_primitive_generator( new Generator<VortexRing>( subsquent_rings, 6.0, 3 ) );

         break;
      }  
         
      case 2:
      {
         // THICK SMOKE:

         VortexRing *ring = new VortexRing( Vec3d(0), Vec3d(0,0.25,0), 0.5, 0.1 );
         ring->m_clamped_acceleration[1] = Vec3d( -0.0075, 0.0, MAXFLOAT );
         ring->m_magnitude_clamped_dot = Vec3d( -0.001, 0.0, MAXFLOAT );
         m_flow_primitive_manager.add_flow_primitive( ring );
         
         DivergenceSource *source = new DivergenceSource( Vec3d(0), Vec3d(0, 0.25, 0), 1.2, 0.9, 0.3 );
         source->m_clamped_acceleration[1] = Vec3d( -0.0075, 0.0, MAXFLOAT );
         source->m_magnitude_clamped_dot = Vec3d( -0.002, 0.0, MAXFLOAT );
         m_flow_primitive_manager.add_flow_primitive( source );
         
         VortexRing ring_recipe( Vec3d(0), Vec3d(0,0.25,0), 0.6, 0.04 );
         ring_recipe.m_clamped_acceleration[1] = Vec3d( -0.0075, 0.0, MAXFLOAT );
         ring_recipe.m_magnitude_clamped_dot = Vec3d( -0.001, 0.0, MAXFLOAT );
         m_flow_primitive_manager.add_flow_primitive_generator ( new Generator<VortexRing>( ring_recipe, 5.0, 4 ) );
         
         DivergenceSource source_recipe( Vec3d(0, 0.0, 0), Vec3d(0, 0.25, 0), 0.4, 0.8, 0.3 );
         source_recipe.m_clamped_acceleration[1] = Vec3d( -0.0075, 0.0, MAXFLOAT );
         source_recipe.m_magnitude_clamped_dot = Vec3d( -0.001, 0.0, MAXFLOAT );
         m_flow_primitive_manager.add_flow_primitive_generator( new Generator<DivergenceSource>( source_recipe, 5.0, 4 ) );
         
         m_flow_primitive_manager.add_flow_primitive( new AxisNoiseOctave( Vec3d(0,0,0), 0.3, 0.004 ) );      
         
         break;
      }
         
      default:
         assert(false);
   }

   

   m_initial_volume = surf.get_volume();
   std::cout << "FlowPrimitiveDriver: Initial volume: " << m_initial_volume << std::endl;

   m_initial_surface_area = surf.get_surface_area();
   std::cout << "FlowPrimitiveDriver: Initial surface area: " << m_initial_surface_area << std::endl;
      
}


void FlowPrimitiveDriver::display( const DynamicSurface& surf )
{
   glDisable(GL_LIGHTING);

   m_flow_primitive_manager.render_flow_primitives();
   
}


void FlowPrimitiveDriver::set_surface_velocity( const DynamicSurface& surf, std::vector<Vec3d>& velocities, double current_t, double& dt )
{
      
   velocities.clear();
   velocities.resize( surf.m_positions.size(), Vec3d(0,0,0) );
   
   //
   // update flow primitives
   //
   
   m_flow_primitive_manager.update( dt );
      
   //
   // apply flow primitives to each vertex
   //
   
   static const double xmin = -3.0;
   static const double xmax = 2.9;

   for ( unsigned int i = 0; i < velocities.size(); ++i )
   {    
      // skip orphaned vertices
      
      if ( surf.m_mesh.m_vtxtri[i].empty() ) // || surf.m_masses[i] > 100.0 )
      {
         velocities[i] = Vec3d(0,0,0);
         continue;
      }
            
      m_flow_primitive_manager.apply_flow_primitives( surf.m_positions[i], velocities[i] );
      
      // boundary vertices
      
      const std::vector<unsigned int>& edges = surf.m_mesh.m_vtxedge[i];
      bool one_tri = false;
      for ( unsigned int j = 0; j < edges.size(); ++j )
      {
         if ( surf.m_mesh.m_edgetri[ edges[j] ].size() == 1 )
         {  
            one_tri = true;
            break;
         }
      }
      
      if ( one_tri ) 
      {          
         const Vec3d& p = surf.m_positions[i];
         Vec3d predicted_position = p + dt * velocities[i];
         if ( fabs(p[0] - xmin) < 1e-1 ) { predicted_position[0] = xmin; }
         if ( fabs(p[2] - xmin) < 1e-1 ) { predicted_position[2] = xmin; }
         if ( fabs(p[0] - xmax) < 1e-1 ) { predicted_position[0] = xmax; }
         if ( fabs(p[2] - xmax) < 1e-1 ) { predicted_position[2] = xmax; }
         velocities[i] = ( predicted_position - surf.m_positions[i] ) / dt;
      }

      const Vec3d& p = surf.m_positions[i];
      Vec3d predicted_position = p + dt * velocities[i];
      if ( predicted_position[0] < xmin ) { predicted_position[0] = xmin; }
      if ( predicted_position[2] < xmin ) { predicted_position[2] = xmin; }
      if ( predicted_position[0] > xmax ) { predicted_position[0] = xmax; }
      if ( predicted_position[2] > xmax ) { predicted_position[2] = xmax; }      
      velocities[i] = ( predicted_position - surf.m_positions[i] ) / dt;
      
   }


   // project solid vertices back onto the sphere
   if ( current_t < 20.0f ) //if ( m_rings.size() < NUM_RINGS )
   {
      static const Vec3d solid_sphere_centre( 0.0, 0.0, 0.0 );
      static const double solid_sphere_radius = 0.5;
      
      for ( unsigned int i = 0; i < velocities.size(); ++i )
      {    
         Vec3d predicted_position = surf.m_positions[i] + dt * velocities[i];
         Vec3d vector_to_centre = predicted_position - solid_sphere_centre;
         
         if ( mag(vector_to_centre) < solid_sphere_radius && predicted_position[1] < 0.0 )
         {
            predicted_position -= ( mag( vector_to_centre ) - solid_sphere_radius ) * vector_to_centre / mag(vector_to_centre);
            velocities[i] = ( predicted_position - surf.m_positions[i] ) / dt;
         }
      }
   }

   
   if(0)
   {      
      for ( unsigned int i = 0; i < velocities.size(); ++i )
      {          
         Vec3d predicted_position = surf.m_positions[i] + dt * velocities[i];

         double px = predicted_position[0];
         double py = predicted_position[1];
         double pz = predicted_position[2];

         if ( px > 3.0 )
         {
            px = 3.0;
         }

         if ( px < -3.0 )
         {
            px = -3.0;
         }

         if ( pz > 3.0 )
         {
            pz = 3.0;
         }

         if ( pz < -3.0 )
         {
            pz = -3.0;
         }

         if ( py < 0.0 )
         {
            py = 0.0;
         }
                  
         predicted_position[0] = px;
         predicted_position[1] = py;
         predicted_position[2] = pz;
         
         velocities[i] = ( predicted_position - surf.m_positions[i] ) / dt;
      }
   }
   
}


void FlowPrimitiveDriver::compute_error( const DynamicSurface& surf, double current_t )
{
   double current_volume = surf.get_volume();
   std::cout << "FlowPrimitiveDriver: current volume: " << current_volume;
   std::cout << "\t percent change: " << (current_volume - m_initial_volume) / m_initial_volume << std::endl;
   
   double current_surface_area = surf.get_surface_area();
   std::cout << "FlowPrimitiveDriver: current area: " << current_surface_area;
   std::cout << "\t percent change: " << (current_surface_area - m_initial_surface_area) / m_initial_surface_area << std::endl;
   
}



