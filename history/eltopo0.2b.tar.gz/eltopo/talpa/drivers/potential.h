// ---------------------------------------------------------
//
//  potential.h
//  Tyson Brochu 2008
//
//  Motion defined by the gradient of a potential flow.
//
//
//  ==================
//  UNDER CONSTRUCTION
//  ==================
//
// ---------------------------------------------------------

#ifndef POTENTIAL_H
#define POTENTIAL_H

// ---------------------------------------------------------
// Nested includes
// ---------------------------------------------------------

#include <meshdriver.h>

// ---------------------------------------------------------
//  Forwards and typedefs
// ---------------------------------------------------------

// ---------------------------------------------------------
//  Interface declarations
// ---------------------------------------------------------

class PotentialDriver : public MeshDriver
{

public:
   
   PotentialDriver( double in_dx = 1e-4 ) : dx(in_dx), neighbour_average_points() {}
   
   void initialize( const DynamicSurface& ) {}
   
   double signed_distance( const Vec3d& pt );
   void grad_phi( const Vec3d& pt, Vec3d& n );
   void curvature_regularization( const DynamicSurface& surf, unsigned int vertex_index, double coefficient, Vec3d& f_out );
   void spring_force( const DynamicSurface& surf, unsigned int vertex_index, double coefficient, double spring_constant, Vec3d& f_out );
   
   void display( const DynamicSurface& surf ) {}
   
   void set_surface_velocity( const DynamicSurface& surf, std::vector<Vec3d>& out_velocity, double current_t, double& adaptive_dt );
   
   void compute_error( const DynamicSurface& surf, double current_t ) {}

   double dx;   
   std::vector<Vec3d> neighbour_average_points;

};

// ---------------------------------------------------------
//  Inline functions
// ---------------------------------------------------------


#endif
