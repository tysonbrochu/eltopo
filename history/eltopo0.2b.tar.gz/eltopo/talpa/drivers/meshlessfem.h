// ---------------------------------------------------------
//
//  meshlessfem.h
//
//  Meshless FEM elasticity from Muller et al. 2004.
//
//  ==================
//  UNDER CONSTRUCTION
//  ==================
//
// ---------------------------------------------------------

#ifndef MESHLESSFEM_H
#define MESHLESSFEM_H

// ---------------------------------------------------------
// Nested includes
// ---------------------------------------------------------

#include <meshdriver.h>
#include <mat.h>
#include <vec.h>
#include <accelerationgrid.h>

// ---------------------------------------------------------
//  Forwards and typedefs
// ---------------------------------------------------------

class SurfTrack;

// ---------------------------------------------------------
//  Interface declarations
// ---------------------------------------------------------

// ---------------------------------------------------------
///
/// Particle-based elasticity/plasticity
///
// ---------------------------------------------------------

class MeshlessFEMDriver : public MeshDriver
{
public:

   /// Default constructor
   ///
   MeshlessFEMDriver( double youngs_modulus = 1e-1, 
                      double poisson_ratio = 0.35, 
                      double rayleigh_phi = 0.0, 
                      double rayleigh_psi = 0.0, 
                      double von_mises_gamma = 0.0, 
                      double max_plastic_strain = 1e+7);   

   /// Virtual destructor
   ///
   virtual ~MeshlessFEMDriver() {}
  
private:

   ///
   /// Don't allow copy construction or assignment
   ///
   
   MeshlessFEMDriver( const MeshlessFEMDriver& other );
   MeshlessFEMDriver& operator=( const MeshlessFEMDriver& other );
   
public:

   double get_k_nearest_neighbours( unsigned int k, 
                                    const Vec3d& pt, 
                                    unsigned int volume_id, 
                                    std::vector<unsigned int>& nearest_neighbours );
                             
   void initialize( const DynamicSurface& surf );
   
   double spline_weight( double r, double h );
   double gaussian_weight( double r, double h );
   
   Mat33d compute_deformation_gradient( unsigned int i, 
                                        const std::vector<unsigned int>& neighbours, 
                                        const std::vector<double>& wi, 
                                        const Mat33d& inv_A );
   
   
   Mat33d compute_deformation_rate_gradient( unsigned int i, 
                                             const std::vector<unsigned int>& neighbours, 
                                             const std::vector<double>& wi, 
                                             const Mat33d& inv_A );
   
   void build_acceleration_grids( double grid_padding );

   void get_neighbouring_reference_particles( unsigned int particle_index, std::vector<unsigned int>& neighbours );
   void get_nearby_reference_particles( const Vec3d& x, double h, unsigned int volume_id, std::vector<unsigned int>& neighbours );
   
   void compute_elastic_plastic_forces( double dt, std::vector<Vec3d>& forces );

   void compute_surface_tenstion_forces( const DynamicSurface& surf, std::vector<Vec3d>& forces );
   
   /// Compute displacement at the given point in reference space
   ///
   void linear_interpolate_displacement( const Vec3d& reference_x, unsigned int volume_id, double h, Vec3d& u );

   
   /// Take a single change in surface displacement, and adjust the simulation displacement to fit it
   ///
   //void interpolate_displacement_to_simulation( const Vec3d& reference_x, unsigned int volume_id, double h, const Vec3d& u_after_collision, const Vec3d& u_predicted, double dt );

   /// Fit simulation displacements to all changed surface displacements (like a global version of the previous function)
   ///
   void linear_fit_particle_displacements_to_surface( unsigned int volume_id, 
                                               const std::vector<Vec3d>& surface_reference_positions,
                                               const std::vector<Vec3d>& collision_adjusted_displacements,
                                               const std::vector<Vec3d>& predicted_displacements,
                                               double h,
                                               double dt );
   
   void compute_accelerations( const DynamicSurface& surf, double dt, std::vector<Vec3d>& accelerations );
   
   double detect_pentration( const Vec3d& predicted_position, Vec3d& normal );
   
   /// Set velocities on each mesh vertex
   ///
   void set_surface_velocity( const DynamicSurface& surf, std::vector<Vec3d>& out_velocity, double current_t, double& adaptive_dt );

   void compute_error( const DynamicSurface& /*surf*/, double /*current_t*/ ) {}
   
   void display(const DynamicSurface& surf);
   
   AccelerationGrid m_reference_space_grid;
   
   std::vector<Vec3d> m_reference_positions;

   std::vector<Vec3d> m_displacements;   
   
   std::vector<Vec3d> m_displacement_velocities;      

   std::vector<double> m_masses;
   std::vector<double> m_densities;
   std::vector<double> m_supports;
   std::vector<double> m_volumes;

   std::vector<Mat33d> m_plastic_strains;
   
   std::vector<Mat33d> m_grad_Us;
   std::vector<Mat33d> m_inv_As;
      
   std::vector<unsigned int> m_volume_ids;

   double m_cfl_max_dt;
   double m_original_particle_spacing;

   double m_lame_lambda;
   double m_lame_mu;
   double m_rayleigh_phi;
   double m_rayleigh_psi;
   double m_von_mises_gamma;
   double m_max_plastic_strain;
      
   Vec3d cylinder_centre;
   double cylinder_radius;
   
};

// ---------------------------------------------------------
//  Inline functions
// ---------------------------------------------------------


inline double MeshlessFEMDriver::spline_weight( double r, double h )
{
   if ( r < h )
   {
      return 315.0 / (64.0 * M_PI * h * h * h * h * h * h * h * h * h) * ( h*h - r*r) * ( h*h - r*r) * ( h*h - r*r);
   }
   else
   {
      return 0.0;
   }
}


inline double MeshlessFEMDriver::gaussian_weight( double r, double h )
{
   return exp( -(r*r) / (h*h) );
}

#endif

