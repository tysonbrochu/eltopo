// ---------------------------------------------------------
//
//  faceoff.h
//  Tyson Brochu 2008
//
//  Mesh driver for motion in the normal direction using the faceoff method (entropy solution).
//
// ---------------------------------------------------------

#ifndef FACEOFF_H
#define FACEOFF_H

// ---------------------------------------------------------
// Nested includes
// ---------------------------------------------------------

#include <meshdriver.h>

#include <vector>
#include <vec.h> 
#include <mat.h>

// ---------------------------------------------------------
//  Forwards and typedefs
// ---------------------------------------------------------

class NonDestructiveTriMesh;
class SurfTrack;

// ---------------------------------------------------------
//  Interface declarations
// ---------------------------------------------------------

// ---------------------------------------------------------
///
/// Motion in the normal direction using Face Offsetting [Jiao 2007].
///
/// Specifically, this driver starts with two spheres, moves in the 
/// positive normal direction, then in the negative normal direction.
/// Error computations are done vs. an analytical solution to this problem.
///
// ---------------------------------------------------------

class FaceOffDriver : public MeshDriver
{
public:
   
   /// Constructor 
   /// 
   FaceOffDriver( double in_speed, const Vec3d& in_sphere_a_centre, const Vec3d& in_sphere_b_centre, double in_max_radius, double in_interior_radius ) : 
      speed(in_speed) ,
      sphere_a_centre(in_sphere_a_centre),
      sphere_b_centre(in_sphere_b_centre),   
      max_radius(in_max_radius),
      interior_radius(in_interior_radius)
   {}
   
   /// Get the quadric metric tensor at a vertex from the given incident triangles
   ///   
   void compute_quadric_metric_tensor( const std::vector<Vec3d>& triangle_normals, 
                                      const std::vector<double>& triangle_areas, 
                                      const std::vector<unsigned int>& incident_triangles,
                                      Mat33d& quadric_metric_tensor );

   /// Return intersection point between a set of planes in the least-squares sense
   ///
   void intersection_point( const std::vector<Vec3d>& triangle_normals, 
                            const std::vector<double>& triangle_plane_distances,
                            const std::vector<double>& triangle_areas, 
                            const std::vector<unsigned int>& incident_triangles,
                            Vec3d& out);
   
   /// Assign a velocity vector to each mesh vertex
   /// 
   void set_surface_velocity( const DynamicSurface& surf, std::vector<Vec3d>& out_velocity, double current_t, double& adaptive_dt );

   /// Compute the distance from vertices to analytic surface, weighted by associated vertex area
   /// 
   void compute_l1_error( const DynamicSurface& surf );

   /// Compute the maximum distance from vertices to analytic surface
   /// 
   void compute_inf_error( const DynamicSurface& surf );
   
   /// Compute and output both L1 and L_inf errors
   ///
   void compute_error( const DynamicSurface& surf, double current_t );
   
   /// Speed of normal motion
   double speed;
   
   //
   // The following members are used to compute the analytic solution
   //
   
   /// Geometry to compare against
   Vec3d sphere_a_centre, sphere_b_centre;
   
   /// radius of spheres when motion switches from positive to negative
   double max_radius;         
   
   /// difference between maximum radius and final radius
   double interior_radius;    
      
};


// ---------------------------------------------------------
//  Inline functions
// ---------------------------------------------------------

#endif


