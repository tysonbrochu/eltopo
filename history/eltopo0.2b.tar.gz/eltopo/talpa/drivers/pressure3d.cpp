
//
// Courtesy Christopher Batty
//

#include <pressure3d.h>
#include <grid3.h>
#include <sparse_matrix.h>

static unsigned int p_ind(int i, int j, int k, int nx, int ny, int nz) {
   return i + j*nx + k*nx*ny;
}

void add_fluid_to_pressure_projection(
    const Grid3d &grid,
    const double dt,
    const double fluid_density,
    const Array3d &vol_fraction_u,
    const Array3d &vol_fraction_v,
    const Array3d &vol_fraction_w,
    const Array3d &input_u,
    const Array3d &input_v,
    const Array3d &input_w,
    const Array3d &liquid_phi,
    SparseMatrixDynamicCSR &matrix,
    std::vector<double> &right_hand_side) 
{
   int nx = vol_fraction_v.ni;
   int ny = vol_fraction_u.nj;
   int nz = vol_fraction_u.nk;

   assert(vol_fraction_u.ni==nx+1 && vol_fraction_u.nj==ny && vol_fraction_u.nk == nz);
   assert(vol_fraction_v.ni==nx && vol_fraction_v.nj==ny+1 && vol_fraction_v.nk == nz);
   assert(vol_fraction_w.ni==nx && vol_fraction_w.nj==ny && vol_fraction_w.nk == nz+1);

   assert(input_u.ni==nx+1 && input_u.nj==ny && input_u.nk == nz);
   assert(input_v.ni==nx && input_v.nj==ny+1 && input_v.nk == nz);
   assert(input_w.ni==nx && input_w.nj==ny && input_w.nk == nz+1);
   assert(matrix.n == nx*ny*nz);
   assert(right_hand_side.size()==(unsigned int)(nx*ny*nz));

   double dx = grid.dx;
   double dx2 = grid.dx*grid.dx;
   double factor = dt/dx2/fluid_density;

   for(int k = 0; k < nz; ++k ) {
      for(int j = 0; j < ny; ++j)  {
         for(int i = 0; i < nx; ++i) {
            int index = p_ind(i,j,k,nx,ny,nz);
            
            //The basic idea is to assume liquid is linearly extrapolated into walls appropriately, 
            //and then we only have to treat the two simple cases, for liquid and air, ignoring Neumann BC for
            //solid wall boundaries which get enforced automatically by the volume weights.

            //Only consider cells containing liquid and having some non-wall volume
            if(liquid_phi(i,j,k) < 0 && 
               vol_fraction_u(i,j,k) + vol_fraction_u(i+1,j,k) + 
               vol_fraction_v(i,j,k) + vol_fraction_v(i,j+1,k) + 
               vol_fraction_w(i,j,k) + vol_fraction_w(i,j,k+1) > 0) {

               //build RHS
               right_hand_side[index] += 1 / dx * (
                  + vol_fraction_u(i,j,k) * input_u(i,j,k) 
                  - vol_fraction_u(i+1,j,k) * input_u(i+1,j,k) 
                  + vol_fraction_v(i,j,k) * input_v(i,j,k) 
                  - vol_fraction_v(i,j+1,k) * input_v(i,j+1,k)
                  + vol_fraction_w(i,j,k) * input_w(i,j,k)
                  - vol_fraction_w(i,j,k+1) * input_w(i,j,k+1)
                  );

               //Set up pressure coefficients.
              
               if(liquid_phi(i-1,j,k) < 0) { //left neighbour is liquid
                  matrix(index, index)       +=  vol_fraction_u(i,j,k)*factor;
                  matrix(index, index - 1)   += -vol_fraction_u(i,j,k)*factor;
               }
               else { //left neighbour is air
                  double theta = max(0.01, liquid_phi(i,j,k) / (liquid_phi(i,j,k) - liquid_phi(i-1,j,k)));
                  matrix(index, index) += vol_fraction_u(i,j,k)*factor/theta;
               }

               if(liquid_phi(i+1,j,k) < 0) { //right neighbour is liquid
                  matrix(index, index )      += vol_fraction_u(i+1,j,k)*factor;
                  matrix(index, index + 1 )  += -vol_fraction_u(i+1,j,k)*factor;
               }
               else { //right neighbour is air
                  double theta = max(0.01, liquid_phi(i,j,k) / (liquid_phi(i,j,k) - liquid_phi(i+1,j,k)));
                  matrix(index, index ) += vol_fraction_u(i+1,j,k)*factor/theta;
               }

               if(liquid_phi(i,j-1,k) < 0) { //below neighbour is liquid
                  matrix(index, index )      +=  vol_fraction_v(i,j,k)*factor;
                  matrix(index, index - nx ) += -vol_fraction_v(i,j,k)*factor;
               }
               else { //below neighbour is air
                  double theta = max(0.01, liquid_phi(i,j,k) / (liquid_phi(i,j,k) - liquid_phi(i,j-1,k)));
                  matrix(index, index ) += vol_fraction_v(i,j,k)*factor/theta;
               }

               if(liquid_phi(i,j+1,k) < 0) { //above neighbour is liquid
                  matrix(index, index )      += vol_fraction_v(i,j+1,k)*factor;
                  matrix(index, index + nx ) += -vol_fraction_v(i,j+1,k)*factor;
               }
               else { //above neighbour is air
                  double theta = max(0.01, liquid_phi(i,j,k) / (liquid_phi(i,j,k) - liquid_phi(i,j+1,k)));
                  matrix(index, index ) += vol_fraction_v(i,j+1,k)*factor/theta;
               }
            

               if(liquid_phi(i,j,k-1) < 0) { //back neighbour is liquid
                  matrix(index, index )         +=  vol_fraction_w(i,j,k)*factor;
                  matrix(index, index - nx*ny ) += -vol_fraction_w(i,j,k)*factor;
               }
               else { //back neighbour is air
                  double theta = max(0.01, liquid_phi(i,j,k) / (liquid_phi(i,j,k) - liquid_phi(i,j,k-1)));
                  matrix(index, index ) += vol_fraction_w(i,j,k)*factor/theta;
               }

               if(liquid_phi(i,j,k+1) < 0) { //front neighbour is liquid
                  matrix(index, index )         += vol_fraction_w(i,j,k+1)*factor;
                  matrix(index, index + nx*ny ) += -vol_fraction_w(i,j,k+1)*factor;
               }
               else { //front neighbour is air
                  double theta = max(0.01, liquid_phi(i,j,k) / (liquid_phi(i,j,k) - liquid_phi(i,j,k+1)));
                  matrix(index, index ) += vol_fraction_w(i,j,k+1)*factor/theta;
               }

            }
         }
      }
   }
   
}

void update_fluid_velocities(
     const Grid3d &grid,
     const double dt,
     const double fluid_density,
     const std::vector<double> &solution,
     const Array3d& liquid_phi,
     Array3d &u,
     Array3d &v,
     Array3d &w) 
{

   int nx = u.ni-1;
   int ny = u.nj;
   int nz = u.nk;
   double dx = grid.dx;
   double factor = dt/fluid_density/dx;
   //update u from pressure gradient
   for(int k = 0; k < nz; ++k) for(int j = 0; j < ny; ++j) for(int i = 1; i < nx; ++i) {
      int p_pos = p_ind(i,j,k,nx,ny,nz);
      int p_neg = p_ind(i-1,j,k,nx,ny,nz);
      
      if(liquid_phi(i,j,k) < 0 && liquid_phi(i-1,j,k) < 0) {
         u(i,j,k) -= (double)(factor * (solution[p_pos]-solution[p_neg])); 
      }
      else if(liquid_phi(i,j,k) < 0) {
         double theta = max(0.01, liquid_phi(i,j,k) / (liquid_phi(i,j,k) - liquid_phi(i-1,j,k)));
         u(i,j,k) -= (double)(factor * solution[p_pos] / theta); 
      }
      else if(liquid_phi(i-1,j,k) < 0) {
         double theta = max(0.01, liquid_phi(i-1,j,k) / (liquid_phi(i-1,j,k) - liquid_phi(i,j,k)));
         u(i,j,k) -= (double)(factor * -solution[p_neg] / theta); 
      }
      
   }

   //update v from pressure gradient
   for(int k = 0; k < nz; ++k) for(int j = 1; j < ny; ++j) for(int i = 0; i < nx; ++i) {
      int p_pos = p_ind(i,j,k,nx,ny,nz);
      int p_neg = p_ind(i,j-1,k,nx,ny,nz);
      if(liquid_phi(i,j,k) < 0 && liquid_phi(i,j-1,k) < 0) {
         v(i,j,k) -= (double)(factor * (solution[p_pos]-solution[p_neg]));
      }
      else if(liquid_phi(i,j,k) < 0) {
         double theta = max(0.01, liquid_phi(i,j,k) / (liquid_phi(i,j,k) - liquid_phi(i,j-1,k)));
         v(i,j,k) -= (double)(factor * solution[p_pos] / theta);
      }
      else if(liquid_phi(i,j-1,k) < 0) {
         double theta = max(0.01, liquid_phi(i,j-1,k) / (liquid_phi(i,j-1,k) - liquid_phi(i,j,k)));
         v(i,j,k) -= (double)(factor * -solution[p_neg] / theta);
      }
   }

   //update w from pressure gradient
   for(int k = 1; k < nz; ++k) for(int j = 0; j < ny; ++j) for(int i = 0; i < nx; ++i) {
      int p_pos = p_ind(i,j,k,nx,ny,nz);
      int p_neg = p_ind(i,j,k-1,nx,ny,nz);
      if(liquid_phi(i,j,k) < 0 && liquid_phi(i,j,k-1) < 0) {
         w(i,j,k) -= (double)(factor * (solution[p_pos]-solution[p_neg]));
      }
      else if(liquid_phi(i,j,k) < 0) {
         double theta = max(0.01, liquid_phi(i,j,k) / (liquid_phi(i,j,k) - liquid_phi(i,j,k-1)));
         w(i,j,k) -= (double)(factor * solution[p_pos] / theta);
      }
      else if(liquid_phi(i,j,k-1) < 0) {
         double theta = max(0.01, liquid_phi(i,j,k-1) / (liquid_phi(i,j,k-1) - liquid_phi(i,j,k)));
         w(i,j,k) -= (double)(factor * -solution[p_neg] / theta);
      }
   }

}

void add_scripted_region(
   const Grid3d &grid,
   const Array3d &vol_u,
   const Array3d &vol_v,
   const Array3d &vol_w,
   const double dt,
   const Vec3d linear_velocity,
   const Vec3d angular_velocity,
   const Vec3d centre_point,
   std::vector<double> &right_hand_side) 
{
   int nx = vol_u.ni-1;
   int ny = vol_u.nj;
   int nz = vol_u.nk;
   double dx = grid.dx;

   for(int k = 0; k < nz; ++k) {
      for (int j = 0; j < ny; ++j) {
         for (int i = 0; i < nx; ++i) {
            int index = p_ind(i,j,k,nx,ny,nz);
            double px = (i+0.5f)*dx;
            double py = (j+0.5f)*dx;
            double pz = (k+0.5f)*dx;
            double offset = 0.5f*dx;

            Vec3d rad_main = Vec3d(px, py, pz) - centre_point;
            Vec3d rad_x0 = rad_main - Vec3d(offset,0,0);
            Vec3d rad_x1 = rad_main + Vec3d(offset,0,0);
            Vec3d rad_y0 = rad_main - Vec3d(0,offset,0);
            Vec3d rad_y1 = rad_main + Vec3d(0,offset,0);
            Vec3d rad_z0 = rad_main - Vec3d(0,0,offset);
            Vec3d rad_z1 = rad_main + Vec3d(0,0,offset);

            Vec3d rotational_velocity_x0 = cross(angular_velocity, rad_x0);
            Vec3d rotational_velocity_x1 = cross(angular_velocity, rad_x1);
            Vec3d rotational_velocity_y0 = cross(angular_velocity, rad_y0);
            Vec3d rotational_velocity_y1 = cross(angular_velocity, rad_y1);
            Vec3d rotational_velocity_z0 = cross(angular_velocity, rad_z0);
            Vec3d rotational_velocity_z1 = cross(angular_velocity, rad_z1);
         
            right_hand_side[index] -= (rotational_velocity_x1[0] + linear_velocity[0]) * (vol_u(i+1,j,k))/dx;
            right_hand_side[index] -= (rotational_velocity_x0[0] + linear_velocity[0]) * (-vol_u(i,j,k))/dx;
            right_hand_side[index] -= (rotational_velocity_y1[1] + linear_velocity[1]) * (vol_v(i,j+1,k))/dx;
            right_hand_side[index] -= (rotational_velocity_y0[1] + linear_velocity[1]) * (-vol_v(i,j,k))/dx;
            right_hand_side[index] -= (rotational_velocity_z1[2] + linear_velocity[2]) * (vol_w(i,j,k+1))/dx;
            right_hand_side[index] -= (rotational_velocity_z0[2] + linear_velocity[2]) * (-vol_w(i,j,k))/dx;
         }
      }
   }
}

