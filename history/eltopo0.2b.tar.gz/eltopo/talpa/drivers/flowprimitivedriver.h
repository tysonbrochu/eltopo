// ---------------------------------------------------------
//
//  flowprimitivedriver.h
//  Tyson Brochu 2009
//
//  
//
// ---------------------------------------------------------

#ifndef FLOWPRIMITIVEDRIVER_H
#define FLOWPRIMITIVEDRIVER_H

// ---------------------------------------------------------
// Nested includes
// ---------------------------------------------------------

#include <flowprimitives.h>
#include <meshdriver.h>

// ---------------------------------------------------------
//  Forwards and typedefs
// ---------------------------------------------------------

class DynamicSurface;

// ---------------------------------------------------------
//  Interface declarations
// ---------------------------------------------------------

// ---------------------------------------------------------

struct FlowPrimitiveDriver: public MeshDriver
{
   FlowPrimitiveDriver(void);
   
   void initialize( const DynamicSurface& surf );

   void display( const DynamicSurface& surf );
   
   // Set velocities on each mesh vertex
   void set_surface_velocity( const DynamicSurface& surf, std::vector<Vec3d>& out_velocity, double current_t, double& dt );
   
   void post_collision_update( const DynamicSurface& , const std::vector<Vec3d>& , double , double&  ) {}
   
   void compute_error( const DynamicSurface& surf, double current_t );
   
   FlowPrimitiveManager m_flow_primitive_manager;
   
   double m_initial_volume;
   double m_initial_surface_area;
   
};

// ---------------------------------------------------------
//  Inline functions
// ---------------------------------------------------------



#endif
