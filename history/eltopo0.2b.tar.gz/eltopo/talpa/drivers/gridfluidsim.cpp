
// ---------------------------------------------------------
//
//  Tyson Brochu 2008
//  
//
//  
//
// ---------------------------------------------------------

// ---------------------------------------------------------
// Includes
// ---------------------------------------------------------

#include <gridfluidsim.h>
#include <pressure3d.h>

#include <surftrack.h>
#include <broadphase.h>
#include <util.h>
#include <gluvi.h>
#include <makelevelset3.h>

#include <sparse_matrix.h>
#include <krylov_solvers.h>

// ---------------------------------------------------------
// Global externs
// ---------------------------------------------------------

extern unsigned int g_fluid_render_type;

// ---------------------------------------------------------
// Local constants, typedefs, macros
// ---------------------------------------------------------

// ---------------------------------------------------------
// Static and nonmember function definitions
// ---------------------------------------------------------

// ---------------------------------------------------------
///
/// 
///
// ---------------------------------------------------------

double fluid_trilerp( const Vec3d& x, const Vec3d& grid_origin, double grid_dx, double grid_inv_dx, const Array3d& grid )
{
   Vec3d grid_coord_x = x - grid_origin;
   
   assert( grid_coord_x[0] >= 0.0 );
   assert( grid_coord_x[1] >= 0.0 );
   assert( grid_coord_x[2] >= 0.0 );

   assert( grid_coord_x[0] < grid.ni * grid_dx );
   assert( grid_coord_x[1] < grid.nj * grid_dx );
   assert( grid_coord_x[2] < grid.nk * grid_dx );
   
   int i = (int) floor( grid_coord_x[0] * grid_inv_dx );
   
   if ( i >= grid.ni - 1 ) { return 0.0f; }
   
   double fx = grid_coord_x[0] - i * grid_dx;
   fx *= grid_inv_dx;
   
   int j = (int) floor( grid_coord_x[1] * grid_inv_dx );
   
   if ( j >= grid.nj - 1) { return 0.0f; }
   
   double fy = grid_coord_x[1] - j * grid_dx;
   fy *= grid_inv_dx;

   int k = (int) floor( grid_coord_x[2] * grid_inv_dx );
  
   if ( k >= grid.nk - 1) { return 0.0f; }
      
   double fz = grid_coord_x[2] - k * grid_dx;
   fz *= grid_inv_dx;
   
   return trilerp( grid(i,j,k),     grid(i+1,j,k),
                   grid(i,j+1,k),   grid(i+1,j+1,k),
                   grid(i,j,k+1),   grid(i+1,j,k+1),
                   grid(i,j+1,k+1), grid(i+1,j+1,k+1),
                   fx, fy, fz );

}


// ---------------------------------------------------------
///
/// 
///
// ---------------------------------------------------------

void fluid_extrapolate( const Array3d& f, Array3d& extrapolated_f )
{
   assert( extrapolated_f.ni == f.ni + 2 );
   assert( extrapolated_f.nj == f.nj + 2 );
   assert( extrapolated_f.nk == f.nk + 2 );

   // interior
   for ( int i = 0; i < f.ni; ++i )
   {
      for ( int j = 0; j < f.nj; ++j )
      {
         for ( int k = 0; k < f.nk; ++k )
         {
            extrapolated_f(i+1,j+1,k+1) = f(i,j,k);
         }
      }
   }
   
   // i low and high
   for ( int j = 0; j < f.nj; ++j )
   {
      for ( int k = 0; k < f.nk; ++k )
      {
         extrapolated_f( 0,      j+1, k+1 ) = 2.0f * f(0,j,k) - f(1,j,k);
         extrapolated_f( f.ni+1, j+1, k+1 ) = 2.0f * f( f.ni-1, j, k ) - f( f.ni-2, j, k );
      }
   }

   // j low and high
   for ( int i = 0; i < f.ni; ++i )
   {
      for ( int k = 0; k < f.nk; ++k )
      {
         extrapolated_f( i+1, 0,      k+1 ) = 2.0f * f(i,0,k) - f(i,1,k);
         extrapolated_f( i+1, f.nj+1, k+1 ) = 2.0f * f( i, f.nj-1, k ) - f( i, f.nj-2, k );
      }
   }

   // k low and high
   for ( int i = 0; i < f.ni; ++i )
   {
      for ( int j = 0; j < f.nj; ++j )
      {
         extrapolated_f( i+1, j+1, 0      ) = 2.0f * f(i,j,0) - f(i,j,1);
         extrapolated_f( i+1, j+1, f.nk+1 ) = 2.0f * f(i,j,f.nk-1) - f(i,j,f.nk-2);
      }
   }
   
   // corners
   unsigned int last_i = extrapolated_f.ni-1, 
                last_j = extrapolated_f.nj-1,
                last_k = extrapolated_f.nk-1;
   
   extrapolated_f( 0, 0, 0 ) = ( 2 * extrapolated_f( 1,0,0 ) - extrapolated_f( 2, 0, 0 ) + 
                                 2 * extrapolated_f( 0, 1, 0 ) - extrapolated_f( 0, 2, 0 ) + 
                                 2 * extrapolated_f( 0, 0, 1 ) - extrapolated_f( 0, 0, 2 ) ) / 3.0f;

   extrapolated_f( last_i, 0, 0 ) = ( 2 * extrapolated_f( last_i - 1, 0, 0 ) - extrapolated_f( last_i - 2, 0, 0 ) + 
                                      2 * extrapolated_f( last_i, 1, 0 ) - extrapolated_f( last_i, 2, 0 ) + 
                                      2 * extrapolated_f( last_i, 0, 1 ) - extrapolated_f( last_i, 0, 2 )  ) / 3.0f;
   
   extrapolated_f( 0, last_j, 0 ) = ( 2 * extrapolated_f( 1, last_j, 0 ) - extrapolated_f( 2, last_j, 0 ) + 
                                      2 * extrapolated_f( 0, last_j - 1, 0 ) - extrapolated_f( 0, last_j - 2, 0 ) +
                                      2 * extrapolated_f( 0, last_j, 1 ) - extrapolated_f( 0, last_j, 2 ) ) / 3.0f;

   extrapolated_f( last_i, last_j, 0 ) = ( 2 * extrapolated_f( last_i - 1, last_j, 0 ) - extrapolated_f( last_i - 2, last_j, 0 ) + 
                                           2 * extrapolated_f( last_i, last_j - 1, 0 ) - extrapolated_f( last_i, last_j - 2, 0 ) +
                                           2 * extrapolated_f( last_i, last_j, 1 ) - extrapolated_f( last_i, last_j, 2 ) ) / 3.0f;
   
   extrapolated_f( 0, 0, last_k ) = ( 2 * extrapolated_f( 1, 0, last_k ) - extrapolated_f( 2, 0, last_k ) + 
                                      2 * extrapolated_f( 0, 1, last_k ) - extrapolated_f( 0, 2, last_k ) +
                                      2 * extrapolated_f( 0, 0, last_k - 1 ) - extrapolated_f( 0, 0, last_k - 2 ) ) / 3.0f;
      
   extrapolated_f( last_i, 0, last_k ) = ( 2 * extrapolated_f( last_i - 1, 0, last_k ) - extrapolated_f( last_i - 2, 0, last_k ) + 
                                           2 * extrapolated_f( last_i, 1, last_k ) - extrapolated_f( last_i,  2, last_k ) +
                                           2 * extrapolated_f( last_i, 0, last_k - 1 ) - extrapolated_f( last_i, 0, last_k - 2 ) ) / 3.0f;

   extrapolated_f( 0, last_j, last_k ) = ( 2 * extrapolated_f( 1, last_j, last_k ) - extrapolated_f(  2, last_j, last_k ) + 
                                           2 * extrapolated_f( 0, last_j - 1, last_k ) - extrapolated_f( 0, last_j - 2, last_k ) +
                                           2 * extrapolated_f( 0, last_j, last_k - 1 ) - extrapolated_f( 0, last_j, last_k - 2 ) ) / 3.0f;

   extrapolated_f( last_i, last_j, last_k ) = ( 2 * extrapolated_f( last_i - 1, last_j, last_k ) - extrapolated_f( last_i - 2, last_j, last_k ) + 
                                                2 * extrapolated_f( last_i, last_j - 1, last_k ) - extrapolated_f( last_i, last_j - 2, last_k ) +
                                                2 * extrapolated_f( last_i, last_j, last_k - 1 ) - extrapolated_f( last_i, last_j, last_k - 2 ) ) / 3.0f;
   
}                                                                 


// ---------------------------------------------------------
// Member function definitions
// ---------------------------------------------------------

// ---------------------------------------------------------
///
/// Constructor
///
// ---------------------------------------------------------

GridFluidSim::GridFluidSim( const Vec3d& grid_origin, const Vec3d& grid_high_bound, double grid_dx, double in_gravity ) :
   m_gravity( in_gravity )
{
   m_phi_grid.origin = grid_origin;
   m_phi_grid.dx = grid_dx;
   m_phi_grid.over_dx = 1.f / grid_dx;
   
   const int phi_ni = 1 + (int) ( (grid_high_bound[0] - grid_origin[0]) * m_phi_grid.over_dx );
   const int phi_ny = 1 + (int) ( (grid_high_bound[1] - grid_origin[1]) * m_phi_grid.over_dx );
   const int phi_nz = 1 + (int) ( (grid_high_bound[2] - grid_origin[2]) * m_phi_grid.over_dx );
   
   m_fluid_phi.resize( phi_ni, phi_ny, phi_nz );
   m_pressure.resize( phi_ni, phi_ny, phi_nz );
   
   new ( &m_sim_u ) Array3d( phi_ni + 1, phi_ny,     phi_nz,     0.0f );
   new ( &m_sim_v ) Array3d( phi_ni,     phi_ny + 1, phi_nz,     0.0f );
   new ( &m_sim_w ) Array3d( phi_ni,     phi_ny,     phi_nz + 1, 0.0f );
   
   
   // set up solid boundaries
   new ( &m_vol_fraction_u ) Array3d( m_fluid_phi.ni + 1, m_fluid_phi.nj, m_fluid_phi.nk, 1.0f );
   for ( int j = 0; j < m_vol_fraction_u.nj; ++j )
   {
      for ( int k = 0; k < m_vol_fraction_u.nk; ++k )
      {
         m_vol_fraction_u( 0, j, k ) = 0.0f;
         m_vol_fraction_u( 1, j, k ) = 0.0f;
         m_vol_fraction_u( m_vol_fraction_u.ni-1, j, k ) = 0.0f;
         m_vol_fraction_u( m_vol_fraction_u.ni-2, j, k ) = 0.0f;
         
         for ( int i = 0; i < m_vol_fraction_u.ni; ++i )
         {
            m_vol_fraction_u( i, j, 0 ) = 0.0f;
            m_vol_fraction_u( i, 0, k ) = 0.0f;            
            m_vol_fraction_u( i, j, m_vol_fraction_u.nk-1 ) = 0.0f;
            m_vol_fraction_u( i, m_vol_fraction_u.nj-1, k ) = 0.0f;            
         }
      }
   }
   
   new ( &m_vol_fraction_v ) Array3d( m_fluid_phi.ni, m_fluid_phi.nj + 1, m_fluid_phi.nk, 1.0f );
   for ( int i = 0; i < m_vol_fraction_v.ni; ++i )
   {
      for ( int k = 0; k < m_vol_fraction_v.nk; ++k )
      {
         m_vol_fraction_v( i, 0, k ) = 0.0f;
         m_vol_fraction_v( i, 1, k ) = 0.0f;
         m_vol_fraction_v( i, m_vol_fraction_v.nj-1, k ) = 0.0f;
         m_vol_fraction_v( i, m_vol_fraction_v.nj-2, k ) = 0.0f;
         
         for ( int j = 0; j < m_vol_fraction_v.nj; ++j )
         {
            m_vol_fraction_v( i, j, 0 ) = 0.0f;
            m_vol_fraction_v( i, j, m_vol_fraction_v.nk-1 ) = 0.0f;
            m_vol_fraction_v( 0, j, k ) = 0.0f;
            m_vol_fraction_v( m_vol_fraction_v.ni-1, j, k ) = 0.0f;         
         }
      }
   }         
   
   
   new ( &m_vol_fraction_w ) Array3d( m_fluid_phi.ni, m_fluid_phi.nj, m_fluid_phi.nk + 1, 1.0f );
   for ( int i = 0; i < m_vol_fraction_w.ni; ++i )
   {
      for ( int j = 0; j < m_vol_fraction_w.nj; ++j )
      {
         m_vol_fraction_w( i, j, 0 ) = 0.0f;
         m_vol_fraction_w( i, j, 1 ) = 0.0f;
         m_vol_fraction_w( i, j, m_vol_fraction_w.nk-1 ) = 0.0f;
         m_vol_fraction_w( i, j, m_vol_fraction_w.nk-2 ) = 0.0f;
         
         for ( int k = 0; k < m_vol_fraction_w.nk; ++k )
         {
            m_vol_fraction_w( 0, j, k ) = 0.0f;
            m_vol_fraction_w( i, 0, k ) = 0.0f;            
            m_vol_fraction_w( m_vol_fraction_w.ni-1, j, k ) = 0.0f;
            m_vol_fraction_w( i, m_vol_fraction_w.nj-1, k ) = 0.0f;                        
         }
      }
   }            
   
}


// ---------------------------------------------------------
///
///
///
// ---------------------------------------------------------

void GridFluidSim::apply_boundary_conditions()
{
   // Set velocity at solid wall boundaries
   
   for ( int j = 0; j < m_sim_u.nj; ++j )
   {
      for ( int k = 0; k < m_sim_u.nk; ++k )
      {
         m_sim_u(0, j, k) = 0.0f;
         m_sim_u(1, j, k) = 0.0f;         
         m_sim_u(m_sim_u.ni-1, j, k) = 0.0f;
         m_sim_u(m_sim_u.ni-2, j, k) = 0.0f;         
      }
   }
   
   for ( int i = 0; i < m_sim_v.ni; ++i )
   {
      for ( int k = 0; k < m_sim_v.nk; ++k )
      {
         m_sim_v(i, 0, k) = 0.0f;
         m_sim_v(i, 1, k) = 0.0f;         
         m_sim_v(i, m_sim_v.nj-1, k) = 0.0f;
         m_sim_v(i, m_sim_v.nj-2, k) = 0.0f;         
      }
   }
   
   for ( int i = 0; i < m_sim_w.ni; ++i )
   {
      for ( int j = 0; j < m_sim_w.nj; ++j )
      {
         m_sim_w(i, j, 0) = 0.0f;
         m_sim_w(i, j, 1) = 0.0f;         
         m_sim_w(i, j, m_sim_w.nk-1) = 0.0f;
         m_sim_w(i, j, m_sim_w.nk-2) = 0.0f;         
      }
   }
   
}


// ---------------------------------------------------------
///
/// 
///
// ---------------------------------------------------------

void GridFluidSim::extrapolate_phi_into_solid()
{
   int lastx = m_fluid_phi.ni-1;
   int lasty = m_fluid_phi.nj-1;
   int lastz = m_fluid_phi.nk-1;   
   
   // Extend fluid signed distance into solid boundary
   for ( int j = 0; j < m_fluid_phi.nj; ++j )
   {
      for ( int k = 0; k < m_fluid_phi.nk; ++k )
      {
         m_fluid_phi(0, j, k) = m_fluid_phi(1, j, k);
         m_fluid_phi(lastx, j, k) = m_fluid_phi(lastx-1, j, k);
      }
   }
   
   for ( int i = 0; i < m_fluid_phi.ni; ++i )
   {
      for ( int k = 0; k < m_fluid_phi.nk; ++k )
      {
         m_fluid_phi(i, 0, k) = m_fluid_phi(i, 1, k);
         m_fluid_phi(i, lasty, k) = m_fluid_phi(i, lasty-1, k);
      }
   }
   
   for ( int i = 0; i < m_fluid_phi.ni; ++i )
   {
      for ( int j = 0; j < m_fluid_phi.nj; ++j )
      {
         m_fluid_phi(i, j, 0) = m_fluid_phi(i, j, 1);
         m_fluid_phi(i, j, lastz) = m_fluid_phi(i, j, lastz-1);
      }
   }
   
   // corners
   m_fluid_phi(0,0,0) = m_fluid_phi(1,1,1);
   m_fluid_phi(lastx,0,0) = m_fluid_phi(lastx-1,1,1);
   m_fluid_phi(0,lasty,0) = m_fluid_phi(1,lasty-1,1);
   m_fluid_phi(0,0,lastz) = m_fluid_phi(1,1,lastz-1);
   m_fluid_phi(lastx,lasty,0) = m_fluid_phi(lastx-1,lasty-1,1);
   m_fluid_phi(lastx,0,lastz) = m_fluid_phi(lastx-1,1,lastz-1);
   m_fluid_phi(0,lasty,lastz) = m_fluid_phi(1,lasty-1,lastz-1);
   m_fluid_phi(lastx,lasty,lastz) = m_fluid_phi(lastx-1,lasty-1,lastz-1);
   
}


// ---------------------------------------------------------
///
///
///
// ---------------------------------------------------------

void GridFluidSim::project_velocity( double dt )
{
   SparseMatrixDynamicCSR laplace_matrix( m_vol_fraction_v.ni * m_vol_fraction_u.nj * m_vol_fraction_u.nk );
   
   std::vector<double> right_hand_side;
   right_hand_side.resize( laplace_matrix.n );
   
   add_fluid_to_pressure_projection( m_phi_grid, dt, 1.0f,
                                     m_vol_fraction_u, m_vol_fraction_v, m_vol_fraction_w,
                                     m_sim_u, m_sim_v, m_sim_w,
                                     m_fluid_phi,
                                     laplace_matrix,
                                     right_hand_side );
   
   double *c_rhs = new double[right_hand_side.size()];
   double *c_x = new double[right_hand_side.size()];
   for ( unsigned int i = 0; i < right_hand_side.size(); ++i ) { c_rhs[i] = right_hand_side[i]; }
   
   std::cout << "poisson solve... ";
   
   CG_Solver solver;
   solver.max_iterations = 1000;

   KrylovSolverStatus status = solver.solve( laplace_matrix, c_rhs, c_x );

   assert( status == KRYLOV_CONVERGED );
   
   std::cout << "done." << std::endl;
   
   std::vector<double> solution( right_hand_side.size() );
   for ( unsigned int i = 0; i < solution.size(); ++i ) { solution[i] = c_x[i]; }
   
   update_fluid_velocities( m_phi_grid, 
                            dt, 
                            1.0f, 
                            solution,
                            m_fluid_phi,
                            m_sim_u, m_sim_v, m_sim_w );
   
   delete[] c_rhs;
   delete[] c_x;
   
}


// ---------------------------------------------------------
///
///
///
// ---------------------------------------------------------

void GridFluidSim::extend_velocity( const DynamicSurface& surf, Array3d& vel, unsigned int offset_i, unsigned int offset_j, unsigned int offset_k  )
{
   Vec3d field_origin = m_phi_grid.origin;
   field_origin -= Vec3d( 0.5f * m_phi_grid.dx * offset_i, 0.5f * m_phi_grid.dx * offset_j, 0.5f * m_phi_grid.dx * offset_k );
   
   for ( unsigned int i = offset_i; i < vel.ni - offset_i; ++i )
   {
      for ( unsigned int j = offset_j; j < vel.nj - offset_j; ++j )
      {
         for ( unsigned int k = offset_k; k < vel.nk - offset_k; ++k )
         {
            double field_point_m_fluid_phi = lerp( m_fluid_phi(i-offset_i, j-offset_j, k-offset_k), m_fluid_phi(i,j,k), 0.5f );
            if ( field_point_m_fluid_phi < 0.0 )
            {
               continue;
            }
            
            Vec3d field_point( m_phi_grid.dx * i + field_origin[0], 
                               m_phi_grid.dx * j + field_origin[1], 
                               m_phi_grid.dx * k + field_origin[2] );
            
            // get phi points on either side of the current velocity point
            int tri0 = m_closest_tris( i - offset_i, j - offset_j, k - offset_k );
            int tri1 = m_closest_tris( i, j, k );
            
            // get the closest two triangles, then the six closest mesh points
            std::vector<Vec3d> mesh_points;
            mesh_points.push_back( surf.m_positions[ surf.m_mesh.m_tris[tri0][0] ] );
            mesh_points.push_back( surf.m_positions[ surf.m_mesh.m_tris[tri0][1] ] );
            mesh_points.push_back( surf.m_positions[ surf.m_mesh.m_tris[tri0][2] ] );
            mesh_points.push_back( surf.m_positions[ surf.m_mesh.m_tris[tri1][0] ] );
            mesh_points.push_back( surf.m_positions[ surf.m_mesh.m_tris[tri1][1] ] );
            mesh_points.push_back( surf.m_positions[ surf.m_mesh.m_tris[tri1][2] ] );
            
            // find the minimum distance out of the six mesh points
            double min_dist = 1e30;
            unsigned int min_dist_index = 6;
            for ( unsigned int p = 0; p < 6; ++p )
            {
               double dist = mag( mesh_points[p] - field_point );
               if ( dist <  min_dist)
               {
                  min_dist = dist;
                  min_dist_index = p;
               }
            }
            
            // evaulate the velocity at this closest mesh point (interpolate from the grid)
            int p_i, p_j, p_k;
            double bary_i, bary_j, bary_k;
            get_barycentric( (mesh_points[min_dist_index][0] - field_origin[0])/m_phi_grid.dx, p_i, bary_i, 0, vel.ni );
            get_barycentric( (mesh_points[min_dist_index][1] - field_origin[1])/m_phi_grid.dx, p_j, bary_j, 0, vel.nj );
            get_barycentric( (mesh_points[min_dist_index][2] - field_origin[2])/m_phi_grid.dx, p_k, bary_k, 0, vel.nk );
            
            vel(i,j,k) = trilerp( vel(p_i, p_j,   p_k),   vel(p_i+1, p_j,   p_k), 
                                  vel(p_i, p_j+1, p_k),   vel(p_i+1, p_j+1, p_k), 
                                  vel(p_i, p_j,   p_k+1), vel(p_i+1, p_j,   p_k+1), 
                                  vel(p_i, p_j+1, p_k+1), vel(p_i+1, p_j+1, p_k+1),
                                  bary_i, bary_j, bary_k );
         }
      }
   }
   
}


// ---------------------------------------------------------
///
/// Transfer velocity from grid sim to mesh vertices
///
// ---------------------------------------------------------

void GridFluidSim::apply_grid_velocity_to_mesh( const DynamicSurface& surf, std::vector<Vec3d>& mesh_velocities )
{
   const std::vector<Vec3d>& mesh_points = surf.m_positions;
   
   // u
   {
      Vec3d field_origin( m_phi_grid.origin[0] - 0.5*m_phi_grid.dx, m_phi_grid.origin[1], m_phi_grid.origin[2] );
      for ( unsigned int i = 0; i < mesh_points.size(); ++i )
      {
         int p_i, p_j, p_k;
         double bary_i, bary_j, bary_k;
         get_barycentric( (mesh_points[i][0] - field_origin[0]) * m_phi_grid.over_dx, p_i, bary_i, 0, m_sim_u.ni );
         get_barycentric( (mesh_points[i][1] - field_origin[1]) * m_phi_grid.over_dx, p_j, bary_j, 0, m_sim_u.nj );
         get_barycentric( (mesh_points[i][2] - field_origin[2]) * m_phi_grid.over_dx, p_k, bary_k, 0, m_sim_u.nk );
         
         mesh_velocities[i][0] = trilerp( m_sim_u(p_i, p_j,   p_k),
                                          m_sim_u(p_i+1, p_j,   p_k),
                                          m_sim_u(p_i, p_j+1, p_k),
                                          m_sim_u(p_i+1, p_j+1, p_k),
                                          m_sim_u(p_i, p_j,   p_k+1),
                                          m_sim_u(p_i+1, p_j,   p_k+1),
                                          m_sim_u(p_i, p_j+1, p_k+1),
                                          m_sim_u(p_i+1, p_j+1, p_k+1),
                                          bary_i, bary_j, bary_k );
      }
   }
   
   // v
   {
      Vec3d field_origin(  m_phi_grid.origin[0], m_phi_grid.origin[1] - 0.5 * m_phi_grid.dx, m_phi_grid.origin[2] );
      for ( unsigned int i = 0; i < mesh_points.size(); ++i )
      {
         int p_i, p_j, p_k;
         double bary_i, bary_j, bary_k;
         get_barycentric( (mesh_points[i][0] - field_origin[0]) * m_phi_grid.over_dx, p_i, bary_i, 0, m_sim_v.ni );
         get_barycentric( (mesh_points[i][1] - field_origin[1]) * m_phi_grid.over_dx, p_j, bary_j, 0, m_sim_v.nj );
         get_barycentric( (mesh_points[i][2] - field_origin[2]) * m_phi_grid.over_dx, p_k, bary_k, 0, m_sim_v.nk );
         
         mesh_velocities[i][1] = trilerp( m_sim_v(p_i, p_j,   p_k),   m_sim_v(p_i+1, p_j,   p_k), 
                                          m_sim_v(p_i, p_j+1, p_k),   m_sim_v(p_i+1, p_j+1, p_k), 
                                          m_sim_v(p_i, p_j,   p_k+1), m_sim_v(p_i+1, p_j,   p_k+1), 
                                          m_sim_v(p_i, p_j+1, p_k+1), m_sim_v(p_i+1, p_j+1, p_k+1),
                                          bary_i, bary_j, bary_k );
      }
   }
   
   // w
   {
      Vec3d field_origin( m_phi_grid.origin[0], m_phi_grid.origin[1], m_phi_grid.origin[2] - 0.5*m_phi_grid.dx );
      for ( unsigned int i = 0; i < mesh_points.size(); ++i )
      {
         int p_i, p_j, p_k;
         double bary_i, bary_j, bary_k;
         get_barycentric( (mesh_points[i][0] - field_origin[0]) * m_phi_grid.over_dx, p_i, bary_i, 0, m_sim_w.ni );
         get_barycentric( (mesh_points[i][1] - field_origin[1]) * m_phi_grid.over_dx, p_j, bary_j, 0, m_sim_w.nj );
         get_barycentric( (mesh_points[i][2] - field_origin[2]) * m_phi_grid.over_dx, p_k, bary_k, 0, m_sim_w.nk );
         
         mesh_velocities[i][2] = trilerp( m_sim_w(p_i, p_j,   p_k),   m_sim_w(p_i+1, p_j,   p_k), 
                                          m_sim_w(p_i, p_j+1, p_k),   m_sim_w(p_i+1, p_j+1, p_k), 
                                          m_sim_w(p_i, p_j,   p_k+1), m_sim_w(p_i+1, p_j,   p_k+1), 
                                          m_sim_w(p_i, p_j+1, p_k+1), m_sim_w(p_i+1, p_j+1, p_k+1),
                                          bary_i, bary_j, bary_k );
      }
   }
   
}

// ---------------------------------------------------------
///
/// Get fluid phi from the mesh
///
// ---------------------------------------------------------

void GridFluidSim::compute_signed_distance( const DynamicSurface& surf )
{
   // compute signed distance
   
   make_level_set3( surf.m_mesh.m_tris, 
                    surf.m_positions, 
                    m_phi_grid.origin, 
                    m_phi_grid.dx, 
                    m_fluid_phi.ni, 
                    m_fluid_phi.nj, 
                    m_fluid_phi.nk, 
                    m_fluid_phi, 
                    m_closest_tris );
     
   // Now...  If any cell is marked as air but actually contains a mesh vertex, set the value of that cell to some small negative number
   for ( int i = 0; i < m_fluid_phi.ni; ++i )
   {
      for ( int j = 0; j < m_fluid_phi.nj; ++j )   
      {
         for ( int k = 0; k < m_fluid_phi.nk; ++k )
         {
            //m_fluid_phi(i,j,k) -= 0.5 * m_phi_grid.dx;
            
            if ( m_fluid_phi(i,j,k) > 0.0f )
            {
               // check for mesh vertices in this cell
               Vec3d cell_low( m_phi_grid.dx * ((double)i-0.5) , m_phi_grid.dx * ((double)j-0.5), m_phi_grid.dx * ((double)k-0.5) );
               Vec3d cell_high( m_phi_grid.dx * ((double)i+0.5) , m_phi_grid.dx * ((double)j+0.5), m_phi_grid.dx * ((double)k+0.5) );               
               
               std::vector<unsigned int> overlapping_elements;
               surf.m_broad_phase->get_potential_triangle_collisions( cell_low, cell_high, overlapping_elements);
               
               if ( overlapping_elements.size() > 0 )
               {
                  m_fluid_phi(i,j,k) = -0.1 * m_phi_grid.dx;
               }
            }

         }
      }
   }
   
}


// ---------------------------------------------------------
///
/// 
///
// ---------------------------------------------------------

void GridFluidSim::apply_forces( const DynamicSurface& surf, double dt )
{
   // apply gravity
   for ( int i = 0; i < m_sim_v.ni; ++i )
   {
      for ( int j = 1; j < m_sim_v.nj-1; ++j )
      {
         for ( int k = 0; k < m_sim_v.nk; ++ k )
         {
            double v_m_fluid_phi = lerp( m_fluid_phi(i,j-1,k), m_fluid_phi(i,j,k), 0.5f );
            
            if ( v_m_fluid_phi < 0.0f )
            {
               Vec3d p( m_phi_grid.origin[0], m_phi_grid.origin[1] - 0.5*m_phi_grid.dx, m_phi_grid.origin[2] );
               p += Vec3d( m_phi_grid.dx * i, m_phi_grid.dx * j, m_phi_grid.dx * k );
               //std::cout << "(" << i << ", " << j << ", " << k << "): " << mag( p - Vec3d( 0.0, 5.0, 0.0 ) ) << std::endl;
               m_sim_v(i,j,k) += m_gravity * dt;
            }
         }
      }
   }
}



// ---------------------------------------------------------
///
/// Velocity self-advection using semi-Lagrangian advection
///
// ---------------------------------------------------------

void GridFluidSim::advect_velocity( double dt )
{
   // f( x, t + dt ) = f( x - dt*u, t )
   
   Array3d new_u( m_sim_u.ni, m_sim_u.nj, m_sim_u.nk );
   Array3d new_v( m_sim_v.ni, m_sim_v.nj, m_sim_v.nk );
   Array3d new_w( m_sim_w.ni, m_sim_w.nj, m_sim_w.nk );
   
   Array3d extrapolated_u( m_sim_u.ni+2, m_sim_u.nj+2, m_sim_u.nk+2 );
   Array3d extrapolated_v( m_sim_v.ni+2, m_sim_v.nj+2, m_sim_v.nk+2 );
   Array3d extrapolated_w( m_sim_w.ni+2, m_sim_w.nj+2, m_sim_w.nk+2 );
   
   fluid_extrapolate( m_sim_u, extrapolated_u );
   fluid_extrapolate( m_sim_v, extrapolated_v );
   fluid_extrapolate( m_sim_w, extrapolated_w );
      
   // ApplyBoundaryConditions( extrapolated_u, extrapolated_v, extrapolated_w ) ???

   Vec3d u_origin = m_phi_grid.origin - 0.5f * m_phi_grid.dx * Vec3d( 1.0f, 0.0f, 0.0f );
   Vec3d v_origin = m_phi_grid.origin - 0.5f * m_phi_grid.dx * Vec3d( 0.0f, 1.0f, 0.0f );   
   Vec3d w_origin = m_phi_grid.origin - 0.5f * m_phi_grid.dx * Vec3d( 0.0f, 0.0f, 1.0f );
   
   Vec3d extrapolated_u_origin = u_origin - m_phi_grid.dx * Vec3d( 1.0f, 1.0f, 1.0f );
   Vec3d extrapolated_v_origin = v_origin - m_phi_grid.dx * Vec3d( 1.0f, 1.0f, 1.0f );
   Vec3d extrapolated_w_origin = w_origin - m_phi_grid.dx * Vec3d( 1.0f, 1.0f, 1.0f );
   
   //
   // Advect u
   //
   
   for ( int i = 0; i < m_sim_u.ni; ++i )
   {
      for( int j = 0; j < m_sim_u.nj; ++j )
      {
         for( int k = 0; k < m_sim_u.nk; ++k )
         { 
            Vec3d current_node_position = u_origin + m_phi_grid.dx * Vec3d( i, j, k );
            
            double interpolated_v = fluid_trilerp( current_node_position, extrapolated_v_origin, m_phi_grid.dx, m_phi_grid.over_dx, extrapolated_v );
            double interpolated_w = fluid_trilerp( current_node_position, extrapolated_w_origin, m_phi_grid.dx, m_phi_grid.over_dx, extrapolated_w );
            
            Vec3d velocity_at_current_node( m_sim_u(i,j,k), interpolated_v, interpolated_w );
            
            Vec3d previous_node_position = current_node_position - dt * velocity_at_current_node;
            
            // interpolate to get new value
            new_u(i,j,k) = fluid_trilerp( previous_node_position, extrapolated_u_origin, m_phi_grid.dx, m_phi_grid.over_dx, extrapolated_u );
         }
      }
   }
   
   //
   // Advect v
   //
   for ( int i = 0; i < m_sim_v.ni; ++i )
   {
      for( int j = 0; j < m_sim_v.nj; ++j )
      {
         for( int k = 0; k < m_sim_v.nk; ++k )
         { 
            Vec3d current_node_position = v_origin + m_phi_grid.dx * Vec3d( i, j, k );
            
            double interpolated_u = fluid_trilerp( current_node_position, extrapolated_u_origin, m_phi_grid.dx, m_phi_grid.over_dx, extrapolated_u );
            double interpolated_w = fluid_trilerp( current_node_position, extrapolated_w_origin, m_phi_grid.dx, m_phi_grid.over_dx, extrapolated_w );
            
            Vec3d velocity_at_current_node( interpolated_u, m_sim_v(i,j,k), interpolated_w );
            
            Vec3d previous_node_position = current_node_position - dt * velocity_at_current_node;
                       
            // interpolate to get new value
            new_v(i,j,k) = fluid_trilerp( previous_node_position, extrapolated_v_origin, m_phi_grid.dx, m_phi_grid.over_dx, extrapolated_v );
         }
      }
   }
   
   std::cout << std::endl;
   
   //
   // Advect w
   //
   for ( int i = 0; i < m_sim_w.ni; ++i )
   {
      for( int j = 0; j < m_sim_w.nj; ++j )
      {
         for( int k = 0; k < m_sim_w.nk; ++k )
         { 
            Vec3d current_node_position = w_origin + m_phi_grid.dx * Vec3d( i, j, k );

            double interpolated_u = fluid_trilerp( current_node_position, extrapolated_u_origin, m_phi_grid.dx, m_phi_grid.over_dx, extrapolated_u );
            double interpolated_v = fluid_trilerp( current_node_position, extrapolated_v_origin, m_phi_grid.dx, m_phi_grid.over_dx, extrapolated_v );
            
            Vec3d velocity_at_current_node( interpolated_u, interpolated_v, m_sim_w(i,j,k) );
            
            Vec3d previous_node_position = current_node_position - dt * velocity_at_current_node;
            
            // interpolate to get new value
            new_w(i,j,k) = fluid_trilerp( previous_node_position, extrapolated_w_origin, m_phi_grid.dx, m_phi_grid.over_dx, extrapolated_w );
         }
      }
   }
   
   m_sim_u = new_u;
   m_sim_v = new_v;
   m_sim_w = new_w;

}



// ---------------------------------------------------------
///
///
///
// ---------------------------------------------------------

void GridFluidSim::set_surface_velocity( const DynamicSurface& surf, 
                                         std::vector<Vec3d>& out_velocity, 
                                         double current_t, 
                                         double& adaptive_dt )
{
   
   std::cout << " -------------- fluid sim update -------------------- " << std::endl;
      
   compute_signed_distance( surf );

   extrapolate_phi_into_solid();
      
   apply_forces( surf, adaptive_dt );      // gravity, etc.
   
   apply_boundary_conditions();
   
   project_velocity( adaptive_dt );
   
   // extend velocity field from liquid into into gas phase
   extend_velocity( surf, m_sim_u, 1, 0, 0 );      
   extend_velocity( surf, m_sim_v, 0, 1, 0 );      
   extend_velocity( surf, m_sim_w, 0, 0, 1 );      
   
   apply_boundary_conditions();
   
   apply_grid_velocity_to_mesh( surf, out_velocity );
   
   advect_velocity( adaptive_dt );     // using SL advection
   
}


// ---------------------------------------------------------
///
/// 
///
// ---------------------------------------------------------

void GridFluidSim::display( const DynamicSurface& surf )
{
   switch ( g_fluid_render_type )
   {
      case 0:
         break;
      case 1:
         render_pressure( m_phi_grid.origin, m_phi_grid.dx, m_pressure );
         break;
      case 2:
         render_signed_distance( m_phi_grid.origin, m_phi_grid.dx, m_fluid_phi );
         break;
      case 3:
         render_velocity( m_phi_grid.origin, m_phi_grid.dx, m_sim_u, m_sim_v, m_sim_w );
         break;
      case 4:
         render_solid( m_phi_grid.origin, m_phi_grid.dx, m_sim_u, m_sim_v, m_sim_w );
         break;
      default:
         assert(0);
   }
         
}


// ---------------------------------------------------------
///
/// 
///
// ---------------------------------------------------------

void render_pressure( const Vec3d& origin, double dx, const Array3d& m_pressure )
{   
   glDisable(GL_LIGHTING);
   glPointSize(4.0f);
   glBegin( GL_POINTS );
   
   for ( int i = 0; i < m_pressure.ni; ++i )
   {
      for ( int j = 0; j < m_pressure.nj; ++j )
      {
         for ( int k = 0; k < m_pressure.nk; ++k )
         {        
            Vec3d x = origin + dx * Vec3d( i, j, k );
            glColor3d( m_pressure(i,j,k), m_pressure(i,j,k), 0.f );
            glVertex3dv( x.v );
         }
      }
   }
   glEnd();
   glEnable(GL_LIGHTING);
}


// ---------------------------------------------------------
///
/// 
///
// ---------------------------------------------------------

void render_signed_distance( const Vec3d& origin, double dx, const Array3d& phi )
{
   glDisable(GL_LIGHTING);
   glPointSize(4.0f);
   glBegin( GL_POINTS );
   
   for ( int i = 0; i < phi.ni; ++i )
   {
      for ( int j = 0; j < phi.nj; ++j )
      {
         for ( int k = 0; k < phi.nk; ++k )
         {        
            Vec3d x = origin + dx * Vec3d( i, j, k );
            
            if ( phi(i,j,k) < 0.0f )
            {
               glColor3f( 1.0f, 0.f, 0.f );
            }
            else
            {
               glColor3f( 0.f, 1.0f, 0.f );
            }
            
            glVertex3dv( x.v );
         }
      }
   }
   glEnd();
   glEnable(GL_LIGHTING);
}


// ---------------------------------------------------------
///
/// 
///
// ---------------------------------------------------------

void render_velocity( const Vec3d& phi_origin, double dx, const Array3d& u, const Array3d& v, const Array3d& w )
{   
   glDisable(GL_LIGHTING);
   glBegin(GL_LINES);
   glColor3f( 0.f, 0.f, 0.f );
   
   for ( int i = 0; i < v.ni; ++i )
   {
      for ( int j = 0; j < v.nj; ++j )
      {
         for ( int k = 0; k < v.nk; ++k )
         {
            Vec3d x = phi_origin + dx * Vec3d( i, (double)j-0.5f, k );
            glVertex3dv( x.v );            
            Vec3d arrow_head = x + Vec3d(0.f, v(i,j,k), 0.f );
            glVertex3dv( arrow_head.v );
         }
      }
   }
   
   glEnd();
   glEnable(GL_LIGHTING);
}


// ---------------------------------------------------------
///
/// 
///
// ---------------------------------------------------------

void render_solid( const Vec3d& phi_origin, double dx, const Array3d& u, const Array3d& v, const Array3d& w )
{   
   glDisable(GL_LIGHTING);
   glBegin(GL_LINES);
   glColor3f( 0.f, 0.f, 0.f );
   
   for ( int i = 0; i < v.ni; ++i )
   {
      for ( int j = 0; j < v.nj; ++j )
      {
         for ( int k = 0; k < v.nk; ++k )
         {
            if ( v(i,j,k) == 0.0f )
            {
               Vec3d centre = phi_origin + dx * Vec3d( i, (double)j-0.5f, k );
               Vec3d x = centre + 0.5f * dx * Vec3d( -1.0f, 0.0f, -1.0 );
               glVertex3dv( x.v );
               x = centre + 0.5f * dx * Vec3d( 1.0f, 0.0f, -1.0 );
               glVertex3dv( x.v );
               x = centre + 0.5f * dx * Vec3d( 1.0f, 0.0f, 1.0 );
               glVertex3dv( x.v );
               x = centre + 0.5f * dx * Vec3d( -1.0f, 0.0f, 1.0 );
               glVertex3dv( x.v );
               x = centre + 0.5f * dx * Vec3d( -1.0f, 0.0f, -1.0 );
               glVertex3dv( x.v );
            }            
         }
      }
   }
   
   glEnd();
   glEnable(GL_LIGHTING);
}
