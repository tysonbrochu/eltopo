
//
// Courtesy Christopher Batty
//

#ifndef PRESSURE3D_H
#define PRESSURE3D_H

#include <array3.h>
#include <grid3.h>
#include <sparse_matrix.h>

void add_fluid_to_pressure_projection(
   const Grid3d &grid,
   const double dt,
   const double fluid_density,
   const Array3d &vol_fraction_u,
   const Array3d &vol_fraction_v,
   const Array3d &vol_fraction_w,
   const Array3d &input_u,
   const Array3d &input_v,
   const Array3d &input_w,
   const Array3d &liquid_phi,
   SparseMatrixDynamicCSR& matrix,
   std::vector<double> &right_hand_side);

void update_fluid_velocities(
   const Grid3d &grid,
   const double dt,
   const double fluid_density,
   const std::vector<double> &solution,
   const Array3d& liquid_phi,
   Array3d &u,
   Array3d &v,
   Array3d &w);

void add_scripted_region(
      const Grid3d &grid,
   const Array3d &vol_u,
   const Array3d &vol_v,
   const Array3d &vol_w,
   const double dt,
   const Vec3d linear_velocity,
   const Vec3d angular_velocity,
   const Vec3d centre_point,
   std::vector<double> &right_hand_side);


#endif

