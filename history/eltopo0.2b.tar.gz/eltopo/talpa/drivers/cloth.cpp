
// ---------------------------------------------------------
//
//  cloth.cpp
//  Tyson Brochu 2009
//
//  Cloth simulated using springs along edges
//
// ---------------------------------------------------------

#include <cloth.h>

#include <bfstream.h>
#include <dynamicsurface.h>
#include <gluvi.h>
#include <simulation.h>

void create_spring( const DynamicSurface& surf, unsigned int a, unsigned int b, std::vector<Spring>& springs )
{
   static const double SPRING_CONSTANT = 40.0;
   static const double DAMPING_CONSTANT = 10.0;
   
   Spring new_spring;
   
   assert( a < surf.m_positions.size() );
   assert( b < surf.m_positions.size() );

   new_spring.vertex_a = a;
   new_spring.vertex_b = b;
      
   new_spring.rest_length = dist( surf.m_positions[ new_spring.vertex_a ], surf.m_positions[ new_spring.vertex_b ] );
   new_spring.spring_constant = SPRING_CONSTANT;   
   new_spring.damping_constant = DAMPING_CONSTANT;   
   
   springs.push_back( new_spring );
}

extern Simulation* g_sim;

void ClothDriver::initialize( const DynamicSurface& surf )
{
   
   if ( g_sim->m_curr_frame != 0 )
   {
      std::cout << "ClothDriver: loading saved spring data" << std::endl;
      read_springs_from_file( "springs.bin" );
      return;
   }
   
   for ( unsigned int sheet = 0; sheet < num_sheets; ++sheet )
   {
      std::cout << "sheet " << sheet << std::endl;
      
      for ( unsigned int i = 0; i < springs.size(); ++i )
      {
         springs[i].vertex_a += nx*ny;
         springs[i].vertex_b += nx*ny;
      }
      
      for ( unsigned int i = 0; i < ny; ++i )
      {
         for ( unsigned int j = 0; j < nx; ++j )
         {
            // right
            if ( j < nx - 1 )
            {
               create_spring( surf, i*nx + j, i*nx + j+1, springs);
            }
            
            // up
            if ( i < ny - 1 )
            {
               create_spring( surf, i*nx + j, (i+1)*nx + j, springs);
            }
            
            // up right
            if ( i < ny - 1 && j < nx - 1 )
            {
               create_spring( surf, i*nx + j, (i+1)*nx + j+1, springs);
            }
            
            // up left
            if ( i < ny - 1 && j > 0 )
            {
               create_spring( surf, i*nx + j, (i+1)*nx + j-1, springs);
            }
            
            // two right
            if ( j < nx - 2 )
            {
               create_spring( surf, i*nx + j, i*nx + j+2, springs);
            }
            
            // two up
            if ( i < ny - 2 )
            {
               create_spring( surf, i*nx + j, (i+2)*nx + j, springs);
            }
            
         }
      }
           
   }
   
   write_springs_to_file( "springs.bin" );
   
}

void ClothDriver::display( const DynamicSurface& surf )
{
   glDisable(GL_LIGHTING);
   
   glLineWidth(3);
   glColor3d(1.0,0,0);
   
   glBegin(GL_LINES);

    for(unsigned int i = 0; i < springs.size(); i++)
   {
      const Vec3d& vtx0 = surf.m_positions[springs[i].vertex_a];
      const Vec3d& vtx1 = surf.m_positions[springs[i].vertex_b];
      glVertex3d(vtx0[0], vtx0[1], vtx0[2]);
      glVertex3d(vtx1[0], vtx1[1], vtx1[2]);
   }
   
   glEnd();   

   glPointSize(5);
   glColor3d(0.0, 1.0, 0.0);

   glBegin(GL_POINTS);   
   
   for ( unsigned int i = 0; i < surf.m_masses.size(); ++i )
   {
      if ( surf.m_masses[i] > 1.1 )
      {
         const Vec3d& vtx0 = surf.m_positions[i];
         glVertex3d(vtx0[0], vtx0[1], vtx0[2]);
      }
   }
   
   glEnd();
   
}

void ClothDriver::compute_edge_spring_forces( const DynamicSurface& surf, std::vector<Vec3d>& forces )
{
   
   std::cout << "----- CLOTH: springs" << std::endl;
   
   double max_f = -1.0;
   
   for ( unsigned int i = 0; i < springs.size(); ++i )
   {
      unsigned int va = springs[i].vertex_a;
      unsigned int vb = springs[i].vertex_b;
      
      double curr_length = dist( surf.m_positions[va], surf.m_positions[vb] );
      
      double f = springs[i].spring_constant * ( springs[i].rest_length - curr_length );

      max_f = max( max_f, fabs(f) );
      
      Vec3d b_to_a( surf.m_positions[va] - surf.m_positions[vb] );
      normalize(b_to_a);

      Vec3d a_to_b( surf.m_positions[vb] - surf.m_positions[va] );
      normalize(a_to_b);

      forces[va] += f * b_to_a;
      forces[vb] += f * a_to_b;
      
      //
      // damping
      //

      {
         Vec3d relative_velocity = surf.m_velocities[va] - surf.m_velocities[vb];
         double x_dot = dot( relative_velocity, b_to_a );
         //if ( x_dot > 0.0 )
         {
            forces[va] -= springs[i].damping_constant * x_dot * b_to_a;
         }
      }   

      {
         Vec3d relative_velocity = surf.m_velocities[vb] - surf.m_velocities[va];
         double x_dot = dot( relative_velocity, a_to_b );
         //if ( x_dot > 0.0 )
         {
            forces[vb] -= springs[i].damping_constant * x_dot * a_to_b;
         }
      }   
      
   }
   
   std::cout << "max spring force: " << max_f << std::endl;
   
}   

bool contains( const std::vector<unsigned int>& a, unsigned int t )
{
   return ( std::find( a.begin(), a.end(), t ) != a.end() );
}

void ClothDriver::strain_limiting_impulses( const DynamicSurface& surf, std::vector<Vec3d>& velocities, double dt )
{

   std::cout << "----- CLOTH: strain limiting" << std::endl;
      
   std::vector<Vec3d> predicted_positions( velocities.size() );
   for ( unsigned int i = 0; i < velocities.size(); ++i )
   {
      if ( surf.m_masses[i] > 100 ) 
      { 
         predicted_positions[i] = surf.m_positions[i]; 
      }
      else
      {
         predicted_positions[i] = surf.m_positions[i] + dt * velocities[i]; 
      }
   }
   
   bool spring_fixed = true;
   unsigned int num_passes = 0;
   while ( spring_fixed && num_passes++ < 10 )
   {
    
      spring_fixed = false;
               
      for ( unsigned int i = 0; i < springs.size(); ++i )
      {
         unsigned int va = springs[i].vertex_a;
         unsigned int vb = springs[i].vertex_b;
         
         double predicted_length = dist( predicted_positions[va], predicted_positions[vb] );
                  
         double disired_length = 0.0;
         bool should_fix = false;
         if ( predicted_length > 1.1 * springs[i].rest_length )
         {
            disired_length = 1.1 * springs[i].rest_length;
            should_fix = true;
         }

         if ( predicted_length < 0.999 * springs[i].rest_length )
         {
            disired_length = 0.999 * springs[i].rest_length;
            should_fix = true;
         }
         
         if ( should_fix )
         {
            assert( disired_length > 0.0 );
            
            Vec3d midpoint = 0.5 * ( predicted_positions[va] + predicted_positions[vb] );
            Vec3d spring_segment = predicted_positions[va] - predicted_positions[vb];
            
            predicted_positions[va] = midpoint + 0.5 * ( disired_length * spring_segment / mag(spring_segment) );
            predicted_positions[vb] = midpoint - 0.5 * ( disired_length * spring_segment / mag(spring_segment) );
            
            double alpha = 0.5 / dot(spring_segment, spring_segment) * dot( spring_segment, velocities[vb] - velocities[va] );
            
            velocities[va] += alpha * spring_segment;
            velocities[vb] -= alpha * spring_segment;
            
            double new_predicted_length = dist( predicted_positions[va], predicted_positions[vb] );
            
            assert( fabs(new_predicted_length - disired_length) < 1e-10 );
            
            assert( new_predicted_length < 1.1 * springs[i].rest_length + 1e-10 );
            assert( new_predicted_length > 0.999 * springs[i].rest_length - 1e-10 );
            
            Vec3d rel_vel = velocities[vb] - velocities[va];
            double rel_vel_dot_segment = dot( rel_vel, spring_segment );
            assert( fabs( rel_vel_dot_segment ) < 1e-10 );
            
            spring_fixed = true;
         }
         
      }
   }

   // TODO: fix this
   for ( unsigned int i = 0; i < velocities.size(); ++i )
   {
      if ( surf.m_masses[i] < 100 ) 
      {
         velocities[i] = (predicted_positions[i] - surf.m_positions[i]) / dt;
      }
   }
   
}

void ClothDriver::set_surface_velocity( const DynamicSurface& surf, std::vector<Vec3d>& out_velocities, double current_t, double& adaptive_dt )
{   
   std::vector<Vec3d> forces( surf.m_positions.size(), Vec3d(0,0,0) );
   
   compute_edge_spring_forces( surf, forces );
   
   for ( unsigned int i = 0; i < out_velocities.size(); ++i )
   {
      if ( surf.m_masses[i] > 100.0 )
      {
         out_velocities[i] = Vec3d(0,0,0);
      }
      else
      {
         out_velocities[i] += adaptive_dt * Vec3d( 0, -9.8, 0 );
         out_velocities[i] += adaptive_dt * forces[i] / surf.m_masses[i];
      }
   }

   strain_limiting_impulses( surf, out_velocities, adaptive_dt );
   
   for ( unsigned int i = 0; i < constrained_vertices.size(); ++i )
   {
      out_velocities[ constrained_vertices[i] ] = Vec3d(0,0,0);
   }

   std::cout << "----- CLOTH: v[0]: " << out_velocities[0] << std::endl;
   
}


void ClothDriver::write_springs_to_file( const char* filename )
{
   bofstream outfile( filename );
   assert( outfile.good() );
   
   outfile.write_endianity();
   
   outfile << springs.size();
   
   for ( unsigned int i = 0; i < springs.size(); ++i )
   {
      outfile << springs[i].vertex_a;
      outfile << springs[i].vertex_b;
      outfile << springs[i].rest_length;
      outfile << springs[i].spring_constant;
      outfile << springs[i].damping_constant;
   }
   
}

void ClothDriver::read_springs_from_file( const char* filename )
{
   bifstream infile( filename );
   assert( infile.good() );
   
   infile.read_endianity();
   
   unsigned int n;
   infile >> n;
      
   springs.resize(n);
   
   for ( unsigned int i = 0; i < springs.size(); ++i )
   {
      infile >> springs[i].vertex_a;
      infile >> springs[i].vertex_b;
      infile >> springs[i].rest_length;
      infile >> springs[i].spring_constant;
      infile >> springs[i].damping_constant;
   }   
}

