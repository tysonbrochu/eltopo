
// ---------------------------------------------------------
//
//  Tyson Brochu 2009
//  
//
//  
//
// ---------------------------------------------------------

#ifndef GRIDSMOKE_H
#define GRIDSMOKE_H

// ---------------------------------------------------------
//  Nested includes
// ---------------------------------------------------------

#include <gridfluidsim.h>
#include <curlnoise.h>
#include <noise.h>

// ---------------------------------------------------------
//  Forwards and typedefs
// ---------------------------------------------------------

class DynamicSurface;

// ---------------------------------------------------------
//  Interface declarations
// ---------------------------------------------------------

struct SmokeCurlNoise : public CurlNoise3
{
   
   double noise0(double x, double y, double z) const { return noise(x, y, z); }
   double noise1(double x, double y, double z) const { return noise(y+51.416, z-27.853, x+32.793); }
   double noise2(double x, double y, double z) const { return noise(z-203.994, x+169.47, y-205.31); }
   
   Vec3d potential(double x, double y, double z) const;

   //Array3d m_temperature;
   FlowNoise3 noise;
   
};


class GridSmokeSim : public GridFluidSim
{
public:
   
   GridSmokeSim( const Vec3d& grid_origin, const Vec3d& grid_high_bound, double grid_dx, double in_gravity = -5.0 );
   
   void initialize( const DynamicSurface& surf );
   
   void compute_signed_distance( const DynamicSurface& surf );
   void apply_forces( const DynamicSurface& surf, double dt );
   
   void extend_velocity( const DynamicSurface& surf, 
                         Array3d& vel, 
                         unsigned int offset_i, 
                         unsigned int offset_j, 
                         unsigned int offset_k )
   {
      std::cout << "extend_velocity: doing nothing" << std::endl;
      
      // do nothing
      return;
   }
   
   void addCurlNoise( const DynamicSurface& surf, std::vector<Vec3d>& out_velocity );
   
   void set_surface_velocity( const DynamicSurface& surf, 
                              std::vector<Vec3d>& out_velocity, 
                              double current_t, 
                              double& adaptive_dt );
   
   Array3d m_temperature;
   
   SmokeCurlNoise m_curl_noise;
   
   
};

// ---------------------------------------------------------
//  Inline functions
// ---------------------------------------------------------


#endif
