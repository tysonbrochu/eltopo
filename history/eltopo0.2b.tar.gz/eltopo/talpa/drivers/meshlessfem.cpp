
// ---------------------------------------------------------
//
//  meshlessfem.cpp
//
//  Meshless FEM elasticity from Müller et al. 2004.
//
// ---------------------------------------------------------

// ---------------------------------------------------------
// Includes
// ---------------------------------------------------------

#include <meshlessfem.h>

#include <array2.h>
#include <fstream>
#include <gluvi.h>
#include <lapack_wrapper.h>
#include <makelevelset3.h>
#include <simulation.h>
#include <surftrack.h>

// ---------------------------------------------------------
// Global externs
// ---------------------------------------------------------

// ---------------------------------------------------------
// Local constants, typedefs, macros
// ---------------------------------------------------------

// ---------------------------------------------------------
// Static and nonmember function definitions
// ---------------------------------------------------------

// ---------------------------------------------------------
// Member function definitions
// ---------------------------------------------------------


// ---------------------------------------------------------
///
/// Default constructor
///
// ---------------------------------------------------------

MeshlessFEMDriver::MeshlessFEMDriver( double youngs_modulus, 
                                      double poisson_ratio, 
                                      double rayleigh_phi, 
                                      double rayleigh_psi, 
                                      double von_mises_gamma, 
                                      double max_plastic_strain ) :
   m_reference_space_grid(),
   m_reference_positions(0), 
   m_displacements(0), 
   m_displacement_velocities(0),
   m_masses(0), 
   m_densities(0), 
   m_supports(0), 
   m_volumes(0),
   m_plastic_strains(0), 
   m_grad_Us(0), 
   m_inv_As(0), 
   m_volume_ids(0),
   m_cfl_max_dt(-1.0), 
   m_original_particle_spacing(-1.0), 
   m_lame_lambda( ( youngs_modulus * poisson_ratio ) / ( (1+poisson_ratio)*(1-2*poisson_ratio) ) ),
   m_lame_mu( youngs_modulus / ( 2*(1-poisson_ratio) ) ),
   m_rayleigh_phi( rayleigh_phi ),
   m_rayleigh_psi( rayleigh_psi ),   
   m_von_mises_gamma( von_mises_gamma ),
   m_max_plastic_strain( max_plastic_strain ),
   cylinder_centre( Vec3d( 0.0, -0.5, 0.0 ) ),
   cylinder_radius(0.08)
{}


// ---------------------------------------------------------
///
/// Really, really bad k-nearest neighbour search
///
// ---------------------------------------------------------

double MeshlessFEMDriver::get_k_nearest_neighbours( unsigned int k, const Vec3d& pt, unsigned int volume_id, std::vector<unsigned int>& nearest_neighbours )
{
   double query_radius = 1.0;
   
   nearest_neighbours.clear();
   
   while ( nearest_neighbours.size() < k )
   {
      std::vector<unsigned int> query_results;
      get_nearby_reference_particles( pt, query_radius, volume_id, query_results );
      
      std::cout << "nearby_reference_particles: " << query_results.size() << std::endl;
      
      // remove points outside the query sphere
      
      for ( unsigned int i = 0; i < query_results.size(); ++i )
      {         
         if ( mag( m_reference_positions[query_results[i]] - pt ) > query_radius )
         {
            query_results.erase( query_results.begin() + i );
            --i;
         }
      }
      
      std::cout << "nearby_reference_particles after culling with sphere: " << query_results.size() << std::endl;

      while ( ( !query_results.empty() ) && ( nearest_neighbours.size() < k ) )
      {
       
         std::cout << "nearest_neighbours: " << nearest_neighbours.size() << std::endl;

         // better idea: sort and process in order
         
         double min_dist = 1e30;
         unsigned int closest_query_point = ~0;
         
         for ( unsigned int i = 0; i < query_results.size(); ++i )
         {
            double dist = mag( pt - m_reference_positions[query_results[i]] );
            
            if ( dist < min_dist )
            {
               min_dist = dist;
               closest_query_point = i;
            }
         }

         nearest_neighbours.push_back( query_results[closest_query_point] );
         
         query_results.erase( query_results.begin() + closest_query_point );
         
      }
      
      query_radius *= 2.0;
      
   }
   
   double avg = 0.0;
   for ( unsigned int i = 0; i < nearest_neighbours.size(); ++i )
   {
      avg += mag( pt - m_reference_positions[nearest_neighbours[i]] );
   }
   avg /= (double) nearest_neighbours.size();
   
   return avg;
   
}


// ---------------------------------------------------------
///
/// Seed the interior of the surface with particles and initialize masses, etc.
///
// ---------------------------------------------------------

void MeshlessFEMDriver::initialize( const DynamicSurface& surf )
{
   
   double surface_vertex_spacing = surf.get_average_edge_length();

   double particle_spacing = 4.0 * surface_vertex_spacing;

   // Divide up by volume
   
   unsigned int num_volumes = 0;
   for( unsigned int i = 0; i < surf.m_volume_ids.size(); ++i )
   {
      num_volumes = max( num_volumes, surf.m_volume_ids[i] );
   }
   ++num_volumes;

   unsigned int np = 0;
   
   for ( unsigned int v = 0; v < num_volumes; ++v )
   {
      std::cout << "surftrack volume " << v << "/" << num_volumes << std::endl;
      
      std::vector<Vec3d> volume_vertices;
      
      for( unsigned int i = 0; i < surf.m_volume_ids.size(); ++i )
      {
         if ( surf.m_volume_ids[i] == v )
         {
            volume_vertices.push_back( surf.m_positions[i] );
         }
      }

      std::cout << "volume_vertices: " << volume_vertices.size() << std::endl;
      
      std::vector<Vec3ui> volume_triangles;
      
      for( unsigned int i = 0; i < surf.m_mesh.tris.size(); ++i )
      {
         const Vec3ui& t = surf.m_mesh.tris[i];

         assert( surf.m_volume_ids[t[0]] == surf.m_volume_ids[t[1]] );
         assert( surf.m_volume_ids[t[1]] == surf.m_volume_ids[t[2]] );
         assert( surf.m_volume_ids[t[2]] == surf.m_volume_ids[t[0]] );
         
         if ( surf.m_volume_ids[t[0]] == v )
         {
            volume_triangles.push_back( t );
         }
      }
      

      std::cout << "volume_triangles: " << volume_triangles.size() << std::endl;
      
      //
      // Create initial seeding of particles around the surface
      //
         
      Vec3d low(1e30, 1e30, 1e30), high(-1e30, -1e30, -1e30);
      for ( unsigned int i = 0; i < volume_vertices.size(); ++i )
      {
         update_minmax( volume_vertices[i], low, high );
      }
   
      low -= particle_spacing * Vec3d(1.1, 1.1, 1.1);
      high += particle_spacing * Vec3d(1.1, 1.1, 1.1);
      
      unsigned int ni = (unsigned int) ceil( (high[0] - low[0]) / particle_spacing );
      unsigned int nj = (unsigned int) ceil( (high[1] - low[1]) / particle_spacing );
      unsigned int nk = (unsigned int) ceil( (high[2] - low[2]) / particle_spacing );
         
      Array3d phi;
      make_level_set3( volume_triangles, surf.m_positions, low, particle_spacing,
                       ni, nj, nk, phi ); 
      
      for ( unsigned int i = 0; i < ni; ++i )
      {
         for ( unsigned int j = 0; j < nj; ++j )
         {
            for ( unsigned int k = 0; k < nk; ++k )
            {
               if ( phi(i,j,k) < 0.9 * particle_spacing )
               {
                  m_reference_positions.push_back( low + particle_spacing * Vec3d( i, j, k ) );
                  m_volume_ids.push_back( v );
               }
            }
         }
      }

      
   }
     
   np = m_reference_positions.size();
   
   std::cout << "number of FEM particles: " << np << std::endl;
   
   m_displacements.resize( np, Vec3d(0,0,0) );  
   m_displacement_velocities.resize( np, Vec3d( 0.0, -10.0, 0.0 ) );  
   
   m_masses.resize( np, UNINITIALIZED_DOUBLE );
   m_densities.resize( np, UNINITIALIZED_DOUBLE );
   m_supports.resize( np, UNINITIALIZED_DOUBLE );
   m_volumes.resize( np, UNINITIALIZED_DOUBLE );
   
   m_plastic_strains.resize( np, Mat33d( 0,0,0, 0,0,0, 0,0,0 ) );
   
   std::cout << "building acceleration grid" << std::endl;
   build_acceleration_grids( particle_spacing );

   //
   // Set masses and m_supports
   //
   
   std::cout << "setting masses" << std::endl;
   
   // TODO: Set these.
   double s = 1.0, rho = 1.0;
   
   for ( unsigned int i = 0; i < m_reference_positions.size(); ++i )
   {
      std::cout << "particle " << i << std::endl;
      
      std::vector<unsigned int> nearest_neighbours;
      double average_distance = get_k_nearest_neighbours( 6, m_reference_positions[i], m_volume_ids[i], nearest_neighbours );
      
      //double average_distance = particle_spacing;
      
      m_supports[i] = 3.0 * average_distance;
      
      m_masses[i] = s * average_distance * average_distance * average_distance * rho;
    
      zero( m_plastic_strains[i] );
      
   }

   //
   // Set densities
   //

   std::cout << "setting densities" << std::endl;
   
   for ( unsigned int i = 0; i < m_reference_positions.size(); ++i )
   {
      std::vector<unsigned int> neighbours;
      get_neighbouring_reference_particles( i, neighbours );
      
      m_densities[i] = 0.0;

      for ( unsigned int n = 0; n < neighbours.size(); ++n )
      {
         unsigned int j = neighbours[n];
         double wij = spline_weight( mag( m_reference_positions[j] - m_reference_positions[i] ), m_supports[i] );
         
         m_densities[i] += m_masses[j] * wij;
      }
      
      m_volumes[i] = m_masses[i] / m_densities[i];
   }

   //
   // Set CFL time step limit
   //
   
   double min_particle_spacing = 1e30;
   
   for ( unsigned int i = 0; i < m_reference_positions.size(); ++i )
   {
      std::vector<unsigned int> neighbours;
      get_neighbouring_reference_particles( i, neighbours );
      
      for ( unsigned n = 0; n < neighbours.size(); ++n )
      {
         min_particle_spacing = min( min_particle_spacing, mag( m_reference_positions[i] - m_reference_positions[neighbours[n]] ) );
      }
   }
   
   m_cfl_max_dt = min_particle_spacing / sqrt( 2*m_lame_mu + m_lame_lambda );
   
   m_original_particle_spacing = min_particle_spacing;
   
   std::cout << "done initializing" << std::endl;
}


// ---------------------------------------------------------
///
/// Construct grid to speed up neighbour queries
///
// ---------------------------------------------------------

void MeshlessFEMDriver::build_acceleration_grids( double grid_padding )
{

   //
   // Reference space grid
   //

   {
      Vec3d xmax = m_reference_positions[0];
      Vec3d xmin = m_reference_positions[0];
      double maxdistance = 0;
      
      unsigned int n = m_reference_positions.size();
      
      for(unsigned int i = 0; i < n; i++)
      {
         update_minmax(m_reference_positions[i] - m_supports[i] * Vec3d(1,1,1), xmin, xmax);
         update_minmax(m_reference_positions[i] + m_supports[i] * Vec3d(1,1,1), xmin, xmax);
         maxdistance = std::max(maxdistance, mag(m_reference_positions[i] - m_reference_positions[i]));
      }
      
      for(unsigned int i = 0; i < 3; i++)
      {
         xmin[i] -= 2*maxdistance + grid_padding;
         xmax[i] += 2*maxdistance + grid_padding;
      }
      
      Vec3ui dims(1,1,1);
      
      if(mag(xmax-xmin) > grid_padding)
      {
         double elements_per_cell = 4.0;
         double volume = (xmax[0]-xmin[0])*(xmax[1]-xmin[1])*(xmax[2]-xmin[2]);
         double volume_per_cell = volume * elements_per_cell / n;
         double ideal_cell_size = pow(volume_per_cell, 1.0/3.0);      
         
         for(unsigned int i = 0; i < 3; i++)
         {
            unsigned int d = (unsigned int)ceil((xmax[i] - xmin[i])/ideal_cell_size);
            
            if(d < 1) d = 1;
            if(d > n) d = n;
            dims[i] = d;
         }
      }
      
      m_reference_space_grid.set(dims, xmin, xmax);
      
      for(unsigned int i = n; i > 0; i--)
      {
         unsigned int index = i - 1;
         m_reference_space_grid.add_element( index, 
                                    m_reference_positions[index] - (m_supports[index] + grid_padding) * Vec3d(1,1,1), 
                                    m_reference_positions[index] + (m_supports[index] + grid_padding) * Vec3d(1,1,1) );
      }
    
   }
      
}


// ---------------------------------------------------------
///
/// Get the set of particles whose radii overlap the specified particle's radius
///
// ---------------------------------------------------------

void MeshlessFEMDriver::get_neighbouring_reference_particles( unsigned int particle_index, std::vector<unsigned int>& neighbours )
{
   m_reference_space_grid.find_overlapping_elements( m_reference_space_grid.elementxmins[particle_index],
                                                     m_reference_space_grid.elementxmaxs[particle_index],
                                                     neighbours );
   
   for ( std::vector<unsigned int>::iterator iter = neighbours.begin(); iter != neighbours.end(); ++iter )
   {
      if ( ( *iter == particle_index ) || ( m_volume_ids[*iter] != m_volume_ids[particle_index] ) )
      {
         neighbours.erase( iter );
         --iter;
      }
   }
         
}

void MeshlessFEMDriver::get_nearby_reference_particles( const Vec3d& x, double h, unsigned int volume_id, std::vector<unsigned int>& neighbours )
{
   m_reference_space_grid.find_overlapping_elements( x - Vec3d( h, h, h ),
                                                     x + Vec3d( h, h, h ), 
                                                     neighbours );
   
   for ( std::vector<unsigned int>::iterator iter = neighbours.begin(); iter != neighbours.end(); ++iter )
   {
      if ( m_volume_ids[*iter] != volume_id )
      {
         neighbours.erase( iter );
         --iter;
      }
   }
   
}


// ---------------------------------------------------------
///
/// Compute the gradient of deformation at the specified particle
///
// ---------------------------------------------------------

Mat33d MeshlessFEMDriver::compute_deformation_gradient( unsigned int i, const std::vector<unsigned int>& neighbours, const std::vector<double>& wi, const Mat33d& inv_A )
{
   
   Vec3d grad_u(0,0,0);
   Vec3d grad_v(0,0,0);
   Vec3d grad_w(0,0,0);
      
   for ( unsigned int n = 0; n < neighbours.size(); ++n )
   {
      unsigned int j = neighbours[n];
      grad_u += (m_displacements[j][0] - m_displacements[i][0]) * (m_reference_positions[j] - m_reference_positions[i]) * wi[n];
      grad_v += (m_displacements[j][1] - m_displacements[i][1]) * (m_reference_positions[j] - m_reference_positions[i]) * wi[n];
      grad_w += (m_displacements[j][2] - m_displacements[i][2]) * (m_reference_positions[j] - m_reference_positions[i]) * wi[n];
   }
   
   grad_u = inv_A * grad_u;
   grad_v = inv_A * grad_v;
   grad_w = inv_A * grad_w;
   
   Mat33d grad_U;
   grad_U(0,0) = grad_u[0];     grad_U(0,1) = grad_u[1];        grad_U(0,2) = grad_u[2];
   grad_U(1,0) = grad_v[0];     grad_U(1,1) = grad_v[1];        grad_U(1,2) = grad_v[2];
   grad_U(2,0) = grad_w[0];     grad_U(2,1) = grad_w[1];        grad_U(2,2) = grad_w[2];
   
   return grad_U;
   
}

Mat33d MeshlessFEMDriver::compute_deformation_rate_gradient( unsigned int i, const std::vector<unsigned int>& neighbours, const std::vector<double>& wi, const Mat33d& inv_A )
{
   
   Vec3d grad_u(0,0,0);
   Vec3d grad_v(0,0,0);
   Vec3d grad_w(0,0,0);
   
   for ( unsigned int n = 0; n < neighbours.size(); ++n )
   {
      unsigned int j = neighbours[n];
      grad_u += (m_displacement_velocities[j][0] - m_displacement_velocities[i][0]) * (m_reference_positions[j] - m_reference_positions[i]) * wi[n];
      grad_v += (m_displacement_velocities[j][1] - m_displacement_velocities[i][1]) * (m_reference_positions[j] - m_reference_positions[i]) * wi[n];
      grad_w += (m_displacement_velocities[j][2] - m_displacement_velocities[i][2]) * (m_reference_positions[j] - m_reference_positions[i]) * wi[n];
   }
   
   grad_u = inv_A * grad_u;
   grad_v = inv_A * grad_v;
   grad_w = inv_A * grad_w;
   
   Mat33d grad_U_dot;
   grad_U_dot(0,0) = grad_u[0];     grad_U_dot(0,1) = grad_u[1];        grad_U_dot(0,2) = grad_u[2];
   grad_U_dot(1,0) = grad_v[0];     grad_U_dot(1,1) = grad_v[1];        grad_U_dot(1,2) = grad_v[2];
   grad_U_dot(2,0) = grad_w[0];     grad_U_dot(2,1) = grad_w[1];        grad_U_dot(2,2) = grad_w[2];
   
   return grad_U_dot;
   
}


                    
void MeshlessFEMDriver::linear_interpolate_displacement( const Vec3d& reference_x, unsigned int volume_id, double h, Vec3d& u )
{
   
   // Define U(X) = C(x)^T ( U_p )
      
   std::vector<unsigned int> nearby_particles;
   get_nearby_reference_particles( reference_x, h, volume_id, nearby_particles );
      
   unsigned int n = nearby_particles.size();
   
   Array2d A(n,4);
      
   Mat44d M;
   zero(M);
   
   Vec4d p( 1, reference_x[0], reference_x[1], reference_x[2] );

   for ( unsigned int np = 0; np < n; ++np )
   {
      unsigned int j = nearby_particles[np];
      
      Vec4d row( 1.0, m_reference_positions[j][0], m_reference_positions[j][1], m_reference_positions[j][2] );
      
      A(np,0) = row[0];
      A(np,1) = row[1];
      A(np,2) = row[2];
      A(np,3) = row[3];
            
      double w = gaussian_weight( mag( reference_x - m_reference_positions[j] ), h );
      M += outer( row, row ) * w;
   }
   
   int lwork = 4*4;
   double *work = new double[lwork];
   int *ipiv = new int[4];
   int info = 1;

   {
      Mat44d tester = M;
      
      //inline void get_eigen_decomposition( int *n, double *a, int* /*lda*/, double *eigenvalues, double *work, int *lwork, int *info )
      int en = 4;
      double eigenvalues[4];
      int elwork = 4*4;
      double ework[4*4];
      LAPACK::get_eigen_decomposition( &en, tester.a, &en, eigenvalues, ework, &elwork, &info );
      
      assert( info == 0 );
      assert( eigenvalues[0] != 0.0 );
      assert( eigenvalues[1] != 0.0 );
      assert( eigenvalues[2] != 0.0 );
      assert( eigenvalues[3] != 0.0 );      
   }   
   
   LAPACK::invert_general_matrix( 4, M.a, 4, ipiv, work, lwork, info );
   
   assert( info == 0 );

   delete[] ipiv;
   delete[] work;

   
   Vec4d mp = M.transpose() * p;
   
   // C = A*mp

   Array2d C(n,1);
   
   for ( unsigned int i = 0; i < n; ++i )
   {
      double w = gaussian_weight( mag( reference_x - m_reference_positions[nearby_particles[i]] ), h );
      C(i,0) = w * ( A(i,0) * mp[0] + A(i,1) * mp[1] + A(i,2) * mp[2] + A(i,3) * mp[3] );
   }
   
   zero(u);
   
   // u = C^T * u
   for ( unsigned int i = 0; i < n; ++i )
   {
      u += C(i,0) * m_displacements[ nearby_particles[i] ];
   }
      
}


/*
void MeshlessFEMDriver::interpolate_displacement_to_simulation( const Vec3d& reference_x, unsigned int volume_id, double h, const Vec3d& u_after_collision, const Vec3d& u_predicted, double dt )
{
   
   std::vector<unsigned int> nearby_particles;
   get_nearby_reference_particles( reference_x, h, volume_id, nearby_particles );
   
   unsigned int n = nearby_particles.size();
   
   Vec4d p( 1, reference_x[0], reference_x[1], reference_x[2] );
   
   Array2d A(n,4);
   Mat44d M;
   zero(M);
   
   for ( unsigned int np = 0; np < n; ++np )
   {
      unsigned int j = nearby_particles[np];
      
      Vec4d row( 1, m_reference_positions[j][0], m_reference_positions[j][1], m_reference_positions[j][2] );
      
      A(np,0) = 1.0;
      A(np,1) = m_reference_positions[j][0];
      A(np,2) = m_reference_positions[j][1];
      A(np,3) = m_reference_positions[j][2];
      
      double w = 
      M += outer( row, row ) * w;
   }
   
   // inline void invert_general_matrix(int n, float *a, int lda, int *ipiv, int &info)
   int lwork = 4*4;
   double *work = new double[lwork];
   int *ipiv = new int[4];
   int info;
   LAPACK::invert_general_matrix( 4, M.a, 4, ipiv, work, lwork, info);
   delete[] ipiv;
   delete[] work;
   
   assert( info == 0 );
   
   Vec4d mp = M * p;
   
   // C = A*mp
   
   double CTC = 0.0;
   Array1d C(n);
   C.resize(n);
   
   for ( unsigned int i = 0; i < n; ++i )
   {
      C(i) = (A(i,0) * mp[0] + A(i,1) * mp[1] + A(i,2) * mp[2] + A(i,3) * mp[3]);
      CTC += C(i) * C(i);
   }

   // now set lambda = (1/CT*C) * ( u_after_collision - u_predicted )

   Vec3d lambda = 1.0/CTC * ( u_after_collision - u_predicted );

   
   // now apply lambda to simulation displacement   

   for ( unsigned int np = 0; np < n; ++np )
   {
      unsigned int j = nearby_particles[np];
      
      m_displacements[j] += C(np) * lambda;
      
      m_displacement_velocities[j] += C(np) * lambda / dt;
   }
   
}
*/


void MeshlessFEMDriver::linear_fit_particle_displacements_to_surface( unsigned int volume_id, 
                                                 const std::vector<Vec3d>& surface_reference_positions,
                                                 const std::vector<Vec3d>& collision_adjusted_displacements,
                                                 const std::vector<Vec3d>& predicted_displacements,
                                                 double h,
                                                 double dt )
{
   
   if ( collision_adjusted_displacements.size() == 0 ) { return; }
   

   
   unsigned int n = m_reference_positions.size();
   unsigned int m = surface_reference_positions.size();
   
   std::cout << "m: " << m << std::endl;
   
   Array2d CT(m, n, 0.0);
   
   //std::cout << "dx\tdy\tdz\tC" << std::endl;
   
   for ( unsigned int i = 0; i < m; ++i )
   {
      std::vector<unsigned int> nearby_particles;
      get_nearby_reference_particles( surface_reference_positions[i], h, volume_id, nearby_particles );
      
      Vec4d p( 1, surface_reference_positions[i][0], surface_reference_positions[i][1], surface_reference_positions[i][2] );
      
      Array2d A( nearby_particles.size(), 4 );
      
      Mat44d M;
      zero(M);
      
      for ( unsigned int np = 0; np < nearby_particles.size(); ++np )
      {
         unsigned int j = nearby_particles[np];
         
         A(np,0) = 1.0;
         A(np,1) = m_reference_positions[j][0];
         A(np,2) = m_reference_positions[j][1];
         A(np,3) = m_reference_positions[j][2];
         
         Vec4d row( 1.0, m_reference_positions[j][0], m_reference_positions[j][1], m_reference_positions[j][2] );
                  
         double w = gaussian_weight( mag( surface_reference_positions[i] - m_reference_positions[j] ), h );
         
         M += outer( row, row ) * w;
      }
      
      int lwork = 4*4;
      double *work = new double[lwork];
      int *ipiv = new int[4];
      int info;
      
      {
         Mat44d tester = M;
         LAPACK::factor_general_matrix( 4, 4, tester.a, 4, ipiv, info);
         assert( info == 0 );
      }   
                  
      LAPACK::invert_general_matrix( 4, M.a, 4, ipiv, work, lwork, info);
      
      assert( info == 0 );
      
      // CT(i,:)   = p^T * inv(M) * A^T * W
      // CT(i,:)^T = (p' * inv(M) * A' * W)'
      //           = (A' * W)' * (p' * inv(M))'
      //           = W * A * inv(M) * p
      
      // mp = inv(M) * p
      
      Vec4d mp = M * p;
      
      // fill in row i of CT
      // CT(i,:) = (W*A*mp)^T
      
      for ( unsigned int np = 0; np < nearby_particles.size(); ++np )
      {
         unsigned int j = nearby_particles[np];
         double w = gaussian_weight( mag( surface_reference_positions[i] - m_reference_positions[j] ), h );
         
         CT(i,j) = w * ( A(np,0) * mp[0] + A(np,1) * mp[1] + A(np,2) * mp[2] + A(np,3) * mp[3] );
      
         //Vec3d dx = m_reference_positions[j] - surface_reference_positions[i];         
         //std::cout << dx[0] << "\t" << dx[1] << "\t" << dx[2] << "\t" << CT(i,j) << std::endl;
      }
      
   }
   
   //
   // Minimize:
   // min_d || CT*d - (u_corrected - u_predicted) ||
   //
   
   Array2d b( max(m,n), 3);
   for ( unsigned int i = 0; i < m; ++i )
   {      
      b(i,0) = (collision_adjusted_displacements[i][0] - predicted_displacements[i][0]);
      b(i,1) = (collision_adjusted_displacements[i][1] - predicted_displacements[i][1]);
      b(i,2) = (collision_adjusted_displacements[i][2] - predicted_displacements[i][2]);
   }
   
   
   int lapack_m = m;
   int lapack_n = n;
   int lapack_nrhs = 3;
   int lapack_lda = m;   
   int lapack_ldb = max( lapack_m, lapack_n );
   double* s = new double[ min(lapack_m, lapack_n) ];
   double rcond = 1e-10;
   int rank;   
   double optimal_work_size;
   int lwork = -1;
   int nlvl = 26;
   int liwork = 2*min(lapack_m,lapack_n)*nlvl + 11*min(lapack_m,lapack_n);
   int *iwork = new int[liwork];
   int info;
   
   // query
   unsigned int lapack_status = LAPACK::least_squares_svd( &lapack_m, 
                                                          &lapack_n, 
                                                          &lapack_nrhs, 
                                                          CT.a.data, 
                                                          &lapack_lda, 
                                                          b.a.data, 
                                                          &lapack_ldb, 
                                                          s, 
                                                          &rcond, 
                                                          &rank, 
                                                          &optimal_work_size, 
                                                          &lwork, 
                                                          iwork, 
                                                          &info );
   

   if ( info != 0 ) 
   {
      std::cout << "lapack info: " << info << std::endl;;
   }
   
   assert( info == 0 );
   
   lwork = (int)ceil(optimal_work_size);
   
   std::cout << "optimal_work_size: " << optimal_work_size << " = " << lwork << std::endl;
   
   double *work = new double[lwork];
   
   std::cout << "solving..." << std::endl;
   
   lapack_status = LAPACK::least_squares_svd( &lapack_m, 
                                             &lapack_n, 
                                             &lapack_nrhs, 
                                             CT.a.data, 
                                             &lapack_lda, 
                                             b.a.data, 
                                             &lapack_ldb, 
                                             s, 
                                             &rcond, 
                                             &rank, 
                                             work, 
                                             &lwork, 
                                             iwork, 
                                             &info );
   
   assert( info == 0 );
   
   std::cout << "Solved.  Effective rank was: " << rank << std::endl; 
   
   delete[] work;
   delete[] iwork;
   delete[] s;
   

   
   // now apply to simulation displacements: U_sim += d
   
   for ( unsigned int i = 0; i < n; ++i )
   {
      m_displacements[i][0] += b(i,0);
      m_displacements[i][1] += b(i,1);
      m_displacements[i][2] += b(i,2);         
      
      m_displacement_velocities[i][0] += b(i,0) / dt;
      m_displacement_velocities[i][1] += b(i,1) / dt;
      m_displacement_velocities[i][2] += b(i,2) / dt;      
   }   
   
}


double frobenius_norm( const Mat33d& m )
{
   double sum_sqr = 0;
   for ( unsigned int i = 0; i < 3; ++i )
   {
      for ( unsigned int j = 0; j < 3; ++j )
      {
         sum_sqr += m(i,j) * m(i,j);
      }
   }
   
   return sqrt(sum_sqr);
}


// ---------------------------------------------------------
///
/// Compute elastic forces on all particles
///
// ---------------------------------------------------------

void MeshlessFEMDriver::compute_elastic_plastic_forces( double dt, std::vector<Vec3d>& forces )
{   
   static const Mat33d eye( 1,0,0, 0,1,0, 0,0,1 );
     
   double max_strain_deviation = 0.0;
   double max_elastic_stress = 0.0;
   double max_damping_stress = 0.0;
   
   for ( unsigned int i = 0; i < m_reference_positions.size(); ++i )
   {
    
      std::vector<unsigned int> neighbours;
      get_neighbouring_reference_particles( i, neighbours );
                 
      //
      // Moment matrix A
      //

      std::vector<double> wi;
      wi.resize( neighbours.size() );
      Mat33d A;
      zero(A);
      for ( unsigned int n = 0; n < neighbours.size(); ++n )
      {
         unsigned int j = neighbours[n];
         wi[n] = spline_weight( mag( m_reference_positions[j] - m_reference_positions[i] ), m_supports[i] );
         A += outer( m_reference_positions[j] - m_reference_positions[i], m_reference_positions[j] - m_reference_positions[i] ) * wi[n];
      }
      
      m_inv_As[i] = inverse(A);
      
      //
      // Deformation gradient grad_U
      //
      
      m_grad_Us[i] = compute_deformation_gradient( i, neighbours, wi, m_inv_As[i] );
            
      // Jacobian
      
      Mat33d J = m_grad_Us[i] + eye;
      
      // Strain
      
      Mat33d measured_strain = ( J.transpose() * J - eye );
      
      Mat33d elastic_strain = measured_strain - m_plastic_strains[i];
      
      Mat33d dev = elastic_strain - trace( elastic_strain ) / 3 * eye;
      double strain_deviation = frobenius_norm(dev);
      
      max_strain_deviation = max( max_strain_deviation, strain_deviation );
      
      if ( strain_deviation > m_von_mises_gamma )
      {
         Mat33d delta_plastic_strain = (strain_deviation - m_von_mises_gamma) / strain_deviation * dev;                  
         m_plastic_strains[i] = m_plastic_strains[i] + min( 1.0, dt *  m_max_plastic_strain / frobenius_norm( delta_plastic_strain ) ) *  delta_plastic_strain;
      }
                   
      // Stress

      Mat33d elastic_stress = m_lame_lambda * trace( elastic_strain ) * eye + 2 * m_lame_mu * elastic_strain;
      
      Mat33d grad_u_dot = compute_deformation_rate_gradient( i, neighbours, wi, m_inv_As[i] ); 
      Mat33d strain_rate = grad_u_dot + grad_u_dot.transpose() + m_grad_Us[i] * grad_u_dot + m_grad_Us[i].transpose() * grad_u_dot.transpose();
      Mat33d damping_stress = m_rayleigh_phi * trace( strain_rate ) * eye + 2 * m_rayleigh_psi * strain_rate;
      
      max_elastic_stress = max( max_elastic_stress, frobenius_norm(elastic_stress) );
      max_damping_stress = max( max_damping_stress, frobenius_norm(damping_stress) );
      
      // Elastic + damping force tensor: F_e = -2 * volume_i * J_i * stress_i
      
      Mat33d Fe = -2.0 * m_volumes[i] * J * (elastic_stress + damping_stress);
      
      // Gradient of determinant of Jacobian, grad_det_J
      
      Mat33d grad_det_J;
      
      Vec3d cross_vw = cross( Vec3d( J(1,0), J(1,1), J(1,2) ), Vec3d( J(2,0), J(2,1), J(2,2) ) );
      grad_det_J(0,0) = cross_vw[0];
      grad_det_J(0,1) = cross_vw[1];
      grad_det_J(0,2) = cross_vw[2];

      Vec3d cross_wu = cross( Vec3d( J(2,0), J(2,1), J(2,2) ), Vec3d( J(0,0), J(0,1), J(0,2) ) );
      grad_det_J(1,0) = cross_wu[0];
      grad_det_J(1,1) = cross_wu[1];
      grad_det_J(1,2) = cross_wu[2];

      Vec3d cross_uv = cross( Vec3d( J(0,0), J(0,1), J(0,2) ), Vec3d( J(1,0), J(1,1), J(1,2) ) );
      grad_det_J(2,0) = cross_uv[0];
      grad_det_J(2,1) = cross_uv[1];
      grad_det_J(2,2) = cross_uv[2];
      
      // Volume preserving force matrix, F_v = -volume_i * volume_stiffness_i * ( det(J) - 1 ) * grad_det(J)
      
      //Mat33d Fv( 0,0,0, 0,0,0, 0,0,0 );
      Mat33d Fv = -m_volumes[i] * 0.75 * ( determinant(J) - 1 ) * grad_det_J;
      
      // f_i = (F_e + F_v) * inv(A) * -sum(x_ij * w_ij)
      
      Vec3d sum(0,0,0);
      for ( unsigned int n = 0; n < neighbours.size(); ++n )
      {
         unsigned int j = neighbours[n];
         sum += (m_reference_positions[j] - m_reference_positions[i]) * wi[n];
         
         forces[j] += (Fe + Fv) * m_inv_As[i] * (m_reference_positions[j] - m_reference_positions[i]) * wi[n];
      }
      
      forces[i] += (Fe + Fv) * m_inv_As[i] * -sum;
            
   }
   
   std::cout << "max_strain_deviation: " << max_strain_deviation << std::endl;
   std::cout << "max_elastic_stress: " << max_elastic_stress << std::endl;
   std::cout << "max_damping_stress: " << max_damping_stress << std::endl;
   
}


void MeshlessFEMDriver::compute_surface_tenstion_forces( const DynamicSurface& surf, std::vector<Vec3d>& forces )
{
   double SURFACE_TENSION_COEFFICIENT = 100.0;
   
   //
   // Compute per-triangle surface tension forces
   //
   
   std::vector<Vec3d> triangle_surface_tensions( surf.m_mesh.tris.size() );
   
   for ( unsigned int i = 0; i < triangle_surface_tensions.size(); ++i )
   {
      triangle_surface_tensions[i] = Vec3d(0,0,0);
      
      const Vec3ui& incident_edges = surf.m_mesh.triedge[i];

      for ( unsigned int e = 0; e < 3; ++e )
      {
         unsigned int edge_index = incident_edges[e]; 
         const std::vector<unsigned int> adjacent_triangles = surf.m_mesh.edgetri[edge_index];
      
         Vec3d edge_vector = surf.m_positions[surf.m_mesh.edges[edge_index][1]] - surf.m_positions[surf.m_mesh.edges[edge_index][0]];
         
         for ( unsigned int j = 0; j < adjacent_triangles.size(); ++j )
         {
            Vec3d normal = surf.get_triangle_area( adjacent_triangles[j] ) * surf.get_triangle_normal( adjacent_triangles[j] );
            
            triangle_surface_tensions[i] += SURFACE_TENSION_COEFFICIENT * cross( edge_vector, normal );
         }         
      }
   }
   
   //
   // Average forces from triangles to vertices
   //
   
   std::vector<Vec3d> vertex_surface_tensions( surf.m_positions.size() );
   
   for( unsigned int i = 0; i < surf.m_positions.size(); ++i )
   {
      Vec3d force(0,0,0);
      
      const std::vector<unsigned int>& incident_triangles = surf.m_mesh.vtxtri[i];
      
      for ( unsigned int j = 0; j < incident_triangles.size(); ++j )
      {
         force += triangle_surface_tensions[ incident_triangles[j] ];
      }
      
      vertex_surface_tensions[i] = 1.0 / 3.0 * force; 
   }
   
   //
   // Interpolate velocities from triangle vertices to particles
   //
   
   for( unsigned int i = 0; i < surf.m_positions.size(); ++i )   
   {
      std::vector<unsigned int> neighbours;
      get_nearby_reference_particles( surf.m_reference_positions[i], m_original_particle_spacing, 0, neighbours );
      
      double sum_w = 0.0;
      for ( unsigned int j = 0; j < neighbours.size(); ++j )
      {
         double w = gaussian_weight( mag( surf.m_reference_positions[i] - m_reference_positions[neighbours[j]] ), m_original_particle_spacing );
         sum_w += w;
      }

      for ( unsigned int j = 0; j < neighbours.size(); ++j )
      {
         double w = gaussian_weight( mag( surf.m_reference_positions[i] - m_reference_positions[neighbours[j]] ), m_original_particle_spacing );
         forces[neighbours[j]] += w / sum_w * vertex_surface_tensions[i];
      }
      
   }
   
   
}


void MeshlessFEMDriver::compute_accelerations( const DynamicSurface& surf, double dt, std::vector<Vec3d>& accelerations )
{
   static const double acc_gravity = -9.8e+2;

   accelerations.clear();
   
   accelerations.resize( m_reference_positions.size() );

   for ( unsigned int i = 0; i < m_reference_positions.size(); ++i )
   {
      accelerations[i] = Vec3d( 0, acc_gravity, 0 );
      
      /*
      if ( m_reference_positions[i][1] < 1.0 )
      {
        accelerations[i] = Vec3d( 0, acc_gravity, 0 ); 
      }
      else
      {
         accelerations[i] = Vec3d( 0, 0, 0 );
      }
      */
   }
 
   //
   // compute particle elastic forces
   //
   
   std::cout << "Meshless FEM: computing elastic forces" << std::endl;
   
   std::vector<Vec3d> forces( m_reference_positions.size(), Vec3d(0,0,0) );
   
   compute_elastic_plastic_forces( dt, forces );
   
   //compute_surface_tension_forces( surf, forces );
   
   // add to accumulated acceleration
   
   for ( unsigned int i = 0; i < m_reference_positions.size(); ++i )
   {
      //if ( m_reference_positions[i][1] < 1.0 )
      {
         accelerations[i] += forces[i] / m_masses[i];
      }
   }
   
}



double MeshlessFEMDriver::detect_pentration( const Vec3d& predicted_position, Vec3d& normal )
{
   // cylinder

   Vec3d predicted_position_xy( predicted_position[0], predicted_position[1], 0.0 );
   
   normal = predicted_position_xy - cylinder_centre;
   double dist = mag(normal);
   normal /= dist;

   return dist - cylinder_radius;
      
} 


// ---------------------------------------------------------
///
/// Assign to each surface vertex a velocity
///
// ---------------------------------------------------------

extern Simulation* g_sim;
extern std::vector<double> g_vertex_values;

void MeshlessFEMDriver::set_surface_velocity( const DynamicSurface& surf, 
                                              std::vector<Vec3d>& out_velocities, 
                                              double /* UNUSED current_t */, 
                                              double& adaptive_dt )
{
   
   m_inv_As.resize( m_reference_positions.size() );
   m_grad_Us.resize( m_reference_positions.size() );
   
   //
   // update acceleration grid
   //
   
   build_acceleration_grids(1e-2);
   
   std::cout << "Meshless FEM: building grids" << std::endl;
      
   
   //
   // compute acceleration due to elastic forces and gravity
   //
   
   std::vector<Vec3d> accelerations;   
   compute_accelerations( surf, adaptive_dt, accelerations );
   

   // Limit time step according to the CFL condition
   
   adaptive_dt = min( adaptive_dt, 0.5 * m_cfl_max_dt );
   
   // Further limit the time step so that particles don't get too close
   
   double max_acc_mag = -1.0;
   double max_vel_mag = -1.0;
      
   for ( unsigned int i = 0; i < m_reference_positions.size(); ++i )
   {
      max_acc_mag = max( max_acc_mag, mag( accelerations[i] ) );
      max_vel_mag = max( max_vel_mag, mag( m_displacement_velocities[i] ) );
   }
   
   std::cout << "max_acc_mag: " << max_acc_mag << std::endl;
   std::cout << "max_vel_mag: " << max_vel_mag << std::endl;   
   
   double stability_max_dt = sqrt( 0.1 * m_original_particle_spacing / max_acc_mag );

   while ( stability_max_dt * ( max_vel_mag + stability_max_dt * ( max_acc_mag ) ) > 0.1 * m_original_particle_spacing )
   {
      stability_max_dt *= 0.5;
      std::cout << "cutting stability_max_dt: " << stability_max_dt << std::endl;      
   }
   
   std::cout << "stability_max_dt: " << stability_max_dt << std::endl;
   
   adaptive_dt = min( adaptive_dt, stability_max_dt );

   std::cout << "adaptive_dt: " << adaptive_dt << std::endl;

   
   //
   // Advect the particles
   //
   
   for ( unsigned int p = 0; p < m_reference_positions.size(); ++p )
   {      
      m_displacement_velocities[p] += adaptive_dt * accelerations[p];
      m_displacements[p] = adaptive_dt * m_displacement_velocities[p];      
   }
   
   //
   // Interpolate particle displacements onto surface nodes
   //
   
   std::cout << "Meshless FEM: setting surface velocity" << std::endl;
   
   double avg_support = 0.0;
   for ( unsigned int p = 0; p < m_reference_positions.size(); ++p )
   {
      avg_support += m_supports[p];
   }
   avg_support /= (double) (m_reference_positions.size());

   
   unsigned int min_n = 10000000;
   for ( unsigned int i = 0; i < surf.m_positions.size(); ++i )
   {
      std::vector<unsigned int> nearby_particles;
      get_nearby_reference_particles( surf.m_reference_positions[i], avg_support, 0, nearby_particles );
      min_n = min( min_n, (unsigned int)nearby_particles.size() );
   }
   std::cout << "min_n: " << min_n << std::endl;
   
   std::vector<Vec3d> surface_displacements( surf.m_positions.size() );
   
   double avg_surface_displacement = 0.0;
   for ( unsigned int i = 0; i < surf.m_positions.size(); ++i )
   {
      linear_interpolate_displacement( surf.m_reference_positions[i], 0, avg_support, surface_displacements[i] );
      avg_surface_displacement += surface_displacements[i][1];
   }
   avg_surface_displacement /= (double) surf.m_positions.size();

   double max_deviation = 0.0;
   for ( unsigned int i = 0; i < surf.m_positions.size(); ++i )
   {
      max_deviation = max( max_deviation, fabs( surface_displacements[i][1] - avg_surface_displacement ) );
   }
   std::cout << "max_deviation: " << max_deviation << std::endl;
   
   //
   // Run mesh collision detection and fit simulation to corrected surface nodes
   //

   bool collision_found = true;
   bool any_collision_found = false;
   static const bool SIMULTANEOUS_COLLISIONS = false;
   
   g_vertex_values.resize( surf.m_positions.size(), 0.0 );
   
   while ( collision_found )
   {
      collision_found = false;
      
      double deepest_penetration = 1e30;
      int deepest_surface_node = -1;

      std::vector<Vec3d> surface_reference_positions;
      std::vector<Vec3d> predicited_displacements;
      std::vector<Vec3d> collision_adjusted_displacements;
      std::vector<unsigned int> colliding_vertices;
      
      unsigned int num_collisions = 0;
      
      for ( unsigned int i = 0; i < surf.m_positions.size(); ++i )
      {
         Vec3d predicted_position = surf.m_reference_positions[i] + surface_displacements[i];

         Vec3d collision_normal;
         double penetration = detect_pentration( predicted_position, collision_normal );
         
         //penetration = predicted_position[1] - ( -1.5 );

         if ( SIMULTANEOUS_COLLISIONS )
         {            
                        
            if ( penetration < 0.0 )
            {
               colliding_vertices.push_back( i );         
               surface_reference_positions.push_back( surf.m_reference_positions[i] );
               predicited_displacements.push_back( surface_displacements[i] );
               collision_adjusted_displacements.push_back( surface_displacements[i] );                              
               
               collision_adjusted_displacements.back() += Vec3d( 0, -penetration, 0 );
               collision_found = true;
               
               g_vertex_values[i] = 1.0;
               ++num_collisions;
            }            
         }

         if ( penetration < 0.0 && penetration < deepest_penetration)
         {
            deepest_penetration = penetration;
            deepest_surface_node = i;
            collision_found = true;
         }            
         
      }

      if ( collision_found )
      {
         any_collision_found = true;
                  
         std::cout << "num_collisions: " << num_collisions << std::endl;
         std::cout << "deepest_penetration: " << deepest_penetration << std::endl;
                 
         if ( !SIMULTANEOUS_COLLISIONS )
         {
            Vec3d predicted_position = surf.m_reference_positions[deepest_surface_node] + surface_displacements[deepest_surface_node];
            surface_reference_positions.push_back( surf.m_reference_positions[deepest_surface_node] );
            predicited_displacements.push_back( predicted_position - surf.m_reference_positions[deepest_surface_node] );
            collision_adjusted_displacements.push_back( predicted_position - surf.m_reference_positions[deepest_surface_node] );
            colliding_vertices.push_back( deepest_surface_node );         
            
            Vec3d collision_normal;
            double penetration = detect_pentration( predicted_position, collision_normal );

            collision_adjusted_displacements.back() += -penetration * collision_normal;
            
            //collision_adjusted_displacements.back() += Vec3d( 0, -deepest_penetration, 0 );
            
            g_vertex_values[deepest_surface_node] = 1.0;
         }
         
         linear_fit_particle_displacements_to_surface( surf.m_volume_ids[deepest_surface_node], 
                                                       surface_reference_positions, 
                                                       collision_adjusted_displacements, 
                                                       predicited_displacements, 
                                                       avg_support, 
                                                       adaptive_dt );
         
         // and now recompute all surface displacements
         for ( unsigned int s = 0; s < surf.m_positions.size(); ++s )
         {
            linear_interpolate_displacement( surf.m_reference_positions[s], 0, avg_support, surface_displacements[s] );
         }
         
      }

   }

   if ( any_collision_found )
   {
      for ( unsigned int s = 0; s < surf.m_positions.size(); ++s )
      {
         linear_interpolate_displacement( surf.m_reference_positions[s], 0, avg_support, surface_displacements[s] );
      }
   }
   
   // compute surface velocities
   for ( unsigned int s = 0; s < surf.m_positions.size(); ++s )
   {
      Vec3d new_displacement;
      linear_interpolate_displacement( surf.m_reference_positions[s], 0, avg_support, new_displacement );
      out_velocities[s] = ( surf.m_reference_positions[s] + new_displacement - surf.m_positions[s] ) / adaptive_dt;
   }
   
   static const Mat33d eye( 1,0,0, 0,1,0, 0,0,1 );
      
   //
   // Fold stored strain into plastic strains
   //
   
   for ( unsigned int i = 0; i < m_reference_positions.size(); ++i )
   {   
      std::vector<unsigned int> neighbours;
      get_neighbouring_reference_particles( i, neighbours );
      
      std::vector<double> wi;
      wi.resize( neighbours.size() );
      for ( unsigned int n = 0; n < neighbours.size(); ++n )
      {
         unsigned int j = neighbours[n];
         wi[n] = spline_weight( mag( m_reference_positions[j] - m_reference_positions[i] ), m_supports[i] );
      }
      
      m_grad_Us[i] = compute_deformation_gradient( i, neighbours, wi, m_inv_As[i] );
      
      Mat33d J = m_grad_Us[i] + eye;
      Mat33d measured_strain = ( J.transpose() * J - eye );

      m_plastic_strains[i] -= measured_strain;
   }
      
   //
   // Update reference positions
   //
   
   for ( unsigned int i = 0; i < m_reference_positions.size(); ++i )
   {   
      // x = x + u
      m_reference_positions[i] += m_displacements[i];
      
      // u = 0
      m_displacements[i] = Vec3d(0,0,0);

   }   
   
   for ( unsigned int i = 0; i < surf.m_reference_positions.size(); ++i )
   {
      Vec3d& reference_x = const_cast<Vec3d&> ( surf.m_reference_positions[i] );
      reference_x = surf.m_positions[i] + adaptive_dt * out_velocities[i];
   }
   
   
   //
   // Update densities and m_volumes
   //
   
   std::cout << "Meshless FEM: updating densities and m_volumes" << std::endl;
      
   for ( unsigned int i = 0; i < m_reference_positions.size(); ++i )
   {
      std::vector<unsigned int> neighbours;
      get_neighbouring_reference_particles( i, neighbours );
      
      m_densities[i] = 0.0;
      
      std::vector<double> wi( neighbours.size() );
      for ( unsigned int n = 0; n < neighbours.size(); ++n )
      {
         unsigned int j = neighbours[n];
         wi[n] = spline_weight( mag( m_reference_positions[j] - m_reference_positions[i] ), m_supports[i] );      
         m_densities[i] += m_masses[j] * wi[n];
      }
      
      m_volumes[i] = m_masses[i] / m_densities[i];
   }
   
   m_inv_As.clear();
   m_grad_Us.clear();   
   
   
}


void MeshlessFEMDriver::display( const DynamicSurface& surf )
{
   
   glDisable(GL_LIGHTING);

   glPointSize( 3.0f );
   glBegin(GL_POINTS);

   for ( unsigned int i = 0; i < m_reference_positions.size(); ++i )
   {
      glColor3f( 1.0f, 0.0f, 0.0f );
      Vec3d vtx = m_reference_positions[i];
      glVertex3dv(vtx.v);    
   }

   glEnd();  
   
   GLUquadricObj *quadratic = gluNewQuadric();
	gluQuadricNormals(quadratic, GLU_SMOOTH);
   
   glTranslated( cylinder_centre[0], cylinder_centre[1], cylinder_centre[2] - 3.0 );
   gluCylinder(quadratic, cylinder_radius, cylinder_radius, 6.0, 32, 32);
   
   glEnable(GL_LIGHTING);
   
}






