// ---------------------------------------------------------
//
//  sisccurlnoisedriver.cpp
//  Tyson Brochu 2008
//
//  Mesh driver for divergence-free, pseuo-random velocity
//
// ---------------------------------------------------------

// ---------------------------------------------------------
// Includes
// ---------------------------------------------------------

#include <sisccurlnoisedriver.h>
#include <surftrack.h>

// ---------------------------------------------------------
// Global externs
// ---------------------------------------------------------

// ---------------------------------------------------------
// Local constants, typedefs, macros
// ---------------------------------------------------------

// ---------------------------------------------------------
// Static function definitions
// ---------------------------------------------------------

// ---------------------------------------------------------
// Member function definitions
// ---------------------------------------------------------


// ---------------------------------------------------------
///
/// Constructor
///
// ---------------------------------------------------------

SISCCurlNoiseDriver::SISCCurlNoiseDriver()
   : CurlNoise3( ),
     noise_lengthscale(1),
     noise_gain(1),
     noise(),
     m_initial_volume(UNINITIALIZED_DOUBLE)
{
   noise_lengthscale[0]=1.5;
   noise_gain[0]=1.3;  
}


// ---------------------------------------------------------
///
/// Initializer.  Get the initial volume enclosed by the surface for comparison later on.
///
// ---------------------------------------------------------

void SISCCurlNoiseDriver::initialize( const DynamicSurface& surf )
{
   m_initial_volume = surf.get_volume();
}

// ---------------------------------------------------------
///
/// 3D vector field which defines the velocity via its curl.
///
// ---------------------------------------------------------

Vec3d SISCCurlNoiseDriver::potential(double x, double y, double z) const
{
   Vec3d psi(0,0,0);
   double height_factor=0.5;
   
   static const Vec3d centre( 0.0, 1.0, 0.0 );
   static double radius = 4.0;
   
   for(unsigned int i=0; i<noise_lengthscale.size(); ++i)
   {
      double sx=x/noise_lengthscale[i];
      double sy=y/noise_lengthscale[i];
      double sz=z/noise_lengthscale[i];
      
      Vec3d psi_i( 0.f, 0.f, noise2(sx,sy,sz));
      
      double dist = mag( Vec3d(x,y,z) - centre );      
      double scale = max( (radius - dist)/radius, 0.0 );
      psi_i *= scale;

      psi+=height_factor*noise_gain[i]*psi_i;
   }
      
   return psi;
}


// ---------------------------------------------------------
///
/// For each vertex on the mesh, take the curl of potential to get velocity vector at that vertex location.
/// Uses RK4 to get x(t+1) from x(t), then returns linear trajectory v = (x(t+1) - x(t)) / dt.
///
// ---------------------------------------------------------

void SISCCurlNoiseDriver::set_surface_velocity( const DynamicSurface& surf, std::vector<Vec3d>& velocities, double /*unused current_t*/, double& dt )
{
   const std::vector<Vec3d>& positions = surf.m_positions;
   Vec3d v, midx;
   
   // Update velocities
   for ( unsigned int i = 0; i < velocities.size(); ++i )
   {    
      if ( surf.m_mesh.m_vtxtri[i].empty() )
      {
         velocities[i] = Vec3d(0,0,0);
         continue;
      }
      
      const Vec3d& p = positions[i];
      
      // RK4
      // -----------
      // k1 = dt * f( t, x );
      get_velocity( p, v );
      Vec3d k1 = dt * v;
      
      // k2 = dt * f( t + 0.5*dt, x + 0.5*k1 );
      advance_time( 0.5*dt );
      get_velocity( p + 0.5 * k1, v );
      Vec3d k2 = dt * v;
      
      //k3 = dt * f( t + 0.5*dt, x + 0.5*k2 );
      get_velocity( p + 0.5 * k2, v );
      Vec3d k3 = dt * v;
      
      //k4 = dt * f( t + dt, x + k3 );
      advance_time( 0.5*dt );
      get_velocity( p + 0.5 * k3, v );
      Vec3d k4 = dt * v;
      
      Vec3d xnew = p + 1.0/6.0 * ( k1 + k4 ) + 1.0/3.0 * ( k2 + k3 );

      velocities[i] = (xnew - p) / dt;
            
      advance_time( -dt );
   }
   
   advance_time( dt );
}


// ---------------------------------------------------------
///
/// Compute and output difference between current volume and initial volume
///
// ---------------------------------------------------------

void SISCCurlNoiseDriver::compute_error( const DynamicSurface& surf, double current_t )
{
   std::cout << "volume: " << surf.get_volume() << std::endl;
   double delta_volume = surf.get_volume() - m_initial_volume;
   std::cout << "delta volume: " << delta_volume << std::endl;
   double percent_error = delta_volume / m_initial_volume * 100;
   std::cout << "percent error: " << percent_error << std::endl;   
}


