
#ifndef PERIODIC_H
#define PERIODIC_H

#include <meshdriver.h>

class DynamicSurface;
class NonDestructiveTriMesh;

class PeriodicDriver : public MeshDriver
{
   
public:

   std::vector<Vec2ui> constrained_vertex_pairs;
      
   PeriodicDriver( ) {}
        
   void initialize( const DynamicSurface& surf );

   void display( const DynamicSurface& surf );
         
   void set_surface_velocity( const DynamicSurface& surf, std::vector<Vec3d>& out_velocity, double current_t, double& adaptive_dt );      
   
   void compute_error( const DynamicSurface& surf, double current_t ) {}
};

#endif
