
// ---------------------------------------------------------
//
//  flowprimitives.h
//  Tyson Brochu 2009
//
//  A set of procedural flow primitives
//
// ---------------------------------------------------------

#ifndef FLOWPRIMITIVES_H
#define FLOWPRIMITIVES_H

#include <vec.h>
#include <noise.h>

#ifndef MAXFLOAT
#define MAXFLOAT std::numeric_limits<float>::max()
#endif

// ---------------------------------------------------------

inline double apply_clamped_dot( double old_value, double dt, const Vec3d& clamped_dot )
{
   return max( clamped_dot[1], min( clamped_dot[2], old_value + dt * clamped_dot[0] ) );
}


// ---------------------------------------------------------

struct FlowPrimitive
{
   virtual ~FlowPrimitive() {}
   virtual void update( double dt ) = 0;
   virtual void apply( const Vec3d& x, Vec3d& v ) = 0;
   virtual void render() {}
};

// ---------------------------------------------------------

struct LaminarFlow : public FlowPrimitive
{
   LaminarFlow( const Vec3d& direction, 
                double magnitude, 
                Vec3d magnitude_clamped_dot = Vec3d(0.0, -MAXFLOAT, MAXFLOAT) ) :
      m_direction( direction ),
      m_magnitude( magnitude ),
      m_magnitude_clamped_dot( magnitude_clamped_dot )
   {}

   virtual ~LaminarFlow() {}
   
   void update( double dt )
   {
      m_magnitude = apply_clamped_dot( m_magnitude, dt, m_magnitude_clamped_dot );
   }
   
   void apply( const Vec3d& x, Vec3d& v )
   {
      v += m_magnitude * m_direction;
   }
   
   Vec3d m_direction;
   double m_magnitude;
   Vec3d m_magnitude_clamped_dot;
   
};

// ---------------------------------------------------------

struct VortexParticle : public FlowPrimitive
{
   VortexParticle( const Vec3d& c, const Vec3d& v, const Vec3d& o, double r, double m ) :
      m_centre(c),
      m_velocity(v),
      m_clamped_acceleration(),
      m_orientation( o ),
      m_radius(r),
      m_radius_dot(0.0),
      m_magnitude(m),
      m_magnitude_clamped_dot( Vec3d(0.0, 0.0, MAXFLOAT) ),
      m_dx( 1e-4 )
   {}

   virtual ~VortexParticle() {}
   
   void update( double dt )
   {
      m_velocity[0] = apply_clamped_dot( m_velocity[0], dt, m_clamped_acceleration[0] );
      m_velocity[1] = apply_clamped_dot( m_velocity[1], dt, m_clamped_acceleration[1] );
      m_velocity[2] = apply_clamped_dot( m_velocity[2], dt, m_clamped_acceleration[2] );      
      m_centre += dt * m_velocity;
      m_radius = max( 0.0, m_radius + dt * m_radius_dot );
      m_magnitude = apply_clamped_dot( m_magnitude, dt, m_magnitude_clamped_dot );
   }
      
   Vec3d potential( double x, double y, double z );
   void apply( const Vec3d& x, Vec3d& v );
   
   Vec3d m_centre;
   Vec3d m_velocity;
   Vec3d m_clamped_acceleration[3];
   Vec3d m_orientation;
   
   double m_radius, m_radius_dot;
   double m_magnitude;
   Vec3d m_magnitude_clamped_dot;
   
   double m_dx;
   
};


// ---------------------------------------------------------

struct VortexRing : public FlowPrimitive
{
   VortexRing( const Vec3d& c, const Vec3d& v, double r, double m ) :
      m_centre(c),
      m_velocity(v),
      m_clamped_acceleration(),
      m_radius(r),
      m_radius_dot(0.0),
      m_magnitude(m),
      m_magnitude_clamped_dot( Vec3d(0.0, 0.0, MAXFLOAT) ),
      m_dx( 1e-4 )
   {}
   
   virtual ~VortexRing() {}
   
   void update( double dt )
   {
      m_velocity[0] = apply_clamped_dot( m_velocity[0], dt, m_clamped_acceleration[0] );
      m_velocity[1] = apply_clamped_dot( m_velocity[1], dt, m_clamped_acceleration[1] );
      m_velocity[2] = apply_clamped_dot( m_velocity[2], dt, m_clamped_acceleration[2] );      
      std::cout << "ring y-velocity: " << m_velocity[1] << std::endl;
      m_centre += dt * m_velocity;
      m_radius = max( 0.0, m_radius + dt * m_radius_dot );
      m_magnitude = apply_clamped_dot( m_magnitude, dt, m_magnitude_clamped_dot );
   }
   
   Vec3d potential( double x, double y, double z );
   void apply( const Vec3d& x, Vec3d& v );
   void render();
   
   Vec3d m_centre;
   Vec3d m_velocity;
   Vec3d m_clamped_acceleration[3];
   
   double m_radius, m_radius_dot;
   double m_magnitude;
   Vec3d m_magnitude_clamped_dot;
   
   double m_dx;
   
};

// ---------------------------------------------------------

struct DivergenceSource : public FlowPrimitive
{
   DivergenceSource( const Vec3d& c, const Vec3d& v, double r, double m, double l = 0.5 ) :
      m_centre(c),
      m_velocity(v),
      m_clamped_acceleration(),
      m_radius(r),
      m_radius_dot(0.0),
      m_magnitude(m),
      m_magnitude_clamped_dot(),
      m_lengthscale(l),
      m_lengthscale_dot(0.0),
      m_noise( ),
      m_time( 0.0 )
   {}
   
   virtual ~DivergenceSource() {}
   
   void update( double dt );
   
   void apply( const Vec3d& x, Vec3d& v );
   
   void render();
   
   Vec3d m_centre;
   Vec3d m_velocity;
   Vec3d m_clamped_acceleration[3];
   
   double m_radius, m_radius_dot;
   double m_magnitude;
   Vec3d m_magnitude_clamped_dot;
   double m_lengthscale, m_lengthscale_dot;
   
   FlowNoise3 m_noise;
   double m_time;

};

// ---------------------------------------------------------

struct NoiseOctave : public FlowPrimitive
{
   NoiseOctave( double l, double m ) : 
      m_lengthscale(l), 
      m_magnitude(m),
      m_dx( 1e-4 ),
      m_noise(),
      m_time(0)
   {}
   
   virtual ~NoiseOctave() {}
   
   virtual void update( double dt );   
   virtual Vec3d potential( double x, double y, double z );
   virtual void apply( const Vec3d& x, Vec3d& v );
   
   virtual double noise0(double x, double y, double z) const { return m_noise(x, y, z); }
   virtual double noise1(double x, double y, double z) const { return m_noise(y+51.416, z-27.853, x+32.793); }
   virtual double noise2(double x, double y, double z) const { return m_noise(z-203.994, x+169.47, y-205.31); }
   
   double m_lengthscale;
   double m_magnitude;
   double m_dx;
   FlowNoise3 m_noise;
   double m_time;
};


// ---------------------------------------------------------

struct AxisNoiseOctave : public NoiseOctave
{
   AxisNoiseOctave( const Vec3d& c, double l, double m ) : 
      NoiseOctave( l, m ),
      m_axis_centre( c )
   {}
   
   virtual ~AxisNoiseOctave() {}
   
   Vec3d potential( double x, double y, double z )
   {
      double width_factor = sqrt( sqr(x - m_axis_centre[0]) + sqr(z - m_axis_centre[2]) );
      width_factor = max( 0.25, 1.0 - width_factor );
      
      double sx=x/m_lengthscale;
      double sy=y/m_lengthscale;
      double sz=z/m_lengthscale;
      
      Vec3d psi_i(noise0(sx,sy,sz), noise1(sx,sy,sz), noise2(sx,sy,sz));
      
      return width_factor * m_magnitude * psi_i;      
   }

   Vec3d m_axis_centre;
   
};


// ---------------------------------------------------------

struct CentredNoise : public NoiseOctave
{
   CentredNoise( double l, double m ) : 
      NoiseOctave(l, m), 
      m_centre( 0, 0, 0 ),
      m_velocity( 0, 0, 0),
      m_acceleration( 0, 0, 0 ),
      m_radius( 1.0 ),
      m_radius_dot( 0.0 ),
      m_magnitude_dot( 0.0 ),
      m_lengthscale_dot( 0.0 )
   {}
   
   virtual ~CentredNoise() {}
   
   void update( double dt );
   Vec3d potential( double x, double y, double z );
   void apply( const Vec3d& x, Vec3d& v );
   
   Vec3d m_centre;
   Vec3d m_velocity;
   Vec3d m_acceleration;
   
   double m_radius, m_radius_dot;
   double m_magnitude_dot;
   double m_lengthscale_dot;
   
};


// ---------------------------------------------------------

struct Wind : public FlowPrimitive
{
   Wind() :
      m_direction( 1, 0, 0 ),
      m_noise(),
      m_time(0),
      m_period( 5.0 ),
      m_lengthscale( 0.5 ),
      m_height_factor( 0.1 )
   {}
      
   virtual ~Wind() {}
   
   void update( double dt ) 
   {
      m_time += dt;
   }
   
   void apply( const Vec3d& x, Vec3d& v )
   {
      double sx = x[0] / m_lengthscale, sy = x[1] / m_lengthscale, sz = x[2] / m_lengthscale;
      double noise01 = (m_noise( sx, sy, sz ) + 1.0) / 2.0;
      v += cos(2.0*M_PI*m_time/m_period) * noise01 * m_height_factor * x[1] * m_direction;
   }
   
   Vec3d m_direction;
   Noise3 m_noise;
   double m_time;
   double m_period;
   double m_lengthscale;
   double m_height_factor;
};


// ---------------------------------------------------------

// Manager will hold a list of these
//
struct GeneratorBase
{
   virtual ~GeneratorBase() {}
   virtual void tick( double current_time, std::vector<FlowPrimitive*>& m_flow_primitives ) = 0;
};

// ---------------------------------------------------------

template<class T>
struct Generator : public GeneratorBase
{
   Generator( const T recipe, double frequency, unsigned int total_to_generate ) :
      m_recipe( recipe ),
      m_frequency( frequency ),
      m_total_to_generate( total_to_generate ),
      m_num_already_generated( 0 )
   {}
   
   virtual ~Generator() {}
   
   virtual void tick( double current_time, std::vector<FlowPrimitive*>& flow_primitives )
   {
      if ( ( m_num_already_generated < (unsigned int) (current_time / m_frequency) ) && m_num_already_generated < m_total_to_generate )
      {
         flow_primitives.push_back( new T(m_recipe) );
         ++m_num_already_generated;
      }
   }
   
   const T m_recipe;
   double m_frequency;
   unsigned int m_total_to_generate;
   unsigned int m_num_already_generated;
   
};


// ---------------------------------------------------------

struct FlowPrimitiveManager
{
   FlowPrimitiveManager( double initial_t ) : 
      m_current_t(initial_t),
      m_flow_primitives(),
      m_generators()
   {}
   
   // --------------------------
   
   void update( double dt )
   {
      for ( unsigned int i = 0; i < m_flow_primitives.size(); ++i )
      {
         (m_flow_primitives[i])->update( dt );
      }

      for ( unsigned int i = 0; i < m_generators.size(); ++i )
      {
         (m_generators[i])->tick( m_current_t, m_flow_primitives );
      }
      
      m_current_t += dt;
   }
   
   // --------------------------
   
   void apply_flow_primitives( const Vec3d& x, Vec3d& v )
   {
      for ( unsigned int i = 0; i < m_flow_primitives.size(); ++i )
      {
         (m_flow_primitives[i])->apply( x, v );
      }      
   }
   
   // --------------------------
   
   void render_flow_primitives()
   {
      for ( std::vector<FlowPrimitive*>::iterator i = m_flow_primitives.begin(); i != m_flow_primitives.end(); ++i )
      {
         (**i).render();
      }
   }
   
   void add_flow_primitive( FlowPrimitive* new_primitive )
   {
      m_flow_primitives.push_back( new_primitive );
   }

   // --------------------------
   
   void add_flow_primitive_generator( GeneratorBase* new_generator )
   {
      m_generators.push_back( new_generator );
   }
   
   // --------------------------
   // --------------------------
   
   double m_current_t;
   std::vector< FlowPrimitive* > m_flow_primitives;   
   std::vector< GeneratorBase* > m_generators; 
   
};


#endif
