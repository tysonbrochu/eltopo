#ifndef MESH_IO_H
#define MESH_IO_H

// This provides two functions for basic reading/writing of triangle meshes in
// the Wavefront .OBJ format. (Many features of the .obj format are missing
// however --- this just looks at vertex, face, and optionally vertex normal data.)
// Usually the vertex indices in a .obj file are 1-based: the first vertex has label
// 1, not 0. However, this code assumes you are using C++-style 0-based arrays, i.e.
// you specify the first vertex with label 0. The code translates between the two
// conventions for you.

#include <vector>
#include "vec.h"

// Given an array of triangle indices in "tri", an array of vertex locations in "x" (where the indices stored
// in tri are indices into x), and an array of vertex normals in "normal", write a .obj format file
// with the given printf-style format specification of the filename. See bfstream.h or image_io.h
// for more on using this format for the filename. If the "normal" array is empty, no vertex normals are output.
// The function returns true if the file is written successfully.
bool write_objfile(const std::vector<Vec3i>& tri, const std::vector<Vec3f>& x, const std::vector<Vec3f>& normal,
                   const char *filename_format, ...);

// Attempt to read in a .obj file, storing a list of triangles in tri, vertices in x, and vertex normals if
// they were specified in normal (if not specified, normal is made empty). Returns true if it succeeded.
// Note that some parts of the file may be ignored, e.g. specifications of texture coordinates.
bool read_objfile(std::vector<Vec3i>& tri, std::vector<Vec3f>& x, std::vector<Vec3f>& normal,
                  const char *filename_format, ...);

#endif
