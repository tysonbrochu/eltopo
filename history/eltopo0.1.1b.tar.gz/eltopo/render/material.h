#ifndef SHADING_H
#define SHADING_H

// This provides very primitive shading capabilities: just one basic material model
// (a combination of emission, Lambertian diffuse reflectance, and perfect mirror
// reflectance) that a recursive raytracer can easily understand.

#include "vec.h"

struct Material
{
   Vec3f emission_color; // RGB values that always are emitted (as if this were glowing)
   Vec3f diffuse_color;  // RGB values for light uniformly reflected by Lambertian model
   Vec3f mirror_color;   // RGB values for light perfectly reflected as a mirror (specular)

   Material(void)
      : emission_color(0,0,0),
        diffuse_color(1,1,1),
        mirror_color(0,0,0)
   {}
};

#endif
