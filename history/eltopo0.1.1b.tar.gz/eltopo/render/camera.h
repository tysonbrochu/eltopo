#ifndef CAMERA_H
#define CAMERA_H

// This class represents the virtual camera, containing the
// model-view transformation (mapping world space to camera space),
// a specification of the perspective projection and clipping,
// and the desired pixel dimensions of the output image. Most
// importantly, it has a reference to the RayTracer object which
// will compute the color along given rays;
// Camera::render_image() decides which rays to ray trace, and then
// assembles the output image.

#include "transformation.h"
#include "raytracer.h"
#include "array2.h"

struct Camera
{
   // projection
   Transformation modelview; // the map from world space to camera space
   float near;               // the near clipping plane is z=-near in camera space: near must be positive!
   float left, right;        // specify the x-bounds of the image on the near clipping plane
   float bottom, top;        // specify the y-bounds of the image on the near clipping plane

   // image characteristics
   int pixel_width, pixel_height; // the dimensions of the output image in pixels

   // and the raytracer itself (with scene included)
   const RayTracer& raytracer;

   Camera(const RayTracer& raytracer_)
      : modelview(),
        near(1.f),
        left(-1.f), right(1.f),
        bottom(-0.66666666666666666667f), top(0.666666666666666666666667f),
        pixel_width(720), pixel_height(480),
        raytracer(raytracer_)
   {}

   // Pass in an image (a 2D array of RGB vectors) which is then appropriate resized and
   // filled in by raytracing.
   void render_image(Array2<Vec3f>& image) const;

   void render_image(Array2<Vec3f>& image, int supersampling) const;

   protected:
   // Used internally to figure out a ray in world space coordinates given a location in the
   // image in pixel coordinates.
   Ray generate_ray(const Transformation& modelview_inverse, float pixel_x, float pixel_y) const;
};

#endif
