#include <iostream>
#include "shapes.h"

//============================================================================

bool Plane::
quick_intersect(const Ray& ray, float tmin, float tmax) const
{
   float dn=dot(ray.direction, normal);
   if(dn==0) return false;
   float t=-dot(ray.origin-point,normal)/dn;
   return (t>=tmin && t<=tmax);
}

bool Plane::
intersect(const Ray& ray, float tmin, float tmax, float &t, Vec3f& surface_normal, Material& surface_material) const
{
   float dn=dot(ray.direction, normal);
   if(dn==0) return false; // if parallel, there's no intersection
   float t0=-dot(ray.origin-point,normal)/dn; // otherwise, the ray hits at this parameter value
   if(t0>=tmin && t0<=tmax){ // if it's in range, we hit!
      t=t0;
      // make sure we return a surface normal which faces the ray
      if(dot(normal,ray.direction)<0) surface_normal=normal;
      else surface_normal=-normal; // reverse the surface normal to face the ray
      surface_material=material;
      return true;
   }else
      return false;
}

BoundingBox Plane::
bounding_box(void) const
{
   // the max call is there to prevent a completely empty bounding box from being created
   // for a plane which is parallel to one of the axes. That could cause the primitive bounding box
   // intersection test to fail, which would be bad.
   Vec3f vector_bound(bound*max(std::sqrt((1-sqr(normal[0]))),1e-6f),
                      bound*max(std::sqrt((1-sqr(normal[1]))),1e-6f),
                      bound*max(std::sqrt((1-sqr(normal[2]))),1e-6f));
   return BoundingBox(point-vector_bound, point+vector_bound);
}

//============================================================================

bool CheckeredPlane::
intersect(const Ray& ray, float tmin, float tmax, float &t, Vec3f& surface_normal, Material& surface_material) const
{
   float dn=dot(ray.direction, normal);
   if(dn==0) return false; // if parallel, there's no intersection
   float t0=-dot(ray.origin-point,normal)/dn; // otherwise, the ray hits at this parameter value
   if(t0>=tmin && t0<=tmax){ // if it's in range, we hit!
      t=t0;
      // make sure we return a surface normal which faces the ray
      if(dot(normal,ray.direction)<0) surface_normal=normal;
      else surface_normal=-normal; // reverse the surface normal to face the ray
      surface_material=material;
      // this is where things get interesting
      Vec3f x=ray.origin+t*ray.direction;
      if(((int)std::floor(x[0]/step)+(int)std::floor(x[2]/step))%2){
         surface_material.emission_color*=0.5f;
         surface_material.diffuse_color*=0.5f;
         surface_material.mirror_color*=0.5f;
      }
      return true;
   }else
      return false;
}

//============================================================================

bool Sphere::
quick_intersect(const Ray& ray, float tmin, float tmax) const
{
   Vec3f oc(ray.origin-centre);
   float b=2*dot(oc,ray.direction), c=mag2(oc)-sqr(radius);
   float discriminant=sqr(b)-4*c;
   if(discriminant<0) return false;
   float sd=std::sqrt(discriminant);
   float t0=(-b-sd)/2;
   if(t0>=tmin && t0<=tmax) return true;
   float t1=(-b+sd)/2;
   if(t1>=tmin && t1<=tmax) return true;
   return false;
}

bool Sphere::
intersect(const Ray& ray, float tmin, float tmax, float &t, Vec3f& surface_normal, Material& surface_material) const
{
   Vec3f oc(ray.origin-centre);
   float b=2*dot(oc,ray.direction), c=mag2(oc)-sqr(radius);
   float discriminant=sqr(b)-4*c;
   if(discriminant<0) return false;
   float sd=std::sqrt(discriminant);
   float t0=(-b-sd)/2;
   if(t0>=tmin && t0<=tmax){
      t=t0;
      surface_normal=normalized(ray.origin+t*ray.direction-centre);
      surface_material=material;
      return true;
   }
   float t1=(-b+sd)/2;
   if(t1>=tmin && t1<=tmax){
      t=t1;
      surface_normal=normalized(centre-ray.origin+t*ray.direction);
      surface_material=material;
      return true;
   }
   return false;
}

BoundingBox Sphere::
bounding_box(void) const
{
   return BoundingBox(centre-Vec3f(radius), centre+Vec3f(radius));
}

//============================================================================

void TriangleMesh::
build_tree(void)
{
   std::vector<BoundingBox> box(tri.size());
   for(unsigned int f=0; f<tri.size(); ++f){
      int i, j, k; assign(tri[f], i, j, k);
      box[f].build_from_points(x[i], x[j], x[k]);
      box[f].enlarge(epsilon); // to avoid rounding problems later in intersection testing
   }
   tree.construct_from_leaf_boxes(tri.size(), &box[0]);
}

bool TriangleMesh::
quick_intersect(const Ray& ray, float tmin, float tmax) const
{
   // first check if the ray hits the root's bounding box
   float t;
   if(!tree.box.intersect(ray, tmin, tmax, t))
      return false;
   // if we get here it does hit; do a depth first search of the tree
   std::vector<const BoundingBoxTree*> stack;
   stack.push_back(&tree);
   float alpha, beta, gamma;
   while(!stack.empty()){
      const BoundingBoxTree *node=stack.back();
      stack.pop_back();
      // check if there's any primitive geometry to check in this node
      for(unsigned int i=0; i<node->index.size(); ++i){
         if(intersect_triangle(node->index[i], ray, tmin, tmax, t, alpha, beta, gamma)) return true;
      }
      // check if there are children nodes (with boxes intersecting the ray) to search later
      for(unsigned int i=0; i<node->children.size(); ++i){
         if(node->children[i]->box.intersect(ray, tmin, tmax, t))
            stack.push_back(node->children[i]); 
      }
   }
   return false; // got through search of tree without finding an intersection
   /*
   // slow version
   float t, alpha, beta, gamma;
   for(unsigned int f=0; f<tri.size(); ++f){
      if(intersect_triangle(f, ray, tmin, tmax, t, alpha, beta, gamma)) return true;
   }
   return false;
   */
}

bool TriangleMesh::
intersect(const Ray& ray, float tmin, float tmax, float &t, Vec3f& surface_normal, Material& surface_material) const
{
   // first check if the ray hits the root's bounding box
   float tbox;
   if(!tree.box.intersect(ray, tmin, tmax, tbox)) return false;
   // if we get here it does hit; do a depth first search of the tree for the first intersection if there is one
   bool found_intersection=false;
   std::vector<const BoundingBoxTree*> stack;
   stack.push_back(&tree);
   float t0, alpha, beta, gamma;
   while(!stack.empty()){
      const BoundingBoxTree *node=stack.back();
      stack.pop_back();
      // check if there's any primitive geometry to check in this node
      for(unsigned int i=0; i<node->index.size(); ++i){
         int f=node->index[i];
         if(intersect_triangle(f, ray, tmin, tmax, t0, alpha, beta, gamma)){
            t=t0;
            tmax=t0; // eliminate any further intersections from consideration
            if(normal.empty()){
               surface_normal=normalized(cross(x[tri[f][1]]-x[tri[f][0]], x[tri[f][2]]-x[tri[f][0]]));
            }else{
               surface_normal=normalized(alpha*normal[tri[f][0]]+beta*normal[tri[f][1]]+gamma*normal[tri[f][2]]);
            }
            found_intersection=true;
         }
      }
      // check if there are children nodes (with boxes intersecting the ray) to search later
      // Note: we could optimize this to put the children in reverse order of tbox on the stack,
      // but for simplicity's sake we won't do the sort.
      for(unsigned int i=0; i<node->children.size(); ++i){
         if(node->children[i]->box.intersect(ray, tmin, tmax, tbox)){
            stack.push_back(node->children[i]); 
         }
      }
   }
   if(found_intersection){
      if(dot(ray.direction, surface_normal)>0) surface_normal=-surface_normal;
      surface_material=material;
      return true;
   }else{
      return false;
   }
   /*
   // slow version
   bool found_intersection=false;
   float t0, alpha, beta, gamma;
   for(unsigned int f=0; f<tri.size(); ++f){
      if(intersect_triangle(f, ray, tmin, tmax, t0, alpha, beta, gamma)){
         t=t0;
         tmax=t0;
         if(normal.empty()){
            surface_normal=normalized(cross(x[tri[f][1]]-x[tri[f][0]], x[tri[f][2]]-x[tri[f][0]]));
         }else{
            surface_normal=normalized(alpha*normal[tri[f][0]]+beta*normal[tri[f][1]]+gamma*normal[tri[f][2]]);
         }
         found_intersection=true;
      }
   }
   if(found_intersection){
      if(dot(ray.direction, surface_normal)>0) surface_normal=-surface_normal;
      surface_material=material;
      return true;
   }else{
      return false;
   }
   */
}

BoundingBox TriangleMesh::
bounding_box(void) const
{
   assert(!tree.index.empty() || !tree.children.empty()); // check that tree was built before calling this
   return tree.box;
}

// This is the core issue: how to intersect a ray with a triangle.
bool TriangleMesh::
intersect_triangle(unsigned int f, const Ray& ray, float tmin, float tmax, float& t, float& alpha, float& beta, float& gamma) const
{
   // get the vertex indices (i, j, k) from tri[f]: the triangle has vertices x[i], x[j], and x[k]
   int i, j, k; assign(tri[f], i, j, k);
   // first get a vector orthogonal to triangle
   Vec3f ortho=cross(x[j]-x[i], x[k]-x[i]);
   // find plane intersection with ray
   float dn=dot(ray.direction, ortho);
   if(dn==0) return false;
   t=-dot(ray.origin-x[i],ortho)/dn;
   if(t<tmin || t>tmax) return false;
   // figure out the best 2d plane to project onto
   ortho=fabs(ortho);
   int axis0=1, axis1=2; // as if ortho[0] was the biggest
   if(ortho[1]>ortho[0]){
      axis0=0;
      if(ortho[2]>ortho[1]) axis1=1;
   }else if(std::fabs(ortho[2])>std::fabs(ortho[1])){
      axis0=0;
      axis1=1;
   }
   // now solve the 2d point-in-triangle problem
   Vec2f x0(x[i][axis0], x[i][axis1]),
         x1(x[j][axis0], x[j][axis1]),
         x2(x[k][axis0], x[k][axis1]),
         point(ray.origin[axis0]+t*ray.direction[axis0], ray.origin[axis1]+t*ray.direction[axis1]);
   // edge functions
   float f01=(x1[0]-x0[0])*(point[1]-x0[1]) - (point[0]-x0[0])*(x1[1]-x0[1]);
   float f12=(x2[0]-x1[0])*(point[1]-x1[1]) - (point[0]-x1[0])*(x2[1]-x1[1]);
   float f20=(x0[0]-x2[0])*(point[1]-x2[1]) - (point[0]-x2[0])*(x0[1]-x2[1]);
   // barycentric coordinates
   float S=f01+f12+f20;
   alpha=f12/S;
   beta=f20/S;
   gamma=1-alpha-beta;
   // include epsilon to avoid rounding problems
   return (alpha>=-epsilon && beta>=-epsilon && gamma>=-epsilon);
}

//============================================================================

void AggregateShape::
build_tree(void)
{
   std::vector<BoundingBox> box(subshape.size());
   for(unsigned int i=0; i<subshape.size(); ++i){
      box[i]=subshape[i]->bounding_box();
   }
   tree.construct_from_leaf_boxes(subshape.size(), &box[0]);
}

bool AggregateShape::
quick_intersect(const Ray& ray, float tmin, float tmax) const
{
   // first check if the ray hits the root's bounding box
   float t;
   if(!tree.box.intersect(ray, tmin, tmax, t))
      return false;
   // if we get here it does hit; do a depth first search of the tree
   std::vector<const BoundingBoxTree*> stack;
   stack.push_back(&tree);
   while(!stack.empty()){
      const BoundingBoxTree *node=stack.back();
      stack.pop_back();
      // check if there's any primitive geometry to check in this node
      for(unsigned int i=0; i<node->index.size(); ++i){
         if(subshape[node->index[i]]->quick_intersect(ray, tmin, tmax)) return true;
      }
      // check if there are children nodes (with boxes intersecting the ray) to search later
      for(unsigned int i=0; i<node->children.size(); ++i){
         if(node->children[i]->box.intersect(ray, tmin, tmax, t))
            stack.push_back(node->children[i]); 
      }
   }
   return false; // got through search of tree without finding an intersection
   /*
   // slow version to get us started
   for(unsigned int i=0; i<subshape.size(); ++i){
      if(subshape[i]->quick_intersect(ray, tmin, tmax)) return true;
   }
   return false;
   */
}

bool AggregateShape::
intersect(const Ray& ray, float tmin, float tmax, float &t, Vec3f& surface_normal, Material& surface_material) const
{
   // first check if the ray hits the root's bounding box
   float t_test;
   if(!tree.box.intersect(ray, tmin, tmax, t_test)) return false;
   // if we get here it does hit; do a depth first search of the tree for the first intersection if there is one
   bool found_intersection=false;
   std::vector<const BoundingBoxTree*> stack;
   stack.push_back(&tree);
   while(!stack.empty()){
      const BoundingBoxTree *node=stack.back();
      stack.pop_back();
      // check if there's any primitive geometry to check in this node
      for(unsigned int i=0; i<node->index.size(); ++i){
         if(subshape[node->index[i]]->intersect(ray, tmin, tmax, t_test, surface_normal, surface_material)){
            assert(t_test==t_test); // guard against NaN
            assert(surface_normal==surface_normal); // guard against NaN
            t=t_test;
            tmax=t_test; // eliminate any further intersections from consideration
            found_intersection=true;
         }
      }
      // check if there are children nodes (with boxes intersecting the ray) to search later
      // Note: we could optimize this to put the children in reverse order of t_test on the stack
      for(unsigned int i=0; i<node->children.size(); ++i){
         if(node->children[i]->box.intersect(ray, tmin, tmax, t_test)){
            stack.push_back(node->children[i]); 
         }
      }
   }
   return found_intersection;
   /*
   // slow version to get us started
   bool found_intersection=false;
   for(unsigned int i=0; i<subshape.size(); ++i){
      if(subshape[i]->intersect(ray, tmin, tmax, t, surface_normal, surface_material)){
         tmax=t;
         found_intersection=true;
      }
   }
   return found_intersection;
   */
}

BoundingBox AggregateShape::
bounding_box(void) const
{
   assert(!tree.index.empty() || !tree.children.empty()); // check that tree was built before calling this
   return tree.box;
}

