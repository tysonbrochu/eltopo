// ---------------------------------------------------------
//
//  subdivisionscheme.h
//  
//  A collection of interpolation schemes for generating vertex locations.
//
// ---------------------------------------------------------

#ifndef SUBDIVISIONSCHEME_H
#define SUBDIVISIONSCHEME_H

// ---------------------------------------------------------
// Nested includes
// ---------------------------------------------------------

#include <vec.h>

// ---------------------------------------------------------
//  Forwards and typedefs
// ---------------------------------------------------------

class DynamicSurface;

// ---------------------------------------------------------
//  Interface declarations
// ---------------------------------------------------------

// --------------------------------------------------------
///
/// Subdivision scheme interface.  Declares the function prototype for finding an interpolated vertex location.
///
// --------------------------------------------------------

class SubdivisionScheme
{
public:
   virtual ~SubdivisionScheme() {}
   virtual void generate_new_midpoint( unsigned int edge_index, const DynamicSurface& surface, Vec3d& new_point, Vec3d& new_vertex_reference_position ) = 0;
};

// --------------------------------------------------------
///
/// Midpoint scheme: simply places the new vertex at the midpoint of the edge
///
// --------------------------------------------------------

class MidpointScheme : public SubdivisionScheme
{
public:
   void generate_new_midpoint( unsigned int edge_index, const DynamicSurface& surface, Vec3d& new_point, Vec3d& new_vertex_reference_position );   
};

// --------------------------------------------------------
///
/// Butterfly scheme: uses a defined weighting of nearby vertices to determine the new vertex location
///
// --------------------------------------------------------

class ButterflyScheme : public SubdivisionScheme
{
public:   
   void generate_new_midpoint( unsigned int edge_index, const DynamicSurface& surface, Vec3d& new_point, Vec3d& new_vertex_reference_position );
};

// --------------------------------------------------------
///
/// Quadric error minimization scheme: places the new vertex at the location that minimizes the change in the quadric metric tensor along the edge.
///
// --------------------------------------------------------

class QuadraticErrorMinScheme : public SubdivisionScheme
{
public:
   void generate_new_midpoint( unsigned int edge_index, const DynamicSurface& surface, Vec3d& new_point, Vec3d& new_vertex_reference_position );
};


#endif



