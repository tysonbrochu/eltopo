// ---------------------------------------------------------
//
//  meshdriver.h
//  Tyson Brochu 2008
//
//  Interface for a class that specifies vertex velocities over a mesh.
//
// ---------------------------------------------------------

#ifndef MESHDRIVER_H
#define MESHDRIVER_H

// ---------------------------------------------------------
// Nested includes
// ---------------------------------------------------------

#include <vector>
#include <vec.h>

// ---------------------------------------------------------
//  Forwards and typedefs
// ---------------------------------------------------------

class DynamicSurface;

// ---------------------------------------------------------
//  Interface declarations
// ---------------------------------------------------------

// ---------------------------------------------------------
///
/// Base class for anything that moves a dynamic mesh
///
// ---------------------------------------------------------

class MeshDriver
{
public:
   
   /// Silence compiler warning
   ///
   virtual ~MeshDriver() {}
   
   /// Initialise the driver with the surface at t = 0.  Default does nothing
   ///
   virtual void initialize( const DynamicSurface& surf ) {}
   
   /// Draw something with OpenGL.  Default does nothing.
   ///
   virtual void display( const DynamicSurface& surf ) {}
   
   /// Set velocities on each mesh vertex
   ///
   virtual void set_surface_velocity( const DynamicSurface& surf, std::vector<Vec3d>& out_velocity, double current_t, double& adaptive_dt ) = 0;

   /// Compute and output error.  Default does nothing.
   ///
   virtual void compute_error( const DynamicSurface& surf, double current_t ) {}
   
};

#endif

