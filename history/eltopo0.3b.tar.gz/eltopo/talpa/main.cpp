// ---------------------------------------------------------
//
//  main.cpp
//  Tyson Brochu 2008
//
//  Functions for setting up and running an explicit surface simulation, 
//  as well as visualizing it with gluvi.
//
// ---------------------------------------------------------

// ---------------------------------------------------------
// Includes
// ---------------------------------------------------------

#include <cstdio>
#include <fstream>
#include <vector>
#include <queue>

#include <options.h>

// common
#include <array2.h>
#ifdef USE_GUI
#include <gluvi.h>
#endif
#include <marching_tiles_hires.h>
#include <meshloader.h>
#include <util.h>
#include <vec.h>
#include <wallclocktime.h>

// el topo
#include <eltopo.h>
#include <iomesh.h>
#include <meancurvature.h>
#include <meshdriver.h>
#include <parser.h>
#include <simulation.h>
#include <surftrack.h>

// ---------------------------------------------------------
// Globals
// ---------------------------------------------------------

SurfTrack *g_surf;        // The dynamic surface
MeshDriver *g_driver;     // The thing that makes the dynamic surface go
Simulation *g_sim;        // Timekeeping

char g_output_path[256];  // Where to write output data

#ifdef USE_GUI

float g_camera_target[] = {0.0f, 0.0f, 0.0f};    // OpenGL camera points here
Gluvi::Target3D g_cam(g_camera_target, 10.0f);   // OpenGL camera

bool g_render_edges;
bool g_render_fill_triangles;
bool g_render_colliding_triangles;
bool g_render_vertex_rank;
bool g_display_driver = false;
bool g_smooth_shading = true;

#else

struct hack_camera
{
   float target[3];
   float dist;
   float pitch;
   float heading;
} g_cam;

#endif

std::vector<double> g_vertex_values;
std::vector<unsigned int> g_intersecting_triangles;

// Mouse click / ray casting data
int g_selected_vertex = -1;
int g_selected_edge = -1;
int g_selected_triangle = -1;
float g_ray_origin[3], g_ray_direction[3];

// Stats and timings

unsigned int g_min_num_triangles;
unsigned int g_max_num_triangles;
unsigned int g_total_num_triangles;

unsigned int g_min_num_vertices;
unsigned int g_max_num_vertices;
unsigned int g_total_num_vertices;

unsigned int g_total_steps = 0;

double g_total_sim_time = 0;
double g_total_improvement_time = 0;
double g_total_topology_time = 0;
double g_total_driver_time = 0;
double g_total_collision_time = 0;

bool g_skip_improve = false;
bool g_skip_to_integration = false;

bool g_making_animation = false;

// TEMP: display options for fluid sim driver
unsigned int g_fluid_render_type = 6;
const unsigned int g_fluid_render_type_max = 7;


// ---------------------------------------------------------
// Interface declarations
// ---------------------------------------------------------

void display_stats( );

void advance_sim();
void run_simulation(void);

#ifdef USE_GUI
void keyboard(unsigned char key, int x, int y);
void advance_frame();
void mouse(int button, int state, int x, int y);
void mouseMotion(int x, int y);
void bin2sgi();
void display(void);
void init_gui( int argc, char **argv );
#endif

void init_simulation( int argc, char **argv );

int main(int argc, char **argv);


// ---------------------------------------------------------
// Function definitions
// ---------------------------------------------------------

// ---------------------------------------------------------
///
/// Output collected stats to stdout
///
// ---------------------------------------------------------

void display_stats( )
{
   std::cout << "g_total_sim_time: " << g_total_sim_time << std::endl;
   std::cout << "g_total_improvement_time: " << g_total_improvement_time << std::endl;
   std::cout << "g_total_topology_time: " << g_total_topology_time << std::endl;
   std::cout << "g_total_driver_time: " << g_total_driver_time << std::endl;
   std::cout << "g_total_collision_time: " << g_total_collision_time << std::endl;   

   std::cout << "g_total_steps: " << g_total_steps << std::endl;
   
   std::cout << "avg improvement time per step: " << g_total_improvement_time / (double) g_total_steps << std::endl;
   std::cout << "avg topology time per step: " << g_total_topology_time / (double) g_total_steps << std::endl;
   std::cout << "avg driver time per step: " << g_total_driver_time / (double) g_total_steps << std::endl;
   std::cout << "avg collision handling time per step: " << g_total_collision_time / (double) g_total_steps << std::endl;   
      
   std::cout << "min number of triangles: " << g_min_num_triangles << std::endl;
   std::cout << "max number of triangles: " << g_max_num_triangles << std::endl;
   std::cout << "min number of vertices: " << g_min_num_vertices << std::endl;
   std::cout << "max number of vertices: " << g_max_num_vertices << std::endl;   

   std::cout << "avg num triangles per step: " << (double) g_total_num_triangles / (double) g_total_steps << std::endl;
   
   std::cout << "g_total_num_triangles: " << g_total_num_triangles << std::endl;
   std::cout << "g_total_num_vertices: " << g_total_num_vertices << std::endl;

   std::cout << "total_num_collisions: " << g_surf->m_total_num_collisions << std::endl;
   
}


// ---------------------------------------------------------
///
/// Perform static operations (mesh improvement and topology changes) through the El Topo API.
///
// ---------------------------------------------------------

void static_operations( )
{
   
   //
   // Put SurfTrack data into C-array format.
   //
   
   unsigned int nv = g_surf->m_positions.size();
   double *masses = new double[nv];
   double *positions = new double[3*nv];
   for ( unsigned int i = 0; i < nv; ++i )
   {
      masses[i] = g_surf->m_masses[i];
      positions[3*i] = g_surf->m_positions[i][0];
      positions[3*i+1] = g_surf->m_positions[i][1];
      positions[3*i+2] = g_surf->m_positions[i][2];         
   }
   
   unsigned int nt = g_surf->m_mesh.m_tris.size();
   int *triangles = new int[3*nt];
   for ( unsigned int i = 0; i < nt; ++i )
   {
      triangles[3*i] = g_surf->m_mesh.m_tris[i][0];
      triangles[3*i+1] = g_surf->m_mesh.m_tris[i][1];
      triangles[3*i+2] = g_surf->m_mesh.m_tris[i][2];         
   }      
                               
   ElTopoGeneralOptions general_options;
   general_options.m_verbose = g_surf->m_verbose;
   general_options.m_collision_safety = g_surf->m_collision_safety;
   
   ElTopoStaticOperationsOptions static_options;
   static_options.m_allow_topology_changes = g_surf->m_allow_topology_changes;
   static_options.m_max_volume_change = g_surf->m_max_volume_change;
   static_options.m_min_edge_length = g_surf->m_min_edge_length;
   static_options.m_max_edge_length = g_surf->m_max_edge_length;
   static_options.m_merge_proximity_epsilon = g_surf->m_merge_proximity_epsilon;
   static_options.m_perform_improvement = g_surf->m_perform_improvement;
   static_options.m_subdivision_scheme = g_surf->m_subdivision_scheme;
   
   // ====================================================================================================
   
   //
   // Run static operations
   //
   
   int out_num_vertices;                
   double* out_vertex_locations;
   int out_num_triangles;
   int* out_triangles;
   double* out_masses;
   
   el_topo_static_operations( nv,
                              positions,
                              nt,
                              triangles,
                              masses,
                              &general_options,       
                              &static_options, 
                              &out_num_vertices,
                              &out_vertex_locations,
                              &out_num_triangles,
                              &out_triangles,
                              &out_masses );
         
   
   // ====================================================================================================
   
   //
   // Now update SurfTrack with new data
   //
   
   std::vector<Vec3d> new_positions;
   std::vector<double> new_masses;
   for ( int i = 0; i < out_num_vertices; ++i )
   {
      new_positions.push_back( Vec3d( out_vertex_locations[3*i], out_vertex_locations[3*i+1], out_vertex_locations[3*i+2] ) ); 
      new_masses.push_back( out_masses[i] );
   }
   
   std::vector<Vec3ui> new_triangles;
   for ( int i = 0; i < out_num_triangles; ++i )
   {
      new_triangles.push_back( Vec3ui( out_triangles[3*i], out_triangles[3*i+1], out_triangles[3*i+2] ) ); 
   }
   

   g_surf->m_positions = new_positions;
   g_surf->m_masses = new_masses;
   g_surf->m_newpositions.resize( out_num_vertices );
   g_surf->m_velocities.resize( out_num_vertices );
   g_surf->m_mesh.m_tris = new_triangles;
   g_surf->m_mesh.update_connectivity( out_num_vertices );
   
   el_topo_free_static_operations_results( out_vertex_locations, out_triangles, out_masses );
   
   delete[] masses;
   delete[] positions;
   delete[] triangles;

}

// ---------------------------------------------------------
///
/// Perform integration through the El Topo API.
///
// ---------------------------------------------------------

void integration_operations( double dt, const std::vector<Vec3d>& predicted_positions )
{
   
   //
   // Put SurfTrack data into C-array format.
   //
   
   unsigned int nv = g_surf->m_positions.size();
   double *c_masses = new double[nv];
   double *c_positions = new double[3*nv];
   double *c_predicted_positions = new double[3*nv];
   for ( unsigned int i = 0; i < nv; ++i )
   {
      c_masses[i] = g_surf->m_masses[i];
      c_positions[3*i] = g_surf->m_positions[i][0];
      c_positions[3*i+1] = g_surf->m_positions[i][1];
      c_positions[3*i+2] = g_surf->m_positions[i][2];         
      c_predicted_positions[3*i] = predicted_positions[i][0];
      c_predicted_positions[3*i+1] = predicted_positions[i][1];
      c_predicted_positions[3*i+2] = predicted_positions[i][2];      
   }
   
   unsigned int nt = g_surf->m_mesh.m_tris.size();
   int *c_triangles = new int[3*nt];
   for ( unsigned int i = 0; i < nt; ++i )
   {
      c_triangles[3*i] = g_surf->m_mesh.m_tris[i][0];
      c_triangles[3*i+1] = g_surf->m_mesh.m_tris[i][1];
      c_triangles[3*i+2] = g_surf->m_mesh.m_tris[i][2];         
   }      
   
   ElTopoGeneralOptions general_options;
   general_options.m_verbose = g_surf->m_verbose;
   general_options.m_collision_safety = g_surf->m_collision_safety;
   
   ElTopoIntegrationOptions integration_options;
   integration_options.m_proximity_epsilon = g_surf->m_proximity_epsilon;
   integration_options.m_dt = dt;
   
   // ====================================================================================================
   
   //
   // Run integration operations
   //
   
   double* out_vertex_locations;
   
   el_topo_integrate( nv,
                      c_positions,
                      c_predicted_positions,
                      nt,
                      c_triangles,
                      c_masses,
                      &general_options,
                      &integration_options,
                      &out_vertex_locations );
   
   // ====================================================================================================
   
   //
   // Now update SurfTrack with new positions
   //

   for ( unsigned int i = 0; i < nv; ++i )
   {
      g_surf->m_positions[i] = Vec3d( out_vertex_locations[3*i], out_vertex_locations[3*i+1], out_vertex_locations[3*i+2] );
   }
   
   el_topo_free_integrate_results( out_vertex_locations );
   
   delete[] c_masses;
   delete[] c_positions;
   delete[] c_predicted_positions;  
   delete[] c_triangles;
   
}


// ---------------------------------------------------------
///
/// Advance simulation, GUI-ignorant
///
// ---------------------------------------------------------

void advance_sim()
{
   
   double start_time = get_time_in_seconds();
   
   double accum_dt = 0;
   
   while ( (accum_dt < g_sim->m_dt) && (g_sim->m_curr_t + accum_dt < g_sim->m_max_t) && (g_sim->m_running == true) )        
   {       
      
      std::cout << "clearing deleted triangles" << std::endl;
      g_surf->m_mesh.clear_deleted_triangles();
      std::cout << "update connectivity" << std::endl;
      g_surf->m_mesh.update_connectivity( g_surf->m_positions.size() );   
      
      ++g_total_steps;
      
      std::cout << "rebuilding broad phase" << std::endl;
      g_surf->rebuild_static_broad_phase();

      // ----------
      // collect stats
      // ----------
      
      g_min_num_triangles = min( g_min_num_triangles, (unsigned int) g_surf->m_mesh.m_tris.size() );
      g_max_num_triangles = max( g_max_num_triangles, (unsigned int) g_surf->m_mesh.m_tris.size() );
      g_total_num_vertices += g_surf->m_positions.size();
      g_min_num_vertices = min( g_min_num_vertices, (unsigned int) g_surf->m_positions.size() );
      g_max_num_vertices = max( g_max_num_vertices, (unsigned int) g_surf->m_positions.size() );      
      g_total_num_triangles += g_surf->m_mesh.m_tris.size();
            
      // ---------- 
      // mesh maintenance & topology changes
      // ---------- 
     
      if ( false == g_skip_improve && false == g_skip_to_integration )
      {
         // El Topo API:
         //static_operations();
         
         char v_binary_filename[256];
         sprintf( v_binary_filename, "%s/pre-improve.bin", g_output_path );      
         write_binary_file( g_surf->m_mesh, g_surf->m_positions, g_surf->m_masses, g_sim->m_curr_t, v_binary_filename );   
         
         // SurfTrack API:
         g_surf->improve_mesh();
         g_surf->topology_changes();
      }
            
      // ---------- 
      // advance underlying simulation
      // ----------
                  
      double curr_dt = g_sim->m_dt - accum_dt;
      curr_dt = min( curr_dt, g_sim->m_max_t - g_sim->m_curr_t - accum_dt );
      
      printf( "desired dt: %g\n", curr_dt );
      
      printf( "setting surface velocity\n" );

      double time_before_driver = get_time_in_seconds();

      if ( false == g_skip_to_integration )
      {
         g_surf->m_velocities.resize( g_surf->m_positions.size() );
         g_driver->set_surface_velocity( *g_surf, g_surf->m_velocities, g_sim->m_curr_t + accum_dt, curr_dt );
      }
      
      double time_after_driver = get_time_in_seconds();
      
      g_total_driver_time += time_after_driver - time_before_driver;
               
      printf( "adapted dt: %g\n", curr_dt );
      
      // ----------
      // move & handle collision detection
      // ----------
      
      double time_before_integration = get_time_in_seconds();
      
      //
      // El Topo API:
      //
      
//      std::vector<Vec3d> predicted_positions( g_surf->m_positions.size() );
//      for ( unsigned int i = 0; i < g_surf->m_positions.size(); ++i )
//      {
//         predicted_positions[i] = g_surf->m_positions[i] + curr_dt * g_surf->m_velocities[i];
//      }      
//      integration_operations( curr_dt, predicted_positions );
            
      char v_binary_filename[256];
      sprintf( v_binary_filename, "%s/pre-integration.bin", g_output_path );      
      write_binary_file_with_velocities( g_surf->m_mesh, g_surf->m_positions, g_surf->m_masses, g_surf->m_velocities, g_sim->m_curr_t, v_binary_filename );   
      
      //
      // DynamicSurface:
      //
      
      g_surf->integrate( curr_dt );
      
      g_total_collision_time += get_time_in_seconds() - time_before_integration;
      
      if ( g_surf->m_collision_safety )
      {
         g_surf->assert_mesh_is_intersection_free();      
      }
      
      accum_dt += curr_dt;
      
      g_driver->compute_error( *g_surf, g_sim->m_curr_t + accum_dt );
      
   }
      
   double sim_step_time = get_time_in_seconds() - start_time;
   g_total_sim_time += sim_step_time;
   
   ++g_sim->m_curr_frame;
   g_sim->m_curr_t += accum_dt;
   

   g_surf->m_mesh.clear_deleted_triangles();
   g_surf->m_mesh.update_connectivity( g_surf->m_positions.size() );   

   printf( "frame: %d  ---  t: %f   \n", g_sim->m_curr_frame, g_sim->m_curr_t );
   printf( "run time: %f --- tris: %d \n", sim_step_time, (int)g_surf->m_mesh.m_tris.size() );
      
   // ----------
   // file output
   // ----------
   
   char binary_filename[256];
   sprintf( binary_filename, "%s/frame%04d.bin", g_output_path, g_sim->m_curr_frame );      
   write_binary_file( g_surf->m_mesh, g_surf->m_positions, g_surf->m_masses, g_sim->m_curr_t, binary_filename );   

   //char v_binary_filename[256];
   //sprintf( v_binary_filename, "%s/frame%04d-with-velocities.bin", g_output_path, g_sim->m_curr_frame );      
   //write_binary_file_with_velocities( g_surf->m_mesh, g_surf->m_positions, g_surf->m_masses, g_surf->m_velocities, g_sim->m_curr_t, v_binary_filename );   
   
   int render_period = 1;
   if ( g_sim->m_curr_frame % render_period == 0 )
   {
      char sgi_filename[256];
      sprintf( sgi_filename, "%s/frame%04d.sgi", g_output_path, g_sim->m_curr_frame );      
      //render_scene( sgi_filename );
   }      
   
   // ----------
   // check if max time is reached
   // ----------

   if ( g_sim->m_curr_t + 1e-10 >= g_sim->m_max_t )
   {         
      g_sim->m_running = false;
      std::cout << "total time steps: " << g_total_steps << std::endl;
      display_stats();
   }
      
}


// ---------------------------------------------------------
///
/// Run an entire simulation without GUI
///
// ---------------------------------------------------------
void run_simulation(void)
{
   g_sim->m_running = true;
   while ( g_sim->m_running )
   {
      if(!g_sim->m_currently_advancing_simulation)
      {
         g_sim->m_currently_advancing_simulation = true;
         
         advance_sim();
         
         g_sim->m_currently_advancing_simulation = false;
      }
   }
   g_sim->m_running = false;
}


// ---------------------------------------------------------
///
/// Run all examples from the SISC submission
///
// ---------------------------------------------------------

void run_all_sisc_examples( const char* sisc_script_directory )
{
   std::cout << "\n\n\n -------------- running all SISC examples -------------- \n\n\n" << std::endl;
   
   std::vector<std::string> sisc_script_filenames;
   sisc_script_filenames.push_back( "faceoff-params-1.txt" );
   sisc_script_filenames.push_back( "faceoff-params-2.txt" );
   sisc_script_filenames.push_back( "faceoff-params-3.txt" );         
   sisc_script_filenames.push_back( "normal-params-1.txt" );
   sisc_script_filenames.push_back( "normal-params-2.txt" );
   sisc_script_filenames.push_back( "normal-params-3.txt" );      
   sisc_script_filenames.push_back( "mc-params-1.txt" );   
   sisc_script_filenames.push_back( "mc-params-2.txt" );   
   sisc_script_filenames.push_back( "mc-params-3.txt" );         
   sisc_script_filenames.push_back( "enright-parameters.txt" );
   sisc_script_filenames.push_back( "curlnoise-parameters.txt" );
   sisc_script_filenames.push_back( "tangled.txt" );
   sisc_script_filenames.push_back( "open-curlnoise-parameters.txt" );

   
   std::vector<std::string> output_directories;
   output_directories.push_back( "/faceoff1/" );
   output_directories.push_back( "/faceoff2/" );
   output_directories.push_back( "/faceoff3/" );   
   output_directories.push_back( "/normal1/" );
   output_directories.push_back( "/normal2/" );
   output_directories.push_back( "/normal3/" );
   output_directories.push_back( "/mc1/" );      
   output_directories.push_back( "/mc2/" );
   output_directories.push_back( "/mc3/" );   
   output_directories.push_back( "/enright/" );
   output_directories.push_back( "/curlnoise/" );
   output_directories.push_back( "/tangled/" );
   output_directories.push_back( "/opencurlnoise/" );
   
   char results_filename[256];
   strcpy( results_filename, g_output_path );
   strcat( results_filename, "results.txt" );
   std::ofstream results_file( results_filename, std::ios_base::trunc );      // clears existing contents!
   assert( results_file.good() );
   
   std::cout << "results: " << results_filename << std::endl;
   
   for ( unsigned int i = 0; i < sisc_script_filenames.size(); ++i )
   {
      delete g_sim;
      delete g_surf;
      delete g_driver;

      char base_output_path[256];
      strcpy( base_output_path, g_output_path );
      
      std::cout << "base_output_path: " << base_output_path << std::endl;
         
      // set the output path
      strcat( g_output_path, output_directories[i].c_str() );
      std::cout << "output path: " << g_output_path << std::endl;
      
      // re-initialize the simulation
      char filename[256];
      strcpy( filename, sisc_script_directory );
      strcat( filename, sisc_script_filenames[i].c_str() );
      
      char* fake_argv[2] = { NULL, filename };
      init_simulation( 2, fake_argv );
      
      results_file << "filename: " << sisc_script_filenames[i] << std::endl;
      results_file << "------------------------------------------" << std::endl;
      results_file << "avg edge length: " << g_surf->get_average_edge_length() << std::endl;
      results_file << "min edge length: " << g_surf->m_min_edge_length << std::endl;
      results_file << "max edge length: " << g_surf->m_max_edge_length << std::endl;
      results_file << "max volume change: " << g_surf->m_max_volume_change << std::endl;
      
      {
         char binary_filename[256];
         sprintf( binary_filename, "%s/frame%04d.bin", g_output_path, g_sim->m_curr_frame );      
         write_binary_file( g_surf->m_mesh, g_surf->m_positions, g_surf->m_masses, g_sim->m_curr_t, binary_filename );   
      }   
      
      run_simulation();
      
      std::cout << "\n -------------- sim done -------------- \n\n\n" << std::endl;
      
      // re-route cout to outfile
      std::streambuf* sbuf = std::cout.rdbuf();
      std::cout.rdbuf(results_file.rdbuf());
      
      // put final error into outfile
      g_driver->compute_error( *g_surf, g_sim->m_curr_t );

      // put timings and mesh resolution stats into outfile
      display_stats();
      
      std::cout << std::endl;
      
      // now restore cout to usual
      std::cout.rdbuf(sbuf);
            
      // restore output path
      strcpy( g_output_path, base_output_path );
      
   }
   
   results_file.close();
   
}
                           

// =========================================================
// GUI FUNCTIONS
// =========================================================

#ifdef USE_GUI

// ---------------------------------------------------------
///
/// Handle keyboard input
///
// ---------------------------------------------------------

void keyboard(unsigned char key, int, int )
{

   // TEMP: display options for fluid sim driver
   if ( key == 'f' )
   {
      g_fluid_render_type = ( g_fluid_render_type + 1 ) % g_fluid_render_type_max;
   }
      
   if(key == 'q')
   {
      delete g_surf;
      delete g_driver;
      exit(0);
   }
   
   if ( key == 's' )
   {
      g_display_driver = !g_display_driver;
   }
   
   // run one frame
   // 
   if(key == 'n')
   {
      g_sim->m_running = true;
      advance_frame();
      g_sim->m_running = false;      
   }
   
   if ( key == 'e' )
   {
      g_render_edges = !g_render_edges;
   }
   
   if ( key == 't' )
   {
      g_render_fill_triangles = !g_render_fill_triangles;
   }
   
   if ( key == 'c' )
   {
      g_render_colliding_triangles = !g_render_colliding_triangles;
      if ( g_render_colliding_triangles )
      {
         g_intersecting_triangles.clear();
         g_surf->assert_mesh_is_intersection_free();
         std::cout << "num intersecting triangles: " << g_intersecting_triangles.size() << std::endl;
      }
   }
   
   if ( key == 'v' )
   {
      g_render_vertex_rank = !g_render_vertex_rank;
   }
   
   // run improvement sweep
   //
   if ( key == 'i' )
   {
      g_sim->m_currently_advancing_simulation = true;
      
      g_surf->improve_mesh();
      g_surf->rebuild_static_broad_phase();
      g_surf->trim_non_manifold();
      
      g_surf->rebuild_static_broad_phase();
      g_surf->assert_mesh_is_intersection_free();
      
      g_sim->m_currently_advancing_simulation = false;
   }
   
   // return to default camera
   //
   if ( key == 'r' )
   {
      g_cam.return_to_default();
   }
   
   // define default camera
   //
   if ( key == 'd' )
   {
      g_cam.default_target[0] = g_cam.target[0];
      g_cam.default_target[1] = g_cam.target[1];
      g_cam.default_target[2] = g_cam.target[2];      
      g_cam.default_dist = g_cam.dist;
      g_cam.default_heading = g_cam.heading;
      g_cam.default_pitch = g_cam.pitch;   
      
      std::cout << "cam_target " << g_cam.default_target[0] << " " <<  g_cam.default_target[1] << " " << g_cam.default_target[2] << std::endl;
      std::cout << "cam_distance " << g_cam.default_dist << std::endl;
      std::cout << "cam_heading " << g_cam.default_heading << std::endl;
      std::cout << "cam_pitch " << g_cam.default_pitch << std::endl;
   }

   if ( key == 'l' )
   {
      g_smooth_shading = !g_smooth_shading;
   }
   
   // output binary file
   //
   if(key == 'b')
   {
      char binary_filename[256];
      sprintf( binary_filename, "%s/frame%04d.bin", g_output_path, g_sim->m_curr_frame );      
      write_binary_file( g_surf->m_mesh, g_surf->m_positions, g_surf->m_masses, g_sim->m_curr_t, binary_filename );   
      std::cout << "binary file written" << std::endl;      
   }
   
   // output OBJ file
   //
   if(key == 'o')
   {
      char obj_filename[256];
      sprintf( obj_filename, "%s/frame%04d.obj", g_output_path, g_sim->m_curr_frame );
      write_objfile( g_surf->m_mesh, g_surf->m_positions, obj_filename );
      std::cout << "obj file written" << std::endl;
   }
   
   // SGI screenshot
   //
   if(key == 'p')
   {
      char sgi_filename[256];
      sprintf( sgi_filename, "%s/frame%04d.sgi", g_output_path, g_sim->m_curr_frame );      
      Gluvi::sgi_screenshot( sgi_filename );
      std::cout << "sgi screen shot taken" << std::endl;
   }


   // SGI screenshots for a sequence of bin files
   //
   if(key == 'P')
   {
      g_making_animation = true;
      
      g_sim->m_curr_frame = 0;
      g_surf->m_positions.clear();
      g_surf->m_mesh.clear();
      
      char bin_filename[256];
      sprintf( bin_filename, "%s/frame%04d.bin", g_output_path, g_sim->m_curr_frame );            
      std::cout << "loading " << bin_filename << std::endl;
      bool good = read_binary_file( g_surf->m_mesh, g_surf->m_positions, g_surf->m_masses, g_sim->m_curr_t, bin_filename );
      
      if (!good)
      {
         g_making_animation = false;
      }
      
      g_surf->m_mesh.clear_deleted_triangles();
      g_surf->m_mesh.update_connectivity( g_surf->m_positions.size() );   
      
      glutPostRedisplay();
      
   }
   
   // toggle simulation
   //
   if(key == ' ')
   {
      g_sim->m_running = !g_sim->m_running;
      std::cout << "running: " << (g_sim->m_running ? "yes" : "no") << std::endl;
      
      if ( !g_sim->m_running )
      {
         display_stats();
      }
   }
   
   if (key == 'g')
   {
      char v_binary_filename[256];
      sprintf( v_binary_filename, "%s/pre-integration.bin", g_output_path );      
      read_binary_file_with_velocities( g_surf->m_mesh, g_surf->m_positions, g_surf->m_masses, g_surf->m_velocities, g_sim->m_curr_t, v_binary_filename );         
      g_surf->m_mesh.update_connectivity( g_surf->m_positions.size() );
      g_surf->integrate( g_sim->m_dt );
   }

   if (key == 'h')
   {
      char v_binary_filename[256];
      sprintf( v_binary_filename, "%s/pre-improve.bin", g_output_path );      
      read_binary_file( g_surf->m_mesh, g_surf->m_positions, g_surf->m_masses, g_sim->m_curr_t, v_binary_filename );   
      g_surf->m_velocities.resize( g_surf->m_positions.size() );
      g_surf->m_newpositions.resize( g_surf->m_positions.size() );
      g_surf->m_mesh.update_connectivity( g_surf->m_positions.size() );
      g_surf->improve_mesh();
   }   
   
   glutPostRedisplay();
   
}


// ---------------------------------------------------------
///
/// Handle mouse click
///
// ---------------------------------------------------------

void mouse(int button, int state, int x, int y)
{
   if ( glutGetModifiers() == GLUT_ACTIVE_ALT )
   {
      g_selected_vertex = g_selected_edge = g_selected_triangle = -1;
      
      g_cam.transform_mouse( x, y, g_ray_origin, g_ray_direction );
      
      unsigned int hit_index;
      
      unsigned int ray_cast_type;
      if ( button==GLUT_LEFT_BUTTON ) { ray_cast_type = 0; }
      else if ( button==GLUT_MIDDLE_BUTTON ) { ray_cast_type = 1; }
      else { ray_cast_type = 2; }
      
      unsigned int ray_hit_type = g_surf->ray_cast( Vec3f( g_ray_origin ), Vec3f( g_ray_direction ), ray_cast_type, hit_index );
      
      switch (ray_hit_type)
      {
         case SurfTrack::RAY_HIT_VERTEX:
            g_selected_vertex = hit_index;
            break;
         case SurfTrack::RAY_HIT_EDGE:
            g_selected_edge = hit_index;
            break;
         case SurfTrack::RAY_HIT_TRIANGLE:
            g_selected_triangle = hit_index;      
            break;
         default:
            assert( ray_hit_type == SurfTrack::RAY_HIT_NOTHING );
            break;
      }
      
      glutPostRedisplay();
      return;
   }
   
   g_cam.click(button, state, x, y);
}

// ---------------------------------------------------------
///
/// Handle mouse motion
///
// ---------------------------------------------------------

void mouseMotion(int x, int y)
{
   g_cam.drag(x, y);
}


// ---------------------------------------------------------
///
/// Advance simulation with GUI
///
// ---------------------------------------------------------

void advance_frame()
{
      
   if(!g_sim->m_currently_advancing_simulation)
   {
      g_sim->m_currently_advancing_simulation = true;
      
      if ( g_sim->m_curr_frame == 0 )
      {
         // output initial conditions
         char sgi_filename[256];
         sprintf( sgi_filename, "%s/frame%04d.sgi", g_output_path, g_sim->m_curr_frame );      
         Gluvi::sgi_screenshot( sgi_filename );         
      }
      
      advance_sim();
      
      glutPostRedisplay();
      
      char sgi_filename[256];
      sprintf( sgi_filename, "%s/frame%04d.sgi", g_output_path, g_sim->m_curr_frame );      
      Gluvi::sgi_screenshot( sgi_filename );
      
      if ( g_render_colliding_triangles )
      {
         if ( g_surf->m_collision_safety )
         {
            g_surf->assert_mesh_is_intersection_free();
         }
            
         glutPostRedisplay();
      }
                  
      g_sim->m_currently_advancing_simulation = false;

   }

}


// ---------------------------------------------------------
///
/// Load a mesh in binary format, and take an SGI screenshot
///
// ---------------------------------------------------------

void bin2sgi()
{
   
   g_surf->m_positions.clear();
   g_surf->m_mesh.clear();
   
   char bin_filename[256];
   sprintf( bin_filename, "%s/frame%04d.bin", g_output_path, g_sim->m_curr_frame );      
   
   printf( "input filename: %s\n", bin_filename ); 
   
   bool good = read_binary_file( g_surf->m_mesh, g_surf->m_positions, g_surf->m_masses, g_sim->m_curr_t, bin_filename );
   
   if (!good)
   {
      g_making_animation = false;
      return;
   }
   
   g_surf->m_mesh.clear_deleted_triangles();
   g_surf->m_mesh.update_connectivity( g_surf->m_positions.size() );   
   
   glutPostRedisplay();
   
   char sgi_filename[256];
   sprintf( sgi_filename, "%s/frame%04d.sgi", g_output_path, g_sim->m_curr_frame );      
   Gluvi::sgi_screenshot( sgi_filename );         
   
   ++g_sim->m_curr_frame;   
}


// ---------------------------------------------------------
///
/// Render to the OpenGL GUI.  Rendering the triangle surface is handled by SurfTrack::render
///
// ---------------------------------------------------------

void display(void)
{
   Gluvi::set_generic_lights();

   unsigned int options = 0;
   if ( g_render_edges ) { options |= SurfTrack::RENDER_EDGES; }
   if ( g_render_fill_triangles ) { options |= SurfTrack::RENDER_TRIANGLES; }
   if ( g_render_vertex_rank ) { options |= SurfTrack::RENDER_VERTEX_DATA; }
   if ( g_render_colliding_triangles ) { options |= SurfTrack::RENDER_COLLIDING_TRIANGLES; }
   if ( !g_smooth_shading ) { options |= SurfTrack::NO_SHADING; }
   
   
   options |= SurfTrack::TWO_SIDED;
   
   g_surf->render( options );

   if ( g_display_driver )
   {
      g_driver->display(*g_surf);
   }
   
   glDisable(GL_LIGHTING);
   
   if ( g_selected_vertex >= 0 )
   {
      glPointSize( 3.0f );
      glBegin(GL_POINTS);
      Vec3d& vtx0 = g_surf->m_positions[g_selected_vertex];
      glVertex3dv(vtx0.v);
      glEnd();      
   }
   
   if ( g_selected_edge >= 0 )
   {
      glBegin(GL_LINES);
      Vec2ui& edge = g_surf->m_mesh.m_edges[g_selected_edge];
      Vec3d& vtx0 = g_surf->m_positions[edge[0]];
      Vec3d& vtx1 = g_surf->m_positions[edge[1]];
      glVertex3dv(vtx0.v);
      glVertex3dv(vtx1.v);
      glEnd();
   }
   
   if ( g_selected_triangle >= 0 )
   {
      glBegin(GL_TRIANGLES);
      Vec3ui& triangle = g_surf->m_mesh.m_tris[g_selected_triangle];
      Vec3d& vtx0 = g_surf->m_positions[triangle[0]];
      Vec3d& vtx1 = g_surf->m_positions[triangle[1]];
      Vec3d& vtx2 = g_surf->m_positions[triangle[2]];
      glVertex3dv(vtx0.v);
      glVertex3dv(vtx1.v);
      glVertex3dv(vtx2.v);
      glEnd();      
   }
   
   glEnable(GL_LIGHTING);


   // check if we're running something
   
   if( g_sim->m_running )
   {
      advance_frame();
   }

   static double cam_y = 0.0;
   static double cam_y_vel = 0.25;
   static double cam_y_acc = -0.0065;
   
   if ( g_making_animation )
   {
      cam_y_vel += g_sim->m_dt * cam_y_acc;
      if ( cam_y_vel < 0.0 ) { cam_y_vel == 0.0; }
      cam_y += g_sim->m_dt * cam_y_vel;
      std::cout << cam_y << std::endl;
      g_cam.target[1] = cam_y;
      
      bin2sgi();
   }
          
}


// ---------------------------------------------------------
///
/// Initialize the OpenGL GUI
///
// ---------------------------------------------------------

void init_gui( int argc, char **argv )
{
   Gluvi::init("Talpa", &argc, argv);
      
   g_render_fill_triangles = true;
   g_render_colliding_triangles = false;
 
   glClearColor(1,1,1,0);
   Gluvi::camera=&g_cam;
   
   // default
   g_cam.target[0] = 0.0f;
   g_cam.target[1] = 0.0f;
   g_cam.target[2] = 0.0f;
   g_cam.dist = 10.0f;
   g_cam.heading = 0.0f;
   
   std::ifstream file( argv[1] );
   parse_gui_script( file, g_cam.target, g_cam.dist, g_cam.heading, g_cam.pitch );

   keyboard( 'd', 0, 0 );  // set to default

   Gluvi::userDisplayFunc=display;
   
   glutKeyboardFunc(keyboard);
   glutMouseFunc(mouse);
   glutMotionFunc(mouseMotion);
}

#endif  // #ifdef USE_GUI


// ---------------------------------------------------------
///
/// Initialize the simulation.  Set the simulation parameters, initial geometry, etc.
///
// ---------------------------------------------------------

void init_simulation( int argc, char **argv )
{
   assert( argc > 1 );
         
   SurfTrackInitializationParameters init_params;

   std::vector<Vec3ui> tris;
   std::vector<Vec3d> verts;
   std::vector<Vec3d> velocities;
   std::vector<double> masses;
   
   std::cout << "parsing script: " << argv[1] << std::endl;
   std::ifstream file( argv[1] );
   assert( file.good() );
   parse_script( file, g_driver, g_sim, tris, verts, velocities, masses, init_params );
        
   if ( masses.size() != verts.size() )
   {
      masses.resize( verts.size(), 1.0 );
   }
   
   g_surf = new SurfTrack( verts, tris, masses, init_params );   

   std::cout << "initial t: " << g_sim->m_curr_t << std::endl;
   
   g_surf->m_mesh.clear_deleted_triangles();
   g_surf->m_mesh.update_connectivity( g_surf->m_positions.size() );   
   g_surf->clear_deleted_vertices();
   g_surf->m_mesh.update_connectivity( g_surf->m_positions.size() );   
   
   g_surf->trim_non_manifold();
   g_surf->m_mesh.update_connectivity( g_surf->m_positions.size() );

   
   g_driver->initialize( *g_surf );
   
   if ( velocities.size() == verts.size() )
   {
      g_surf->m_velocities = velocities;      
   }
   
   g_surf->rebuild_static_broad_phase();      
   
   if ( g_surf->m_collision_safety )
   {
      g_surf->assert_mesh_is_intersection_free();      
   }
   
   std::cout << "max_edge_length " << g_surf->m_max_edge_length << std::endl;
   std::cout << "min_edge_length " << g_surf->m_min_edge_length << std::endl;
   std::cout << "max_volume_change " << g_surf->m_max_volume_change << std::endl;
   
   //
   // Initialize profiling and statistics variables
   //
   
   g_min_num_triangles = g_surf->m_mesh.m_tris.size();
   g_max_num_triangles = g_surf->m_mesh.m_tris.size();
   g_total_num_triangles = 0;
   g_min_num_vertices = g_surf->m_positions.size();
   g_max_num_vertices = g_surf->m_positions.size();
   g_total_num_vertices = 0;
               
   g_total_sim_time = 0;
   g_total_collision_time = 0;
   g_total_topology_time = 0;
   g_total_improvement_time = 0;
   g_total_driver_time = 0;
   
   g_total_steps = 0;
   
   set_time_base();
      
}

// ---------------------------------------------------------
///
/// MAIN
///
// ---------------------------------------------------------

int main(int argc, char **argv)
{   
   std::cout << "Talpa: Demo applications of El Topo" << std::endl;
   std::cout << "-----------------------------------" << std::endl << std::endl;

   if( argc < 2 )
   {
      std::cout << "Usage: <executable> <scriptfile> <outputdirectory>" << std::endl;
      std::cout << "e.g.: " << std::endl;
      std::cout << "$ ./talpa_release curlnoise-parameters.txt /var/tmp/" << std::endl;
      return 0;
   }
        
   // set path for outputting obj, bin files, etc.
   
   if ( argc > 2 )
   {
      strcpy( g_output_path, argv[2] );
   }
   else
   {
      // argc == 2
      strcpy( g_output_path, "." );
   }
     
   printf("Output path: %s\n", g_output_path );

   
   //
   // Initialize the simulation using the script file
   //
   
   init_simulation( argc, argv );

#ifdef USE_GUI
   
   //
   // Initialize the GUI using the script file
   //
   
   init_gui( argc, argv );
   
#endif
   
   srand( time(NULL) );
   
   // write frame 0
   char binary_filename[256];
   sprintf( binary_filename, "%s/frame%04d.bin", g_output_path, g_sim->m_curr_frame );      
   write_binary_file( g_surf->m_mesh, g_surf->m_positions, g_surf->m_masses, g_sim->m_curr_t, binary_filename );   
   
   //
   // Now start
   //
   
#ifdef USE_GUI
   // start the GUI
   Gluvi::run();
#else

   // default
   std::ifstream file( argv[1] );
   parse_gui_script( file, g_cam.target, g_cam.dist, g_cam.heading, g_cam.pitch );
   
   //while(1) { raytrace(); }
      
   // start the simulation (hands off)
   run_simulation();
   
   // uncomment to run all examples in our SISC paper:
   //run_all_sisc_examples( "./sisc-scripts/" );
   
#endif
   
   return 0;
}



