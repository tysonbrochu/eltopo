// ---------------------------------------------------------
//
//  parser.h
//  Tyson Brochu 2008
//
//  Parses a text file specifying the simulation parameters and initial conditions.
//  (I just hacked this together -- there is surely a much better way to do this.)
//
// ---------------------------------------------------------

#ifndef PARSER_H
#define PARSER_H

// ---------------------------------------------------------
// Nested includes
// ---------------------------------------------------------

#include <string>
#include <vec.h>

// ---------------------------------------------------------
//  Forwards and typedefs
// ---------------------------------------------------------

class MeshDriver;
class SurfTrackInitializationParameters;
class SurfTrack;
class Simulation;

// ---------------------------------------------------------
//  Interface declarations
// ---------------------------------------------------------

void contour_phi( const Vec3d& domain_low, double domain_dx, Array3d& phi, std::vector<Vec3ui>& tris, std::vector<Vec3d>& verts );

void parse_vec3d( const std::string& line, std::string::size_type& loc, Vec3d& vec );

void parse_driver( const std::string& line, MeshDriver*& driver );

void parse_simulation( const std::string& line, Simulation*& sim );

void parse_subdivision_scheme( const std::string& line, SurfTrackInitializationParameters& init );

void parse_command( const std::string& line,
                    MeshDriver*& driver, 
                    Simulation*& sim, 
                    std::vector<Vec3ui>& tris, 
                    std::vector<Vec3d>& verts, 
                    std::vector<Vec3d>& velocities, 
                    std::vector<double>& masses,                   
                    SurfTrackInitializationParameters& init );


void parse_script( std::istream& file, 
                   MeshDriver*& driver, 
                   Simulation*& sim, 
                   std::vector<Vec3ui>& tris, 
                   std::vector<Vec3d>& verts, 
                   std::vector<Vec3d>& velocities,     
                   std::vector<double>& masses,                  
                   SurfTrackInitializationParameters& init );

// Can be the same file as above

void parse_gui_script( std::istream& file,
                       float* cam_target,
                       float& cam_distance,
                       float& cam_heading,
                       float& cam_pitch );


// ---------------------------------------------------------
//  Inline definitions
// ---------------------------------------------------------


#endif

