
EL TOPO: ROBUST TOPOLOGICAL OPERATIONS FOR DYNAMIC EXPLICIT SURFACES
===============================================================================

This distribution contains the following directories:

eltopo3d: the El Topo library
talpa: an example executable using El Topo
common: source code shared by our research group used by El Topo and Talpa

For information on building El Topo or Talpa, see the readme files in their
respective directories.  I highly recommend seeing at least the El Topo readme before getting started.



Tyson Brochu
June 30, 2009


